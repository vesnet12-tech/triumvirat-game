import { GameNode, Equipment, MagicSpell, UsableItem, Monster, Stats, ClassType } from '../types';

export interface ClassDefinition {
  type: ClassType;
  nameRu: string;
  nameEn: string;
  descriptionRu: string;
  descriptionEn: string;
  baseStats: Stats;
  skillNameRu: string;
  skillNameEn: string;
  skillDescriptionRu: string;
  skillDescriptionEn: string;
}

export const CLASS_DEFINITIONS: Record<ClassType, ClassDefinition> = {
  warrior: {
    type: 'warrior',
    nameRu: 'Воин',
    nameEn: 'Warrior',
    descriptionRu: 'Мастер ближнего боя с высоким здоровьем и сильной атакой.',
    descriptionEn: 'Melee master with high health and strong physical attack.',
    baseStats: { hp: 70, maxHp: 70, atk: 16, def: 14, mg: 4, spd: 8 },
    skillNameRu: 'Сокрушение',
    skillNameEn: 'Decimate',
    skillDescriptionRu: 'Наносит 1.7x физического урона, но наносит воину отдачу в 15% от нанесенного урона.',
    skillDescriptionEn: 'Deals 1.7x physical damage, but inflicts 15% recoil damage back to the warrior.'
  },
  mage: {
    type: 'mage',
    nameRu: 'Маг',
    nameEn: 'Mage',
    descriptionRu: 'Хрупкий колдун, способный испепелять врагов заклинаниями, игнорируя защиту.',
    descriptionEn: 'Fragile spellcaster capable of incinerating foes while ignoring physical defense.',
    baseStats: { hp: 45, maxHp: 45, atk: 6, def: 6, mg: 18, spd: 11 },
    skillNameRu: 'Искры Бездны',
    skillNameEn: 'Void Sparks',
    skillDescriptionRu: 'Наносит магический урон мощностью 1.5x, полностью игнорируя физический щит.',
    skillDescriptionEn: 'Deals 1.5x magical damage, completely bypassing normal physical shields.'
  },
  thief: {
    type: 'thief',
    nameRu: 'Вор',
    nameEn: 'Thief',
    descriptionRu: 'Невероятно быстрый и ловкий класс, ворующий золото во время атаки.',
    descriptionEn: 'Incredibly fast and agile class, stealing gold directly during physical strikes.',
    baseStats: { hp: 55, maxHp: 55, atk: 11, def: 8, mg: 6, spd: 16 },
    skillNameRu: 'Карманная кража',
    skillNameEn: 'Pickpocket',
    skillDescriptionRu: 'Наносит урон и крадет у цели 50-150 золотых прямо в бою.',
    skillDescriptionEn: 'Deals moderate strike damage and steals 50-150 gold directly from the victim.'
  },
  cleric: {
    type: 'cleric',
    nameRu: 'Клирик',
    nameEn: 'Cleric',
    descriptionRu: 'Защитный класс с огромным запасом здоровья и умением исцелять себя в бою.',
    descriptionEn: 'Defensive powerhouse with high baseline health and the ability to heal in battle.',
    baseStats: { hp: 80, maxHp: 80, atk: 8, def: 16, mg: 9, spd: 6 },
    skillNameRu: 'Святое Исцеление',
    skillNameEn: 'Divine Heal',
    skillDescriptionRu: 'Мгновенно восстанавливает 30 ед. здоровья во время хода атаки.',
    skillDescriptionEn: 'Instantly recovers 30 HP during the combat action phase.'
  }
};

export const WEAPONS_DB: Equipment[] = [
  { id: 'w1', name: 'Бронзовый меч', type: 'weapon', bonusAtk: 5, bonusDef: 0, bonusMg: 0, bonusSpd: 0, cost: 150, description: 'Стандартный легкий клинок.' },
  { id: 'w2', name: 'Стальное копьё', type: 'weapon', bonusAtk: 12, bonusDef: 2, bonusMg: 0, bonusSpd: -1, cost: 400, description: 'Длинное тяжелое копьё для сильных колющих ударов.' },
  { id: 'w3', name: 'Жезл Ученика', type: 'weapon', bonusAtk: 2, bonusDef: 0, bonusMg: 10, bonusSpd: 1, cost: 350, description: 'Усиливает магический потенциал владельца.' },
  { id: 'w4', name: 'Секира Опустошителя', type: 'weapon', bonusAtk: 25, bonusDef: -2, bonusMg: 0, bonusSpd: -3, cost: 950, description: 'Двуручный топор, вселяющий ужас в монстров.' }
];

export const SHIELDS_DB: Equipment[] = [
  { id: 's1', name: 'Деревянный щит', type: 'shield', bonusAtk: 0, bonusDef: 4, bonusMg: 0, bonusSpd: 0, cost: 100, description: 'Простой щит из дубовых досок.' },
  { id: 's2', name: 'Железный баклер', type: 'shield', bonusAtk: 0, bonusDef: 10, bonusMg: 0, bonusSpd: -1, cost: 300, description: 'Кованый металлический круглый щит.' },
  { id: 's3', name: 'Рунический оберег', type: 'shield', bonusAtk: 0, bonusDef: 5, bonusMg: 8, bonusSpd: 2, cost: 500, description: 'Защищает от физических и магических воздействий.' },
  { id: 's4', name: 'Ростовой щит Эгида', type: 'shield', bonusAtk: -2, bonusDef: 24, bonusMg: 0, bonusSpd: -4, cost: 1000, description: 'Тяжелый щит рыцарей Королевской гвардии.' }
];

export const SPELLS_DB: MagicSpell[] = [
  { id: 'sp1', name: 'Огненная вспышка', power: 12, cost: 120, type: 'attack', description: 'Базовое огненное заклинание.' },
  { id: 'sp2', name: 'Грозовая цепь', power: 24, cost: 450, type: 'attack', description: 'Бьет молнией, нанося сокрушительный урон.' },
  { id: 'sp3', name: 'Пелена Тьмы', power: 8, cost: 200, type: 'defense', description: 'Снижает получаемый магический урон.' }
];

export const ITEMS_DB: UsableItem[] = [
  { id: 'it1', name: 'Двойной Спиннер', description: 'Позволяет бросить 2 кубика за раз.', cost: 80, type: 'spinner', value: 2 },
  { id: 'it2', name: 'Тройной Спиннер', description: 'Позволяет бросить 3 кубика за раз.', cost: 180, type: 'spinner', value: 3 },
  { id: 'it3', name: 'Лечебное зелье', description: 'Полностью восстанавливает 40 ед. здоровья.', cost: 50, type: 'heal', value: 40 },
  { id: 'it4', name: 'Эликсир жизни', description: 'Полностью восстанавливает все ОЗ (HP).', cost: 150, type: 'heal', value: 999 },
  { id: 'it5', name: 'Кристалл телепортации', description: 'Переносит на случайную клетку деревни.', cost: 120, type: 'warp', value: 0 }
];

export const MONSTERS_POOL: Monster[] = [
  { name: 'Лесной Слайм', stats: { hp: 20, maxHp: 20, atk: 6, def: 4, mg: 2, spd: 4 }, rewardExp: 15, rewardGold: 25 },
  { name: 'Дикий Кобольд', stats: { hp: 30, maxHp: 30, atk: 9, def: 6, mg: 3, spd: 8 }, rewardExp: 25, rewardGold: 45 },
  { name: 'Гоблин-Мародёр', stats: { hp: 40, maxHp: 40, atk: 12, def: 8, mg: 4, spd: 10 }, rewardExp: 40, rewardGold: 70 },
  { name: 'Пещерный Паук', stats: { hp: 35, maxHp: 35, atk: 14, def: 5, mg: 5, spd: 12 }, rewardExp: 50, rewardGold: 85 },
  { name: 'Разбойник Пустошей', stats: { hp: 55, maxHp: 55, atk: 16, def: 10, mg: 2, spd: 9 }, rewardExp: 75, rewardGold: 120 }
];

export const TOWN_MONSTERS: Record<string, Monster> = {
  node_3: { name: 'Гоблин-Завоеватель 👺', stats: { hp: 60, maxHp: 60, atk: 18, def: 12, mg: 6, spd: 12 }, rewardExp: 100, rewardGold: 200, isBoss: true },
  node_6: { name: 'Свирепый Орк-Узурпатор 🐗', stats: { hp: 90, maxHp: 90, atk: 24, def: 18, mg: 4, spd: 8 }, rewardExp: 180, rewardGold: 350, isBoss: true },
  node_10: { name: 'Древний Горный Каменный Голем 🪨', stats: { hp: 130, maxHp: 130, atk: 28, def: 32, mg: 10, spd: 5 }, rewardExp: 250, rewardGold: 500, isBoss: true }
};

export const KING_MONSTER: Monster = {
  name: 'Тёмный Лорд Бальтазар 👑👹',
  stats: { hp: 200, maxHp: 200, atk: 35, def: 25, mg: 25, spd: 20 },
  rewardExp: 1000,
  rewardGold: 2000,
  isBoss: true
};

export const MAP_NODES: GameNode[] = [
  {
    id: 'start',
    name: 'Стартовая Деревня 🏡',
    type: 'empty',
    x: 10,
    y: 50,
    neighbors: ['node_1', 'node_4']
  },
  {
    id: 'node_1',
    name: 'Священная Поляна 🌳',
    type: 'empty',
    x: 25,
    y: 25,
    neighbors: ['start', 'node_2']
  },
  {
    id: 'node_2',
    name: 'Заброшенный Алтарь 💎',
    type: 'chest',
    chestRewardType: 'item',
    x: 45,
    y: 20,
    neighbors: ['node_1', 'node_3', 'king_castle']
  },
  {
    id: 'node_3',
    name: 'Деревня Оквейл 🏡 (В осаде!)',
    type: 'town',
    townTax: 50,
    townIncome: 25,
    townMonster: TOWN_MONSTERS['node_3'],
    x: 65,
    y: 20,
    neighbors: ['node_2', 'node_5']
  },
  {
    id: 'node_4',
    name: 'Долина Смерти 💀',
    type: 'empty',
    x: 25,
    y: 75,
    neighbors: ['start', 'node_7']
  },
  {
    id: 'node_5',
    name: 'Лесная Развилка 🪵',
    type: 'empty',
    x: 80,
    y: 25,
    neighbors: ['node_3', 'node_6', 'node_9']
  },
  {
    id: 'node_6',
    name: 'Город Ривербенд 🏙️ (В осаде!)',
    type: 'town',
    townTax: 120,
    townIncome: 60,
    townMonster: TOWN_MONSTERS['node_6'],
    x: 90,
    y: 50,
    neighbors: ['node_5', 'node_11']
  },
  {
    id: 'node_7',
    name: 'Каменное Ущелье 🪨',
    type: 'chest',
    chestRewardType: 'gold',
    x: 45,
    y: 80,
    neighbors: ['node_4', 'node_8', 'king_castle']
  },
  {
    id: 'node_8',
    name: 'Лавка Чудес Dokapon 🔮',
    type: 'shop',
    x: 65,
    y: 80,
    neighbors: ['node_7', 'node_9']
  },
  {
    id: 'node_9',
    name: 'Болото Мучений 🐊',
    type: 'empty',
    x: 70,
    y: 55,
    neighbors: ['node_5', 'node_8', 'node_10']
  },
  {
    id: 'node_10',
    name: 'Царство Теней Шедоуфен 🌲 (В осаде!)',
    type: 'town',
    townTax: 250,
    townIncome: 120,
    townMonster: TOWN_MONSTERS['node_10'],
    x: 80,
    y: 75,
    neighbors: ['node_9', 'node_11']
  },
  {
    id: 'node_11',
    name: 'Врата Судьбы ⛩️',
    type: 'empty',
    x: 90,
    y: 70,
    neighbors: ['node_6', 'node_10', 'king_castle']
  },
  {
    id: 'king_castle',
    name: 'Королевский Замок 👑🏰',
    type: 'king_castle',
    x: 50,
    y: 50,
    neighbors: ['node_2', 'node_7', 'node_11']
  }
];
