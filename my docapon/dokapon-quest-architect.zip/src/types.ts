export type ClassType = 'warrior' | 'mage' | 'thief' | 'cleric';

export interface Stats {
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  mg: number;
  spd: number;
}

export interface Equipment {
  id: string;
  name: string;
  type: 'weapon' | 'shield';
  bonusAtk: number;
  bonusDef: number;
  bonusMg: number;
  bonusSpd: number;
  cost: number;
  description: string;
}

export interface MagicSpell {
  id: string;
  name: string;
  cost: number;
  power: number;
  description: string;
  type: 'attack' | 'defense'; // Used in combat
}

export interface UsableItem {
  id: string;
  name: string;
  description: string;
  cost: number;
  type: 'spinner' | 'heal' | 'warp';
  value: number; // For spinner: number of extra dice, for heal: amount, for warp: target node
}

export interface Monster {
  name: string;
  stats: Stats;
  rewardExp: number;
  rewardGold: number;
  isBoss?: boolean;
}

export type NodeType = 'empty' | 'shop' | 'town' | 'chest' | 'king_castle';

export interface GameNode {
  id: string;
  name: string;
  type: NodeType;
  x: number; // percentage coordinate on visual map (0-100)
  y: number; // percentage coordinate on visual map (0-100)
  neighbors: string[]; // IDs of connected nodes
  townOwnerId?: string | null; // who owns this town
  townTax?: number; // fee to pay when landing on others' town
  townIncome?: number; // turn-by-turn income for owner
  townMonster?: Monster | null; // monster to fight to free this town
  chestRewardType?: 'item' | 'spell' | 'gold' | 'trap';
}

export interface Player {
  id: string;
  name: string;
  isAi: boolean;
  classType: ClassType;
  level: number;
  exp: number;
  gold: number;
  stats: Stats;
  statPoints: number; // customizable free points
  weapon: Equipment | null;
  shield: Equipment | null;
  spells: MagicSpell[];
  items: UsableItem[];
  currentNodeId: string;
  isDarkling: boolean;
  darklingTurnsLeft: number;
  isDead: boolean;
  reviveInTurns: number;
  townsOwned: string[]; // IDs of towns owned
  shamedName: string | null; // renamed by other player after losing PvP
  skinIndex: number; // 1-32, custom sprite index
  direction?: 'down' | 'left' | 'right' | 'up';
}

export interface GameEvent {
  id: string;
  title: string;
  description: string;
  effect: (player: Player) => { log: string; modifiedPlayer: Player };
}

// Combat State
export type CombatPhase = 'first_strike_choice' | 'round_start' | 'attacker_choice' | 'defender_choice' | 'result' | 'ended';

export type AttackerMove = 'attack' | 'strike' | 'magic' | 'skill';
export type DefenderMove = 'defend' | 'counter' | 'mg_defend' | 'give_up';

export interface CombatState {
  attackerId: string; // ID of attacker (player or monster)
  defenderId: string; // ID of defender (player or monster)
  attackerName: string;
  defenderName: string;
  attackerStats: Stats;
  defenderStats: Stats;
  attackerMaxHp: number;
  defenderMaxHp: number;
  attackerSpell?: MagicSpell | null;
  defenderSpell?: MagicSpell | null;
  attackerIsPlayer: boolean;
  defenderIsPlayer: boolean;
  turnOwnerId: string; // whose turn it is to choose action
  attackerMove?: AttackerMove;
  defenderMove?: DefenderMove;
  combatLog: string[];
  phase: CombatPhase;
  rewardGold?: number;
  rewardExp?: number;
  townNodeId?: string; // set if we are fighting to liberate a town
  pvpWinnerId?: string; // ID of winning player in PvP
  pvpLoserId?: string; // ID of losing player in PvP
}

export interface BoardMap {
  id: string;
  name: string;
  nodes: GameNode[];
  isCustom?: boolean;
}
