import React, { useState, useEffect, useRef } from 'react';
import { Player, GameNode, UsableItem, Equipment, MagicSpell, ClassType, Monster, Stats, BoardMap } from './types';
import { MAP_NODES, CLASS_DEFINITIONS, SPELLS_DB, ITEMS_DB, MONSTERS_POOL, KING_MONSTER } from './data/gameData';
import MapBoard from './components/MapBoard';
import CombatScreen from './components/CombatScreen';
import ShopScreen from './components/ShopScreen';
import StatDistribution from './components/StatDistribution';
import CharacterSkin from './components/CharacterSkin';
import SkinSelectorModal from './components/SkinSelectorModal';
import MapEditor from './components/MapEditor';
import { 
  Swords, Shield, Coins, Sparkles, Box, Trophy, ArrowRight, UserPlus, Play, 
  RefreshCw, Crown, Zap, ShieldAlert, Languages, Volume2, Gamepad2, Settings, LogOut, LayoutGrid, Trash2, MapPin
} from 'lucide-react';

export default function App() {
  // --- Game State ---
  const [gameStage, setGameStage] = useState<'intro' | 'main_menu' | 'map_editor' | 'setup' | 'playing' | 'game_over'>('intro');
  const [lang, setLang] = useState<'ru' | 'en'>('ru');
  const [isResetConfirming, setIsResetConfirming] = useState(false);

  // --- Translation Dictionary ---
  const t = {
    ru: {
      gameTitle: "docopixel6",
      creator: "Создатель игры: marazay",
      futureVideo: "🎮 В будущем здесь будет видео заставка игрового мира!",
      pressAnyKey: "НАЖМИТЕ ЛЮБУЮ КНОПКУ ЧТОБЫ ВОЙТИ",
      enter: "Вход",
      settings: "Настройки",
      exit: "Выход",
      settingsTitle: "Настройки игры",
      langSelect: "Смена языка",
      langRu: "Русский 🇷🇺",
      langEn: "English 🇬🇧",
      exitMessage: "Вернуться на экран заставки?",
      selectGameMode: "Выберите игровой режим",
      classicGame: "Классическая игра",
      classicGameDesc: "Настольная RPG с прокачкой, боями с монстрами и осадой деревень!",
      mapEditorBtn: "Редактор карт",
      mapEditorDesc: "Конструируйте свои собственные карты, расставляйте клетки и сохраняйте их!",
      chooseMap: "Выбор карты для игры",
      standardMap: "Стандартная карта Королевства",
      customBoardTag: "Пользовательская карта",
      numNodes: "клеток",
      back: "Назад в меню",
      startCampaign: "Создание новой кампании DocoPixel6",
      setupDesc: "Настройте героев для участия. Игроки могут ходить по очереди на одном экране (Hotseat)!",
      hero: "ГЕРОЙ",
      player: "ИГРОК",
      bot: "БОТ ИИ",
      charName: "Имя персонажа",
      skin: "Скин",
      chooseClass: "Выберите класс RPG",
      startAdventure: "Начать Приключение! ⚔️🏰",
      resetGameConfirm: "Перезапустить игру и вернуться в главное меню?",
      resetBtn: "Главное меню 🔄",
    },
    en: {
      gameTitle: "docopixel6",
      creator: "Created by marazay",
      futureVideo: "🎮 Opening video cinematic placeholder!",
      pressAnyKey: "PRESS ANY KEY TO START",
      enter: "Enter Game",
      settings: "Settings",
      exit: "Exit",
      settingsTitle: "Game Settings",
      langSelect: "Change Language",
      langRu: "Русский 🇷🇺",
      langEn: "English 🇬🇧",
      exitMessage: "Return to the title splash screen?",
      selectGameMode: "Select Game Mode",
      classicGame: "Classic Campaign",
      classicGameDesc: "JRPG board-game adventure with stats levelling, combat & villages liberation!",
      mapEditorBtn: "Map Creator",
      mapEditorDesc: "Design custom gaming boards, set coordinates & save them!",
      chooseMap: "Select Playing Map",
      standardMap: "Standard Kingdom Board",
      customBoardTag: "Custom Map",
      numNodes: "nodes",
      back: "Back to Menu",
      startCampaign: "Create New DocoPixel6 Campaign",
      setupDesc: "Configure your party. You can play together on a single screen hotseat-style!",
      hero: "HERO",
      player: "PLAYER",
      bot: "AI BOT",
      charName: "Character Name",
      skin: "Skin",
      chooseClass: "Select RPG Class",
      startAdventure: "Launch Campaign! ⚔️🏰",
      resetGameConfirm: "Restart game and return to the main menu?",
      resetBtn: "Main Menu 🔄",
    }
  }[lang];
  
  // Custom Maps Support
  const [availableMaps, setAvailableMaps] = useState<BoardMap[]>([]);
  const [selectedMapId, setSelectedMapId] = useState<string>('default');

  // Load custom maps from localStorage on stage changes
  useEffect(() => {
    const saved = localStorage.getItem('docopixel_custom_maps');
    if (saved) {
      try {
        setAvailableMaps(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load custom maps', e);
      }
    }
  }, [gameStage]);

  // Customizing Players in Setup
  const [setupPlayers, setSetupPlayers] = useState<Array<{ name: string; classType: ClassType; isAi: boolean; skinIndex: number }>>([
    { name: 'Игрок 1', classType: 'warrior', isAi: false, skinIndex: 1 },
    { name: 'Бот Вася 🤖', classType: 'mage', isAi: true, skinIndex: 2 },
    { name: 'Игрок 2', classType: 'thief', isAi: false, skinIndex: 3 },
    { name: 'Бот Петя 🤖', classType: 'cleric', isAi: true, skinIndex: 4 }
  ]);

  const handleSetPlayerCount = (count: number) => {
    setSetupPlayers(prev => {
      if (prev.length === count) return prev;
      if (prev.length > count) {
        return prev.slice(0, count);
      } else {
        const added: typeof prev = [];
        for (let i = prev.length; i < count; i++) {
          const isAi = i >= 2; // AI bots default for 3rd/4th/5th/6th player placeholders, but customizable
          added.push({
            name: isAi ? (lang === 'ru' ? `Бот ${i + 1} 🤖` : `Bot ${i + 1} 🤖`) : (lang === 'ru' ? `Игрок ${i + 1}` : `Player ${i + 1}`),
            classType: (['warrior', 'mage', 'thief', 'cleric'][i % 4]) as ClassType,
            isAi: isAi,
            skinIndex: i + 1
          });
        }
        return [...prev, ...added];
      }
    });
  };

  const [players, setPlayers] = useState<Player[]>([]);
  const [activePlayerIdx, setActivePlayerIdx] = useState<number>(0);
  const [nodes, setNodes] = useState<GameNode[]>(MAP_NODES);
  
  // Dialog / Overlay triggers
  const [combatOpponent, setCombatOpponent] = useState<Player | Monster | null>(null);
  const [isCombatOpponentPlayer, setIsCombatOpponentPlayer] = useState<boolean>(false);
  const [combatTownNodeId, setCombatTownNodeId] = useState<string | undefined>(undefined);
  
  const [activeShopPlayerId, setActiveShopPlayerId] = useState<string | null>(null);
  const [activeStatDistPlayerId, setActiveStatDistPlayerId] = useState<string | null>(null);
  const [isKingRewardAllocation, setIsKingRewardAllocation] = useState<boolean>(false);
  const [selectedSetupPlayerForSkin, setSelectedSetupPlayerForSkin] = useState<number | null>(null);

  // Global game event logging
  const [eventLogs, setEventLogs] = useState<string[]>(['Добро пожаловать в DocoPixel6! Настройте игроков и начните соревнование.']);
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Intro Splash Screen Event Listeners
  useEffect(() => {
    if (gameStage !== 'intro') return;
    const handleTrigger = () => {
      setGameStage('main_menu');
    };
    window.addEventListener('keydown', handleTrigger);
    window.addEventListener('click', handleTrigger);
    return () => {
      window.removeEventListener('keydown', handleTrigger);
      window.removeEventListener('click', handleTrigger);
    };
  }, [gameStage]);

  // Movement parameters
  const [diceRoll, setDiceRoll] = useState<number>(0);
  const [isWalking, setIsWalking] = useState<boolean>(false);
  const [movesRemaining, setMovesRemaining] = useState<number>(0);
  const [currentWalkingNodeId, setCurrentWalkingNodeId] = useState<string>('start');
  const [moveHistory, setMoveHistory] = useState<string[]>([]);

  // Dice rolling animation state
  const [isRollingDiceAnimation, setIsRollingDiceAnimation] = useState<boolean>(false);
  const [isDiceActivelySpinning, setIsDiceActivelySpinning] = useState<boolean>(false);
  const [diceAnimValue, setDiceAnimValue] = useState<number>(1);
  const [isAiRolling, setIsAiRolling] = useState<boolean>(false);

  // Quest Tracker
  const [kingFirstReachClaimed, setKingFirstReachClaimed] = useState<boolean>(false);
  const [kingWinnerName, setKingWinnerName] = useState<string | null>(null);
  const [finalWinner, setFinalWinner] = useState<Player | null>(null);
  const [turnCount, setTurnCount] = useState<number>(1);

  // Auto-scroll logs
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [eventLogs]);

  const addLog = (msg: string) => {
    setEventLogs(prev => [...prev, msg]);
  };

  // --- Recursive Pathfinding (Dokapon branching, no immediate backstep) ---
  const getReachableNodes = (
    nodeId: string,
    steps: number,
    prevNodeId: string | null = null
  ): string[] => {
    if (steps === 0) return [nodeId];
    const currentNode = nodes.find(n => n.id === nodeId);
    if (!currentNode) return [];

    let reachable: string[] = [];
    currentNode.neighbors.forEach(neighId => {
      if (neighId !== prevNodeId) {
        const paths = getReachableNodes(neighId, steps - 1, nodeId);
        reachable.push(...paths);
      }
    });

    return Array.from(new Set(reachable));
  };

  // --- Initializing Game ---
  const startGame = () => {
    // Dynamically load selected map nodes
    let gameNodes = MAP_NODES;
    if (selectedMapId !== 'default') {
      const customMap = availableMaps.find(m => m.id === selectedMapId);
      if (customMap) {
        gameNodes = customMap.nodes;
      }
    }
    setNodes(gameNodes);

    const initialized: Player[] = setupPlayers.map((sp, idx) => {
      const def = CLASS_DEFINITIONS[sp.classType];
      return {
        id: `p${idx + 1}`,
        name: sp.name,
        isAi: sp.isAi,
        classType: sp.classType,
        level: 1,
        exp: 0,
        gold: 300, // Starter funds
        stats: { ...def.baseStats },
        statPoints: 0,
        weapon: null,
        shield: null,
        spells: [SPELLS_DB[0]], // Everyone knows Basic Flame Flare
        items: [ITEMS_DB[0], ITEMS_DB[2]], // Starts with 1 Double Spinner and 1 Potion
        currentNodeId: 'start',
        isDarkling: false,
        darklingTurnsLeft: 0,
        isDead: false,
        reviveInTurns: 0,
        townsOwned: [],
        shamedName: null,
        skinIndex: sp.skinIndex || (idx + 1)
      };
    });

    setPlayers(initialized);
    setActivePlayerIdx(0);
    setGameStage('playing');
    setEventLogs([
      '⚔️ Игра Dokapon Kingdom началась! Все искатели приключений стартуют в Стартовой Деревне.',
      '👑 ЗАДАНИЕ ОТ КОРОЛЯ: Спешите к Королевскому Замку! Тот, кто первым доберется туда, получит огромный дар в +10 очков характеристик!'
    ]);
  };

  // --- Main Turn-Based Game Loop Coordinator ---
  const endTurn = () => {
    setTurnCount(prev => prev + 1);
    // Determine next active player
    let nextIdx = (activePlayerIdx + 1) % players.length;
    
    // Check dead players revive cooldowns
    setPlayers(prevPlayers => {
      const updated = prevPlayers.map((p, idx) => {
        if (idx === nextIdx && p.isDead) {
          if (p.reviveInTurns <= 1) {
            addLog(`💖 Игрок ${p.shamedName || p.name} оправился от ран и воскрес в Стартовой Деревне!`);
            return {
              ...p,
              isDead: false,
              reviveInTurns: 0,
              stats: { ...p.stats, hp: p.stats.maxHp },
              currentNodeId: 'start'
            };
          } else {
            addLog(`💀 Игрок ${p.shamedName || p.name} все еще без сознания. Воскрешение через ${p.reviveInTurns - 1} х.`);
            return {
              ...p,
              reviveInTurns: p.reviveInTurns - 1
            };
          }
        }
        
        // Handle Darkling turn tick down
        if (idx === nextIdx && p.isDarkling) {
          if (p.darklingTurnsLeft <= 1) {
            addLog(`😈 Тёмный пакт истек! Игрок ${p.shamedName || p.name} вернулся к своей истинной форме.`);
            const classDef = CLASS_DEFINITIONS[p.classType];
            return {
              ...p,
              isDarkling: false,
              darklingTurnsLeft: 0,
              stats: {
                ...p.stats,
                atk: classDef.baseStats.atk,
                def: classDef.baseStats.def,
                mg: classDef.baseStats.mg,
                spd: classDef.baseStats.spd
              }
            };
          } else {
            return {
              ...p,
              darklingTurnsLeft: p.darklingTurnsLeft - 1
            };
          }
        }
        return p;
      });

      // If the next player is still marked dead after tick down, automatically skip turn!
      const nextPlayer = updated[nextIdx];
      if (nextPlayer.isDead) {
        setTimeout(() => {
          setActivePlayerIdx(nextIdx);
          endTurn();
        }, 1500);
      } else {
        setActivePlayerIdx(nextIdx);
        // Trigger AI automation if applicable
        if (nextPlayer.isAi) {
          setTimeout(() => handleAiTurn(nextPlayer), 1500);
        }
      }

      return updated;
    });
  };

  // --- Darkling transformation toggle (toxicity / comeback mechanic) ---
  const triggerDarklingTransformation = (playerId: string) => {
    setPlayers(prev => prev.map(p => {
      if (p.id === playerId) {
        addLog(`😈🔥 ЧРЕЗВЫЧАЙНОЕ СОБЫТИЕ! Отстающий игрок ${p.shamedName || p.name} заключил сделку с Тьмой и превратился в сверх-сильного демона DARKLING на 3 хода! Характеристики увеличены вдвое! Берегитесь!`);
        return {
          ...p,
          isDarkling: true,
          darklingTurnsLeft: 3,
          stats: {
            ...p.stats,
            atk: p.stats.atk * 2,
            def: p.stats.def * 2,
            mg: p.stats.mg * 2,
            spd: p.stats.spd * 2,
            hp: p.stats.maxHp,
          }
        };
      }
      return p;
    }));
  };

  // --- Handle Usable Items ---
  const handleUseItem = (itemId: string) => {
    const activePlayer = players[activePlayerIdx];
    const item = activePlayer.items.find(it => it.id === itemId);
    if (!item) return;

    addLog(`📦 ${activePlayer.shamedName || activePlayer.name} активирует предмет: [${item.name}]!`);
    
    // Remove item from inventory
    let updatedItems = [...activePlayer.items];
    const idx = updatedItems.findIndex(it => it.id === itemId);
    if (idx !== -1) updatedItems.splice(idx, 1);

    if (item.type === 'heal') {
      const healAmount = item.value;
      const newHp = Math.min(activePlayer.stats.maxHp, activePlayer.stats.hp + healAmount);
      
      setPlayers(prev => prev.map((p, i) => i === activePlayerIdx ? {
        ...p,
        stats: { ...p.stats, hp: newHp },
        items: updatedItems
      } : p));
      
      addLog(`💖 Восстановлено +${healAmount} ОЗ. Здоровье: ${newHp}/${activePlayer.stats.maxHp}`);
    } else if (item.type === 'spinner') {
      // Set spinner modifier (extra dice multiplier)
      const rollValue = Math.floor(Math.random() * (6 * item.value)) + item.value;
      addLog(`🎲 Сверх-спиннер раскручен! Выдано шагов: ${rollValue}!`);
      
      setPlayers(prev => prev.map((p, i) => i === activePlayerIdx ? { ...p, items: updatedItems } : p));
      startWalking(rollValue);
    } else if (item.type === 'warp') {
      // Warp directly to a random town node
      const townNodes = nodes.filter(n => n.type === 'town');
      const randomTown = townNodes[Math.floor(Math.random() * townNodes.length)];
      
      addLog(`🌀 Кристалл Искажения перенес персонажа в локацию: ${randomTown.name}!`);
      
      setPlayers(prev => prev.map((p, i) => i === activePlayerIdx ? {
        ...p,
        currentNodeId: randomTown.id,
        items: updatedItems
      } : p));

      // Land directly
      setTimeout(() => handleLandingAction(randomTown.id), 1000);
    }
  };

  // --- DICE ROLL & WALK TRIGGERS WITH ANIMATION ---
  const runRollAnimation = (rollValue: number, isAi: boolean, onComplete: () => void) => {
    setIsRollingDiceAnimation(true);
    setIsDiceActivelySpinning(true);
    setIsAiRolling(isAi);
    
    let count = 0;
    const interval = setInterval(() => {
      setDiceAnimValue(Math.floor(Math.random() * 6) + 1);
      count++;
      if (count > 10) {
        clearInterval(interval);
        setDiceAnimValue(rollValue);
        setIsDiceActivelySpinning(false);
        
        setTimeout(() => {
          setIsRollingDiceAnimation(false);
          setIsAiRolling(false);
          onComplete();
        }, 1200);
      }
    }, 80);
  };

  const handleRollDice = () => {
    const activePlayer = players[activePlayerIdx];
    if (isWalking || isRollingDiceAnimation) return;

    const roll = Math.floor(Math.random() * 6) + 1;
    addLog(`🎲 Игрок ${activePlayer.shamedName || activePlayer.name} бросил число на спиннере...`);
    
    setDiceRoll(roll);
    runRollAnimation(roll, false, () => {
      addLog(`🎲 Выпало число: ${roll}!`);
      startWalking(roll);
    });
  };

  const startWalking = (roll: number) => {
    const activePlayer = players[activePlayerIdx];
    setIsWalking(true);
    setMovesRemaining(roll);
    setCurrentWalkingNodeId(activePlayer.currentNodeId);
    setMoveHistory([]);
  };

  const handleTakeStep = (targetNodeId: string) => {
    if (!isWalking) return;

    // Check if we are backtracking to the immediate previous node in our move history
    const isBacktracking = moveHistory.length > 0 && targetNodeId === moveHistory[moveHistory.length - 1];

    const fromNode = nodes.find(n => n.id === currentWalkingNodeId);
    const toNode = nodes.find(n => n.id === targetNodeId);
    let newDirection: 'down' | 'left' | 'right' | 'up' = 'down';
    if (fromNode && toNode) {
      const dx = toNode.x - fromNode.x;
      const dy = toNode.y - fromNode.y;
      if (Math.abs(dx) > Math.abs(dy)) {
        newDirection = dx > 0 ? 'right' : 'left';
      } else {
        newDirection = dy > 0 ? 'down' : 'up';
      }
    }

    if (isBacktracking) {
      // BACKTRACK/UNDO step in Dokapon movement style
      setMoveHistory(prev => prev.slice(0, -1));
      setCurrentWalkingNodeId(targetNodeId);
      setMovesRemaining(prev => prev + 1);
      setPlayers(prevPlayers => prevPlayers.map((p, idx) => {
        if (idx === activePlayerIdx) {
          return { ...p, direction: newDirection };
        }
        return p;
      }));
      addLog(`🚶 Возврат назад на клетку: [${nodes.find(n => n.id === targetNodeId)?.name || targetNodeId}] (шагов восстановлено: +1)`);
    } else {
      // Normal forward step
      setMoveHistory(prev => [...prev, currentWalkingNodeId]);
      setCurrentWalkingNodeId(targetNodeId);
      setPlayers(prevPlayers => prevPlayers.map((p, idx) => {
        if (idx === activePlayerIdx) {
          return { ...p, direction: newDirection };
        }
        return p;
      }));
      setMovesRemaining(prev => {
        const nextRemaining = prev - 1;
        if (nextRemaining === 0) {
          // Stopped walking, finalize position
          setIsWalking(false);
          setPlayers(prevPlayers => prevPlayers.map((p, idx) => {
            if (idx === activePlayerIdx) {
              return { ...p, currentNodeId: targetNodeId, direction: newDirection };
            }
            return p;
          }));
          
          // Trigger land action delay
          setTimeout(() => handleLandingAction(targetNodeId), 500);
        }
        return nextRemaining;
      });
    }
  };

  const handleResetMove = () => {
    const activePlayer = players[activePlayerIdx];
    setCurrentWalkingNodeId(activePlayer.currentNodeId);
    setMovesRemaining(diceRoll);
    setMoveHistory([]);
  };

  // --- AI Automated turn script ---
  const handleAiTurn = (aiPlayer: Player) => {
    addLog(`🤖 ИИ Робот ${aiPlayer.shamedName || aiPlayer.name} думает над ходом...`);
    
    // 1. AI might decide to use a healing potion if health is under 40%
    const hpPercent = aiPlayer.stats.hp / aiPlayer.stats.maxHp;
    const potion = aiPlayer.items.find(it => it.type === 'heal');
    if (hpPercent < 0.4 && potion) {
      handleUseItem(potion.id);
      setTimeout(() => handleAiTurn(players[activePlayerIdx]), 1000);
      return;
    }

    // 2. Roll dice with beautiful animation
    const roll = Math.floor(Math.random() * 6) + 1;
    addLog(`🎲 Робот ${aiPlayer.shamedName || aiPlayer.name} запускает спиннер...`);
    
    setDiceRoll(roll);
    runRollAnimation(roll, true, () => {
      addLog(`🎲 Робот выбросил число: ${roll}!`);
      
      // Calculate reachable nodes for AI
      const reachable = getReachableNodes(aiPlayer.currentNodeId, roll);
      if (reachable.length > 0) {
        // Prioritize Towns, Shops, Chests, or King's Castle
        let targetNodeId = reachable[0];
        const priorityNode = reachable.find(nodeId => {
          const n = nodes.find(cell => cell.id === nodeId);
          return n && (n.type === 'town' || n.type === 'shop' || n.type === 'king_castle');
        });
        
        if (priorityNode) {
          targetNodeId = priorityNode;
        } else {
          // select random
          targetNodeId = reachable[Math.floor(Math.random() * reachable.length)];
        }

        // Complete AI walk instantly and calculate direction
        const fromNode = nodes.find(n => n.id === aiPlayer.currentNodeId);
        const toNode = nodes.find(n => n.id === targetNodeId);
        let aiDirection: 'down' | 'left' | 'right' | 'up' = 'down';
        if (fromNode && toNode) {
          const dx = toNode.x - fromNode.x;
          const dy = toNode.y - fromNode.y;
          if (Math.abs(dx) > Math.abs(dy)) {
            aiDirection = dx > 0 ? 'right' : 'left';
          } else {
            aiDirection = dy > 0 ? 'down' : 'up';
          }
        }

        setPlayers(prev => prev.map((p, idx) => idx === activePlayerIdx ? { ...p, currentNodeId: targetNodeId, direction: aiDirection } : p));
        
        const targetCell = nodes.find(n => n.id === targetNodeId);
        addLog(`🚶 Робот перешел на клетку: [${targetCell?.name || targetNodeId}]`);
        
        setTimeout(() => handleLandingAction(targetNodeId), 1000);
      } else {
        // Safety failback
        endTurn();
      }
    });
  };

  // --- TRIGGER LANDING ACTIONS ---
  const handleLandingAction = (nodeId: string) => {
    const activePlayer = players[activePlayerIdx];
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;

    addLog(`📍 Лэндминг! Игрок ${activePlayer.shamedName || activePlayer.name} приземлился на клетке: [${node.name}]!`);

    // PvP Check - did we land on another alive player?
    const otherPlayersOnNode = players.filter(p => p.id !== activePlayer.id && p.currentNodeId === nodeId && !p.isDead);
    if (otherPlayersOnNode.length > 0) {
      const pvpTarget = otherPlayersOnNode[0];
      addLog(`⚔️ ДУЭЛЬ СТОЛКНОВЕНИЯ! Игрок ${activePlayer.shamedName || activePlayer.name} развязал PvP-бой с соперником ${pvpTarget.shamedName || pvpTarget.name}!`);
      
      setCombatOpponent(pvpTarget);
      setIsCombatOpponentPlayer(true);
      return;
    }

    // Standard Cell Action Triggers
    switch (node.type) {
      case 'king_castle':
        // Check King Quest Reward first
        if (!kingFirstReachClaimed) {
          addLog(`👑 ТРИУМФ! Игрок ${activePlayer.shamedName || activePlayer.name} ПЕРВЫМ пробился в Королевский Замок Короля! Награда в +10 свободных очков характеристик разблокирована!`);
          setKingFirstReachClaimed(true);
          setKingWinnerName(activePlayer.shamedName || activePlayer.name);
          
          // Trigger reward points distribution
          setPlayers(prev => prev.map((p, idx) => idx === activePlayerIdx ? { ...p, statPoints: p.statPoints + 10 } : p));
          setIsKingRewardAllocation(true);
          setActiveStatDistPlayerId(activePlayer.id);
        } else {
          // Re-visiting King's Castle later: triggers the Final boss combat to save the whole kingdom!
          addLog(`🏯 Тёмный Лорд Бальтазар 👹 оккупировал тронный зал! Вы должны сразить его в битве за судьбу Dokapon!`);
          setCombatOpponent(KING_MONSTER);
          setIsCombatOpponentPlayer(false);
          setCombatTownNodeId(node.id);
        }
        break;

      case 'shop':
        if (activePlayer.isAi) {
          // AI purchases weapon/shield automatically if has enough gold
          const canAffordWeapon = activePlayer.gold >= 400;
          if (canAffordWeapon) {
            activePlayer.gold -= 400;
            activePlayer.weapon = { id: 'ai-w', name: 'Рыцарский Меч ⚔️', type: 'weapon', bonusAtk: 12, bonusDef: 0, bonusMg: 0, bonusSpd: 0, cost: 400, description: 'Куплено автопилотом ИИ.' };
            addLog(`🤖 Робот ИИ прикупил крутой Рыцарский Меч!`);
          }
          endTurn();
        } else {
          setActiveShopPlayerId(activePlayer.id);
        }
        break;

      case 'chest':
        // Give randomized chest loot
        const rand = Math.random();
        if (rand < 0.3) {
          // Gold chest
          const goldBonus = Math.floor(Math.random() * 150) + 100;
          addLog(`🎁 Сундук оказался золотым! Получено +${goldBonus} монет!`);
          setPlayers(prev => prev.map((p, idx) => idx === activePlayerIdx ? { ...p, gold: p.gold + goldBonus } : p));
          endTurn();
        } else if (rand < 0.6) {
          // Item chest
          const randomItem = ITEMS_DB[Math.floor(Math.random() * ITEMS_DB.length)];
          if (activePlayer.items.length < 6) {
            addLog(`🎁 Найдена походная посылка! Получен предмет: [${randomItem.name}]!`);
            setPlayers(prev => prev.map((p, idx) => idx === activePlayerIdx ? { ...p, items: [...p.items, randomItem] } : p));
          } else {
            addLog(`🎁 Найдено лечебное зелье, но сумка полна. Оно вылилось на землю...`);
          }
          endTurn();
        } else if (rand < 0.8) {
          // Spell chest
          const randomSpell = SPELLS_DB[Math.floor(Math.random() * SPELLS_DB.length)];
          if (!activePlayer.spells.some(s => s.id === randomSpell.id)) {
            addLog(`🎁 Обнаружен тайный свиток! Вы изучили заклинание: [${randomSpell.name}]!`);
            setPlayers(prev => prev.map((p, idx) => idx === activePlayerIdx ? { ...p, spells: [...p.spells, randomSpell] } : p));
          } else {
            addLog(`🎁 Найдена книга заклинаний, но вы уже знаете эту магию.`);
          }
          endTurn();
        } else {
          // Trap chest!
          addLog(`💥 ОШИБКА! Сундук был заминирован коварной ловушкой с шипами! Игрок получил 20 ед. урона!`);
          setPlayers(prev => prev.map((p, idx) => {
            if (idx === activePlayerIdx) {
              const nextHp = Math.max(1, p.stats.hp - 20); // doesn't fully kill from chest
              return { ...p, stats: { ...p.stats, hp: nextHp } };
            }
            return p;
          }));
          endTurn();
        }
        break;

      case 'town':
        // Landed on a village node
        if (node.townMonster) {
          // Town is under siege! Fight the garrison boss to liberate it
          addLog(`👹 Поселение ${node.name} захвачено грозным чудовищем: [${node.townMonster.name}]! Вступите в бой для спасения деревни!`);
          setCombatOpponent(node.townMonster);
          setIsCombatOpponentPlayer(false);
          setCombatTownNodeId(node.id);
        } else {
          // Town is already liberated. Who owns it?
          if (node.townOwnerId === activePlayer.id) {
            // Landing on your own town heals you!
            addLog(`🏡 Вы зашли в свою собственную деревню. Жители радостно приветствуют вас и лечат ваши раны! (+30 ОЗ)`);
            setPlayers(prev => prev.map((p, idx) => idx === activePlayerIdx ? {
              ...p,
              stats: { ...p.stats, hp: Math.min(p.stats.maxHp, p.stats.hp + 30) }
            } : p));
            endTurn();
          } else if (node.townOwnerId) {
            // Landing on someone else's town: pay tax/fee!
            const owner = players.find(p => p.id === node.townOwnerId);
            const taxAmount = node.townTax || 50;
            addLog(`💸 ПОШЛИНА! Вы зашли в деревню, которой владеет ${owner?.shamedName || owner?.name}! Вы обязаны заплатить налог в ${taxAmount} золотых!`);
            
            setPlayers(prev => prev.map(p => {
              if (p.id === activePlayer.id) {
                return { ...p, gold: Math.max(0, p.gold - taxAmount) };
              }
              if (p.id === owner?.id) {
                return { ...p, gold: p.gold + taxAmount };
              }
              return p;
            }));
            endTurn();
          } else {
            // Free town, no monster, somehow. (Fallback)
            endTurn();
          }
        }
        break;

      default:
        // Empty node: 55% chance Wild monster, 45% random world event
        const r = Math.random();
        if (r < 0.55) {
          const wildMonster = MONSTERS_POOL[Math.floor(Math.random() * MONSTERS_POOL.length)];
          addLog(`🌲 Из кустов выпрыгнул голодный дикий монстр: [${wildMonster.name}]! Начинается пошаговая битва!`);
          setCombatOpponent(wildMonster);
          setIsCombatOpponentPlayer(false);
        } else {
          // Random Event card
          triggerRandomKingdomEvent(activePlayer);
        }
        break;
    }
  };

  // --- Process Random World Events on Empty cells ---
  const triggerRandomKingdomEvent = (player: Player) => {
    const events = [
      {
        text: 'Королевский караван потерял ящик с драгоценностями! Вы нашли золотой слиток. (+150 Золота)',
        apply: (p: Player) => ({ ...p, gold: p.gold + 150 })
      },
      {
        text: 'Таинственная лесная фея взмахнула волшебной палочкой и укрепила ваши мышцы! (+2 к силе Атаки!)',
        apply: (p: Player) => ({ ...p, stats: { ...p.stats, atk: p.stats.atk + 2 } })
      },
      {
        text: 'Гоблин-воришка скрытно срезал лямку вашего кошелька во время сна... (-100 Золота)',
        apply: (p: Player) => ({ ...p, gold: Math.max(0, p.gold - 100) })
      },
      {
        text: 'Вы выпили чистейшей родниковой воды из Волшебного Источника! (+20 ОЗ)',
        apply: (p: Player) => ({ ...p, stats: { ...p.stats, hp: Math.min(p.stats.maxHp, p.stats.hp + 20) } })
      }
    ];

    const chosen = events[Math.floor(Math.random() * events.length)];
    addLog(`✨ СОБЫТИЕ: ${chosen.text}`);
    
    setPlayers(prev => prev.map((p, idx) => idx === activePlayerIdx ? chosen.apply(p) : p));
    endTurn();
  };

  // --- COMBAT RESOLUTION HANDLERS ---
  const handleCombatEnd = (result: {
    winnerId: string;
    loserId: string;
    goldChange: number;
    expChange: number;
    townLiberated: boolean;
    shameAction?: 'steal_gold' | 'steal_town' | 'steal_item' | 'shame_name' | null;
    shameNewName?: string | null;
  }) => {
    const activePlayer = players[activePlayerIdx];

    // Determine if player won
    const playerWon = result.winnerId === activePlayer.id;

    if (playerWon) {
      addLog(`🏆 ПОБЕДА! ${activePlayer.shamedName || activePlayer.name} одолел противника в битве! Получено +${result.goldChange} зол. и +${result.expChange} EXP.`);
      
      // Update players state for experience, level ups, and gold
      setPlayers(prev => prev.map(p => {
        if (p.id === activePlayer.id) {
          let nextExp = p.exp + result.expChange;
          let nextLevel = p.level;
          let nextStatPoints = p.statPoints;
          const classDef = CLASS_DEFINITIONS[p.classType];
          
          // Level up math
          if (nextExp >= p.level * 100) {
            nextExp -= p.level * 100;
            nextLevel += 1;
            nextStatPoints += 3; // +3 free stat points per level up
            addLog(`⭐️ ПОВЫШЕНИЕ УРОВНЯ! Игрок ${p.shamedName || p.name} достиг Уровня ${nextLevel}! Получено +3 очка характеристик для распределения.`);
            
            // Queue Stat points distribution modal
            setTimeout(() => {
              setActiveStatDistPlayerId(p.id);
            }, 1000);
          }

          return {
            ...p,
            gold: p.gold + result.goldChange,
            exp: nextExp,
            level: nextLevel,
            statPoints: nextStatPoints
          };
        }

        // If lost player in PvP: reduce their gold or apply toxic modifiers
        if (isCombatOpponentPlayer && p.id === (combatOpponent as Player).id) {
          let updatedName = p.shamedName;
          let updatedTowns = [...p.townsOwned];

          if (result.shameAction === 'shame_name' && result.shameNewName) {
            updatedName = result.shameNewName;
            addLog(`🤡 КЛЕЙМО ПОЗОРА! Проигравший игрок переименован в "${result.shameNewName}"!`);
          } else if (result.shameAction === 'steal_town' && updatedTowns.length > 0) {
            const stolenTownId = updatedTowns.pop();
            // Assign town to winner
            setTimeout(() => {
              setNodes(prevNodes => prevNodes.map(n => n.id === stolenTownId ? { ...n, townOwnerId: activePlayer.id } : n));
              setPlayers(allP => allP.map(playerItem => {
                if (playerItem.id === activePlayer.id && stolenTownId) {
                  return { ...playerItem, townsOwned: [...playerItem.townsOwned, stolenTownId] };
                }
                return playerItem;
              }));
            }, 500);
            addLog(`🏡 КОНФИСКАЦИЯ! Победитель отобрал владение одной из освобожденных деревень проигравшего!`);
          }

          return {
            ...p,
            isDead: true,
            reviveInTurns: 2, // воскреснет через 2 хода
            gold: Math.max(0, p.gold - result.goldChange),
            shamedName: updatedName,
            townsOwned: updatedTowns
          };
        }

        return p;
      }));

      // If it was a Garrison Town Boss, liberate the Town!
      if (result.townLiberated && combatTownNodeId) {
        addLog(`🎉 ДЕРЕВНЯ ОСВОБОЖДЕНА! Вы спасли жителей! Локация переходит под ваше покровительство и приносит регулярный налог.`);
        
        setNodes(prev => prev.map(n => n.id === combatTownNodeId ? { ...n, townMonster: null, townOwnerId: activePlayer.id } : n));
        setPlayers(prev => prev.map(p => p.id === activePlayer.id ? { ...p, townsOwned: [...p.townsOwned, combatTownNodeId] } : p));
      }

      // If it was the final boss sitting in King's Castle, we win the entire tournament!
      if (combatTownNodeId === 'king_castle') {
        addLog(`👑🏆 ВЕЛИКИЙ ТРИУМФ! Темный Лорд Бальтазар повержен! Игрок ${activePlayer.shamedName || activePlayer.name} объявлен Спасителем Королевства Dokapon!`);
        setFinalWinner(activePlayer);
        setGameStage('game_over');
      }

    } else {
      // Player lost the combat!
      addLog(`💀 ПОРАЖЕНИЕ! Игрок ${activePlayer.shamedName || activePlayer.name} пал без чувств в суровом бою!`);
      
      setPlayers(prev => prev.map(p => {
        if (p.id === activePlayer.id) {
          return {
            ...p,
            isDead: true,
            reviveInTurns: 2, // 2 turns of skip to recover
            gold: Math.max(0, p.gold + result.goldChange) // negative gold change subtracted
          };
        }
        
        // If PvP and AI opponent won, update winner
        if (isCombatOpponentPlayer && p.id === (combatOpponent as Player).id) {
          return {
            ...p,
            gold: p.gold - result.goldChange // winner gains the gold
          };
        }
        return p;
      }));
    }

    // Clear battle overlay & proceed
    setCombatOpponent(null);
    setCombatTownNodeId(undefined);
    
    // Slight delay to allow logs reading
    setTimeout(() => {
      endTurn();
    }, 1500);
  };

  // --- SHOP SCREEN PURCHASES ---
  const handleBuyEquipment = (eq: Equipment) => {
    setPlayers(prev => prev.map(p => {
      if (p.id === activeShopPlayerId) {
        const nextGold = p.gold - eq.cost;
        if (eq.type === 'weapon') {
          return { ...p, gold: nextGold, weapon: eq };
        } else {
          return { ...p, gold: nextGold, shield: eq };
        }
      }
      return p;
    }));
  };

  const handleBuySpell = (spell: MagicSpell) => {
    setPlayers(prev => prev.map(p => {
      if (p.id === activeShopPlayerId) {
        return {
          ...p,
          gold: p.gold - spell.cost,
          spells: [...p.spells, spell]
        };
      }
      return p;
    }));
  };

  const handleBuyItem = (item: UsableItem) => {
    setPlayers(prev => prev.map(p => {
      if (p.id === activeShopPlayerId) {
        return {
          ...p,
          gold: p.gold - item.cost,
          items: [...p.items, item]
        };
      }
      return p;
    }));
  };

  // --- STAT POINTS ALLOCATION ---
  const handleStatConfirm = (allocatedStats: Stats, remainingPoints: number) => {
    setPlayers(prev => prev.map(p => {
      if (p.id === activeStatDistPlayerId) {
        addLog(`💪 Характеристики игрока ${p.shamedName || p.name} успешно обновлены!`);
        return {
          ...p,
          stats: allocatedStats,
          statPoints: remainingPoints
        };
      }
      return p;
    }));

    setActiveStatDistPlayerId(null);
    setIsKingRewardAllocation(false);
  };

  if (gameStage === 'map_editor') {
    return <MapEditor lang={lang} onBackToMenu={() => setGameStage('main_menu')} />;
  }

  if (gameStage === 'intro') {
    return (
      <div 
        id="intro-screen"
        className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center font-sans p-6 relative overflow-hidden select-none cursor-pointer"
      >
        {/* Animated background stars/pixels */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.06)_0%,transparent_70%)] animate-pulse" style={{ animationDuration: '4s' }} />
        <div className="absolute top-10 left-1/4 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-10 right-1/4 w-72 h-72 bg-blue-500/5 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '3s' }} />

        {/* Console game intro container */}
        <div className="text-center max-w-xl w-full z-10 flex flex-col items-center gap-10">
          
          {/* Developer watermark */}
          <div className="animate-fade-in py-1.5 px-4 bg-slate-900/80 border border-slate-800 rounded-full text-[10px] font-black uppercase tracking-[0.25em] text-amber-500 font-mono shadow-md">
            {t.creator}
          </div>

          {/* Title branding logo */}
          <div className="space-y-2 transform transition-transform hover:scale-105 duration-300">
            <h1 className="text-6xl md:text-7xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 font-display drop-shadow-[0_10px_20px_rgba(245,158,11,0.3)] select-none uppercase">
              {t.gameTitle}
            </h1>
            <p className="text-xs uppercase font-mono tracking-[0.3em] text-slate-400 font-bold">
              Retro JRPG Edition
            </p>
          </div>

          {/* Custom Video Placeholder notice */}
          <div className="w-full max-w-sm p-6 bg-slate-900/60 border-2 border-dashed border-slate-800 rounded-3xl flex flex-col items-center justify-center gap-2 shadow-inner group hover:border-slate-700 transition-all">
            <span className="text-2xl animate-bounce">🎬</span>
            <p className="text-xs font-semibold text-slate-400 text-center leading-relaxed">
              {t.futureVideo}
            </p>
            <span className="text-[9px] font-mono text-slate-600 uppercase font-black tracking-wider mt-1">
              [ video slot reserved ]
            </span>
          </div>

          {/* Pulsing prompt to continue */}
          <div className="mt-6 flex flex-col items-center gap-2">
            <div className="text-xs font-mono font-black text-amber-400 tracking-[0.15em] uppercase animate-pulse select-none">
              &gt; {t.pressAnyKey} &lt;
            </div>
            <span className="text-[10px] text-slate-500 font-medium">
              (click anywhere or press keyboard button)
            </span>
          </div>

        </div>

        {/* Footer copyright */}
        <div className="absolute bottom-6 text-[10px] font-mono text-slate-600 font-bold uppercase tracking-widest">
          © 2026 • marazay interactive
        </div>
      </div>
    );
  }

  if (gameStage === 'main_menu') {
    return (
      <div 
        id="main-menu-screen"
        className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between font-sans p-6 relative overflow-hidden select-none"
      >
        <div className="absolute top-0 left-0 w-full h-full bg-[linear-gradient(rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none" />

        {/* Top bar settings / language switcher */}
        <header className="w-full max-w-4xl mx-auto flex justify-between items-center z-10">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-amber-500" />
            <span className="font-mono text-xs font-black tracking-widest text-slate-400 uppercase">SYS_VERSION_6.0</span>
          </div>

          {/* Inline Language switcher */}
          <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setLang('ru')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                lang === 'ru' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              РУС 🇷🇺
            </button>
            <button
              onClick={() => setLang('en')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                lang === 'en' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              ENG 🇬🇧
            </button>
          </div>
        </header>

        {/* Main Content menu cards */}
        <main className="w-full max-w-md mx-auto z-10 flex flex-col items-center gap-10 my-auto">
          
          {/* Game Brand */}
          <div className="text-center space-y-1">
            <h1 className="text-5xl md:text-6xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 uppercase font-display">
              {t.gameTitle}
            </h1>
            <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500 font-bold">
              {t.creator}
            </p>
          </div>

          {/* Menu Options */}
          <div className="w-full space-y-3">
            
            {/* Enter/Play option */}
            <button
              onClick={() => setGameStage('setup')}
              className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-sm uppercase tracking-wider rounded-2xl shadow-xl shadow-amber-500/10 hover:scale-[1.02] transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <Play className="w-5 h-5 text-slate-950 fill-slate-950" />
                <span>{t.enter}</span>
              </div>
              <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
            </button>

            {/* Map Creator Option */}
            <button
              onClick={() => setGameStage('map_editor')}
              className="w-full py-4 px-6 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 font-black text-sm uppercase tracking-wider rounded-2xl hover:scale-[1.02] transition-all cursor-pointer flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <LayoutGrid className="w-5 h-5 text-amber-500" />
                <span>{t.mapEditorBtn}</span>
              </div>
              <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 py-0.5 px-2 rounded-md font-mono uppercase">
                Creator
              </span>
            </button>

            {/* Exit/Back option */}
            <button
              onClick={() => {
                if (window.confirm(t.exitMessage)) {
                  setGameStage('intro');
                }
              }}
              className="w-full py-3 px-6 bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-500 hover:text-slate-400 font-bold text-xs uppercase tracking-wider rounded-2xl transition-colors cursor-pointer flex items-center gap-3"
            >
              <LogOut className="w-4 h-4" />
              <span>{t.exit}</span>
            </button>

          </div>

        </main>

        {/* Footer */}
        <footer className="w-full max-w-4xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2 border-t border-slate-900 pt-4 text-[10px] font-mono text-slate-600 uppercase font-black tracking-widest z-10">
          <div>{t.creator}</div>
          <div>DocoPixel6 • build v6.0</div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 flex flex-col justify-between">
      
      {/* Visual Header */}
      <header className="bg-slate-900 border-b border-slate-800 py-4 px-6 flex justify-between items-center shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-tr from-amber-500 to-yellow-600 rounded-xl text-slate-950 shadow-lg shadow-amber-500/20">
            <Swords className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-display font-black text-2xl text-slate-100 tracking-tight flex items-center gap-2">
              DOCOPIXEL6 <span className="text-amber-400 font-bold text-sm bg-amber-500/10 py-0.5 px-2 rounded border border-amber-500/20">JRPG</span>
            </h1>
            <p className="text-xs text-slate-400 font-medium">{lang === 'ru' ? 'Культовая настольная RPG-игра в вашем браузере' : 'Legendary RPG board game adventure in your browser'}</p>
          </div>
        </div>

        {gameStage === 'setup' && (
          <button
            onClick={() => setGameStage('main_menu')}
            className="py-1.5 px-3 bg-slate-950 hover:bg-slate-900 text-slate-300 rounded-xl transition-all font-semibold cursor-pointer border border-slate-800 text-xs flex items-center gap-1 shadow-md"
          >
            ← {t.back}
          </button>
        )}

        {gameStage === 'playing' && (
          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5 bg-slate-950/60 border border-slate-800 py-1.5 px-3 rounded-xl">
              <span className="text-slate-500 font-bold uppercase">{lang === 'ru' ? 'Раунд:' : 'Round:'}</span>
              <span className="text-slate-200 font-bold"># {players[activePlayerIdx]?.level || 1}</span>
            </div>
            {isResetConfirming ? (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    setIsResetConfirming(false);
                    setGameStage('main_menu');
                  }}
                  className="py-1.5 px-3 bg-red-600 hover:bg-red-500 text-white rounded-xl transition-all font-semibold cursor-pointer border border-red-500/30"
                >
                  {lang === 'ru' ? 'Да, выйти' : 'Yes, Exit'}
                </button>
                <button
                  onClick={() => setIsResetConfirming(false)}
                  className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all font-semibold cursor-pointer border border-slate-700"
                >
                  {lang === 'ru' ? 'Отмена' : 'Cancel'}
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsResetConfirming(true)}
                className="py-1.5 px-3 bg-red-950/40 hover:bg-red-900/40 text-red-400 rounded-xl transition-all font-semibold cursor-pointer border border-red-500/20"
              >
                {t.resetBtn}
              </button>
            )}
          </div>
        )}
      </header>

      {/* --- SETUP SCREEN --- */}
      {gameStage === 'setup' && (
        <main className="flex-1 max-w-4xl w-full mx-auto p-6 flex flex-col justify-center items-center">
          <div className="bg-slate-900 border-2 border-slate-800/80 rounded-3xl p-8 shadow-2xl w-full relative overflow-hidden">
            
            {/* Background design accents */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl" />

            <div className="text-center mb-6">
              <h2 className="font-display text-3xl font-black text-slate-100 tracking-tight">{t.startCampaign}</h2>
              <p className="text-sm text-slate-400 mt-1 max-w-xl mx-auto">
                {t.setupDesc}
              </p>
            </div>

            {/* Player Count Selection Picker */}
            <div className="flex flex-col items-center justify-center mb-8 bg-slate-950/50 border border-slate-800/80 p-4 rounded-2xl max-w-md mx-auto shadow-inner relative z-10">
              <span className="text-[10px] font-mono font-black uppercase tracking-[0.2em] text-amber-400 mb-2.5">
                {lang === 'ru' ? 'КОЛИЧЕСТВО ИГРОКОВ (ОТ 2 ДО 6)' : 'NUMBER OF PLAYERS (2 TO 6)'}
              </span>
              <div className="flex gap-2">
                {[2, 3, 4, 5, 6].map(num => (
                  <button
                    key={num}
                    onClick={() => handleSetPlayerCount(num)}
                    className={`w-11 h-11 rounded-xl font-display font-black text-sm transition-all flex items-center justify-center border cursor-pointer ${
                      setupPlayers.length === num
                        ? 'bg-gradient-to-br from-amber-400 to-amber-600 border-amber-300 text-slate-950 shadow-lg shadow-amber-500/10 scale-110 font-black'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {setupPlayers.map((p, idx) => (
                <div key={idx} className="bg-slate-950/60 p-5 rounded-2xl border border-slate-800 hover:border-slate-700/80 transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs uppercase font-mono font-extrabold text-amber-500">{t.hero} {idx + 1}</span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSetupPlayers(prev => prev.map((item, i) => i === idx ? { ...item, isAi: false } : item))}
                          className={`px-2 py-1 rounded text-[10px] font-bold font-mono transition-colors cursor-pointer ${
                            !p.isAi ? 'bg-emerald-500 text-slate-950' : 'bg-slate-900 text-slate-400'
                          }`}
                        >
                          👥 ИГРОК
                        </button>
                        <button
                          onClick={() => setSetupPlayers(prev => prev.map((item, i) => i === idx ? { ...item, isAi: true } : item))}
                          className={`px-2 py-1 rounded text-[10px] font-bold font-mono transition-colors cursor-pointer ${
                            p.isAi ? 'bg-indigo-500 text-slate-950' : 'bg-slate-900 text-slate-400'
                          }`}
                        >
                          🤖 БОТ ИИ
                        </button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex gap-3 items-end">
                        <div className="flex-1">
                          <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1.5 font-bold">{t.charName}</label>
                          <input
                            type="text"
                            value={p.name}
                            onChange={(e) => setSetupPlayers(prev => prev.map((item, i) => i === idx ? { ...item, name: e.target.value } : item))}
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 font-semibold focus:outline-none focus:border-amber-500"
                          />
                        </div>

                        <div className="flex flex-col items-center">
                          <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1.5 font-bold text-center">{t.skin}</label>
                          <button
                            onClick={() => setSelectedSetupPlayerForSkin(idx)}
                            className="w-10 h-10 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-center hover:border-amber-400 cursor-pointer group transition-all relative overflow-hidden"
                            title="Сменить скин"
                          >
                            <CharacterSkin skinIndex={p.skinIndex || (idx + 1)} size="md" animate={true} />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-[8px] font-bold text-white uppercase">
                              {t.skin}
                            </div>
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1.5 font-bold">{t.chooseClass}</label>
                        <div className="grid grid-cols-2 gap-2">
                          {(['warrior', 'mage', 'thief', 'cleric'] as ClassType[]).map(ct => (
                            <button
                              key={ct}
                              onClick={() => setSetupPlayers(prev => prev.map((item, i) => i === idx ? { ...item, classType: ct } : item))}
                              className={`py-2 px-3 border rounded-xl text-left font-display font-bold text-xs transition-all cursor-pointer ${
                                p.classType === ct
                                  ? 'bg-amber-500/10 border-amber-400/80 text-amber-300'
                                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-850'
                              }`}
                            >
                              {lang === 'ru' ? CLASS_DEFINITIONS[ct].nameRu : CLASS_DEFINITIONS[ct].nameEn}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 italic mt-3 line-clamp-2">
                    {lang === 'ru' ? CLASS_DEFINITIONS[p.classType].descriptionRu : CLASS_DEFINITIONS[p.classType].descriptionEn}
                  </p>
                </div>
              ))}
            </div>

            {/* Map Selection Option */}
            <div className="mt-8 bg-slate-950/60 p-5 rounded-2xl border border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="flex items-center gap-3">
                <MapPin className="w-8 h-8 text-amber-500" />
                <div className="text-left">
                  <h3 className="text-sm font-black text-slate-100">{t.chooseMap}</h3>
                  <p className="text-[11px] text-slate-400">{lang === 'ru' ? 'Выберите стандартный мир или одну из ваших созданных карт' : 'Select the default world or one of your custom-designed maps'}</p>
                </div>
              </div>

              <select
                value={selectedMapId}
                onChange={(e) => setSelectedMapId(e.target.value)}
                className="bg-slate-900 border border-slate-800 text-xs font-bold text-slate-200 py-2.5 px-4 rounded-xl focus:outline-none focus:border-amber-500 cursor-pointer w-full sm:w-64"
              >
                <option value="default">🗺️ {t.standardMap} ({MAP_NODES.length} {t.numNodes})</option>
                {availableMaps.map(map => (
                  <option key={`game-map-opt-${map.id}`} value={map.id}>
                    🛠️ {map.name} ({map.nodes.length} {t.numNodes})
                  </option>
                ))}
              </select>
            </div>

            <div className="mt-8 border-t border-slate-800 pt-6 text-center">
              <button
                onClick={startGame}
                className="py-4 px-12 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-extrabold text-md rounded-2xl cursor-pointer shadow-xl shadow-amber-500/20 hover:scale-103 transition-all uppercase tracking-wider flex items-center gap-2.5 mx-auto"
              >
                <Play className="w-5 h-5" />
                {t.startAdventure}
              </button>
            </div>

          </div>
        </main>
      )}

      {/* --- PLAYING SCREEN --- */}
      {gameStage === 'playing' && (
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col gap-6">
          
          {/* Active Player Comeback/Darkling Option Helper */}
          {players[activePlayerIdx] && !players[activePlayerIdx].isAi && !players[activePlayerIdx].isDarkling && (
            // Last place can turn into a Darkling
            [...players].sort((a,b) => b.gold - a.gold)[players.length - 1]?.id === players[activePlayerIdx].id && (
              <div className="bg-purple-950/40 border border-purple-500/30 p-3.5 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-3 animate-fade-in">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">😈</span>
                  <div>
                    <h4 className="font-display font-extrabold text-purple-300 text-sm">Пакт Опустошителя Бездны!</h4>
                    <p className="text-xs text-slate-400">Поскольку вы отстаете в соревновании, вы можете добровольно трансформироваться в Темного Властелина!</p>
                  </div>
                </div>
                <button
                  onClick={() => triggerDarklingTransformation(players[activePlayerIdx].id)}
                  className="py-1.5 px-4 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-500/20 transition-all cursor-pointer"
                >
                  Принять Тёмную Сделку (+2x Сила!) 😈🔥
                </button>
              </div>
            )
          )}

          {/* Map and Controls Dashboard */}
          <MapBoard
            nodes={nodes}
            players={players}
            activePlayerId={players[activePlayerIdx]?.id}
            movesRemaining={movesRemaining}
            currentWalkingNodeId={currentWalkingNodeId}
            moveHistory={moveHistory}
            isWalking={isWalking}
            onTakeStep={handleTakeStep}
            onResetMove={handleResetMove}
            onUseItem={handleUseItem}
            onRollDice={handleRollDice}
            kingFirstReachClaimed={kingFirstReachClaimed}
            kingWinnerName={kingWinnerName}
            turnCount={turnCount}
          />

          {/* Bottom Live logs window */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col h-40">
            <span className="block text-[10px] uppercase font-mono tracking-wider text-slate-500 mb-2">📢 ЖУРНАЛ КОРОЛЕВСКИХ СОБЫТИЙ (GLOBAL EVENTS)</span>
            <div className="flex-1 overflow-y-auto space-y-1.5 text-xs font-mono text-slate-300 pr-1">
              {eventLogs.map((log, i) => (
                <div key={i} className="border-b border-slate-850 pb-1 last:border-0">
                  {log}
                </div>
              ))}
              <div ref={logsEndRef} />
            </div>
          </div>

        </main>
      )}

      {/* --- GAME OVER FINAL SCREEN --- */}
      {gameStage === 'game_over' && (
        <main className="flex-1 max-w-2xl w-full mx-auto p-6 flex flex-col justify-center items-center">
          <div className="bg-slate-900 border-4 border-amber-500 rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden w-full">
            <Trophy className="w-20 h-20 text-yellow-400 mx-auto animate-bounce mb-4" />
            <h2 className="font-display text-4xl font-black text-yellow-400 tracking-tight">КОРОНАЦИЯ СПАСИТЕЛЯ! 👑🎉</h2>
            <p className="text-slate-300 mt-2">
              Тёмный Лорд повержен, и в Dokapon Kingdom вновь воцарился вечный мир!
            </p>

            {finalWinner && (
              <div className="bg-slate-950/60 border border-amber-500/30 p-6 rounded-2xl my-6 max-w-md mx-auto">
                <span className="text-[10px] uppercase font-mono tracking-widest text-amber-500">ВЕЛИКИЙ ПОБЕДИТЕЛЬ</span>
                <h3 className="font-display font-black text-3xl text-slate-100 mt-1">{finalWinner.shamedName || finalWinner.name}</h3>
                <p className="text-xs text-amber-400 mt-1">{finalWinner.classType.toUpperCase()} • УРОВЕНЬ {finalWinner.level}</p>

                <div className="grid grid-cols-2 gap-3 mt-4 text-xs font-mono">
                  <div className="bg-slate-900 p-2.5 rounded-xl text-left border border-slate-800">
                    <span className="text-[9px] text-slate-500">Золотая Казна:</span>
                    <div className="font-bold text-amber-400 text-lg">{finalWinner.gold}</div>
                  </div>
                  <div className="bg-slate-900 p-2.5 rounded-xl text-left border border-slate-800">
                    <span className="text-[9px] text-slate-500">Владения деревень:</span>
                    <div className="font-bold text-slate-200 text-lg">{finalWinner.townsOwned.length}</div>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={() => setGameStage('setup')}
              className="py-3 px-8 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-sm rounded-xl cursor-pointer shadow-lg shadow-amber-500/20 uppercase"
            >
              Сыграть Снова! 🔄⚔️
            </button>
          </div>
        </main>
      )}

      {/* --- OVERLAY SCREENS --- */}

      {/* 1. Shop Screen overlay */}
      {activeShopPlayerId && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4 backdrop-blur-sm">
          <ShopScreen
            player={players.find(p => p.id === activeShopPlayerId)!}
            onBuyEquipment={handleBuyEquipment}
            onBuySpell={handleBuySpell}
            onBuyItem={handleBuyItem}
            onClose={() => {
              setActiveShopPlayerId(null);
              endTurn();
            }}
          />
        </div>
      )}

      {/* 2. Stat point allocation overlay */}
      {activeStatDistPlayerId && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4 backdrop-blur-sm">
          <StatDistribution
            player={players.find(p => p.id === activeStatDistPlayerId)!}
            title={isKingRewardAllocation ? "Королевское Благословение! 👑" : "Повышение Характеристик! 🎖️"}
            subtitle={isKingRewardAllocation ? "Вы первым дошли до Короля! Распределите супер-бонусные +10 очков!" : "Вы получили новый уровень! Распределите свободные очки."}
            onConfirm={handleStatConfirm}
          />
        </div>
      )}

      {/* 3. Combat Screen overlay */}
      {combatOpponent && (
        <CombatScreen
          player={players[activePlayerIdx]}
          opponent={combatOpponent}
          isOpponentPlayer={isCombatOpponentPlayer}
          townNodeId={combatTownNodeId}
          onCombatEnd={handleCombatEnd}
        />
      )}

      {/* 4. Skin Selector Modal */}
      {selectedSetupPlayerForSkin !== null && (
        <SkinSelectorModal
          playerName={setupPlayers[selectedSetupPlayerForSkin].name}
          currentSkinIndex={setupPlayers[selectedSetupPlayerForSkin].skinIndex}
          onSelectSkin={(skinIdx) => {
            setSetupPlayers(prev => prev.map((p, idx) => idx === selectedSetupPlayerForSkin ? { ...p, skinIndex: skinIdx } : p));
          }}
          onClose={() => setSelectedSetupPlayerForSkin(null)}
        />
      )}

      {/* 5. Giant Dice Roll Animation Overlay */}
      {isRollingDiceAnimation && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 flex flex-col items-center justify-center p-4 backdrop-blur-md animate-fade-in select-none">
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border-4 border-yellow-500 rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl flex flex-col items-center relative overflow-hidden">
            <div className="absolute -inset-10 bg-yellow-500/10 blur-3xl rounded-full animate-pulse" />
            
            <span className="block text-[11px] uppercase font-mono tracking-widest text-amber-400 mb-6 font-extrabold animate-pulse">
              {isAiRolling 
                ? (lang === 'ru' ? '🤖 ИИ КРУТИТ КУБИК!' : '🤖 AI IS SPINNING!') 
                : (lang === 'ru' ? '🎲 ВЫ КРУТИТЕ КУБИК!' : '🎲 YOU ARE SPINNING!')}
            </span>
            
            <div className={`my-6 transform transition-all duration-300 ${
              isDiceActivelySpinning 
                ? 'animate-dice-spin' 
                : 'scale-125 rotate-6 shadow-[0_25px_60px_rgba(239,68,68,0.7)]'
            }`}>
              <DiceFace value={diceAnimValue} />
            </div>
            
            <div className="mt-6 text-center">
              <div className="text-sm font-mono text-slate-400">
                {isAiRolling 
                  ? (lang === 'ru' ? 'Бот делает бросок...' : 'Bot is rolling...')
                  : (lang === 'ru' ? 'Раскручиваем спиннер!' : 'Spinning dice!')
                }
              </div>
              <div className="text-2xl font-display font-black text-white mt-1 animate-bounce">
                {diceAnimValue}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Simple decorative footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-3 px-6 text-center text-[10px] text-slate-500 font-mono tracking-wider">
        <span>РАЗРАБОТАНО ИГРОВЫМ ДИЗАЙНЕРОМ GOOGLE AI STUDIO • ДЛЯ НАСТОЯЩИХ ЛЮБИТЕЛЕЙ DOKAPON KINGDOM</span>
      </footer>

    </div>
  );
}

// Beautiful JRPG Red Dice Renderer with dynamic pips
function DiceFace({ value }: { value: number }) {
  const dotClass = "w-3 h-3 rounded-full bg-white shadow-sm";
  const emptyClass = "w-3 h-3";
  
  let layout: boolean[] = Array(9).fill(false);
  switch (value) {
    case 1:
      layout[4] = true;
      break;
    case 2:
      layout[0] = true;
      layout[8] = true;
      break;
    case 3:
      layout[0] = true;
      layout[4] = true;
      layout[8] = true;
      break;
    case 4:
      layout[0] = true;
      layout[2] = true;
      layout[6] = true;
      layout[8] = true;
      break;
    case 5:
      layout[0] = true;
      layout[2] = true;
      layout[4] = true;
      layout[6] = true;
      layout[8] = true;
      break;
    case 6:
      layout[0] = true;
      layout[2] = true;
      layout[3] = true;
      layout[5] = true;
      layout[6] = true;
      layout[8] = true;
      break;
    default:
      break;
  }

  if (value > 6) {
    return (
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-500 to-rose-700 border-4 border-white flex items-center justify-center text-3xl font-black text-white shadow-[0_10px_25px_rgba(244,63,94,0.5)] animate-bounce">
        {value}
      </div>
    );
  }

  return (
    <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-500 to-rose-700 border-4 border-white p-3 grid grid-cols-3 grid-rows-3 gap-1 shadow-[0_10px_25px_rgba(244,63,94,0.5)] justify-items-center items-center relative overflow-hidden">
      <div className="absolute inset-0.5 rounded-xl border border-red-400 pointer-events-none opacity-60" />
      {layout.map((hasPip, idx) => (
        <div key={idx} className={hasPip ? dotClass : emptyClass} />
      ))}
    </div>
  );
}
