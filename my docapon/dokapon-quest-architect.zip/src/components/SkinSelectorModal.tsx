import React, { useState } from 'react';
import CharacterSkin from './CharacterSkin';
import { Sparkles, X, ChevronRight } from 'lucide-react';

interface SkinSelectorModalProps {
  playerName: string;
  currentSkinIndex: number;
  onSelectSkin: (skinIndex: number) => void;
  onClose: () => void;
}

export default function SkinSelectorModal({
  playerName,
  currentSkinIndex,
  onSelectSkin,
  onClose
}: SkinSelectorModalProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [tempSkinIndex, setTempSkinIndex] = useState<number>(currentSkinIndex);

  // Generate all 32 skin indexes
  const totalSkins = 32;
  const skins = Array.from({ length: totalSkins }, (_, i) => i + 1);

  // Classy Russian descriptions or names for the skins to make it fun!
  const getSkinName = (idx: number) => {
    const names = [
      'Храбрый Рыцарь', 'Лесной Следопыт', 'Королевский Гвардеец', 'Принцесса Роза', 
      'Благородный Принц', 'Орден Паладинов', 'Чародей Стихий', 'Жрица Света',
      'Огненный Элементаль', 'Теневой Ниндзя', 'Вольный Пират', 'Морской Капитан',
      'Гном-Кузнец', 'Таинственный Друид', 'Лесной Эльф', 'Королевский Садовник',
      'Снежная Чародейка', 'Золотой Алхимик', 'Разбойник Пустошей', 'Караванный Торговец',
      'Королевский Шут', 'Мудрый Наставник', 'Воин Севера', 'Валькирия Ветров',
      'Демон Крови', 'Владыка Некрополя', 'Песчаный Скиталец', 'Гладиатор Арены',
      'Хранитель Леса', 'Монах Горного Клана', 'Королевский Казначей', 'Король Докапона'
    ];
    return names[idx - 1] || `Скин #${idx}`;
  };

  const handleConfirm = () => {
    onSelectSkin(tempSkinIndex);
    onClose();
  };

  return (
    <div 
      id="skin-selector-backdrop" 
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
    >
      {/* WHITE BACKGROUND MODAL as requested by the user */}
      <div 
        id="skin-selector-modal" 
        className="bg-white text-slate-900 border-4 border-amber-500 rounded-3xl p-6 shadow-2xl max-w-4xl w-full relative overflow-hidden flex flex-col md:flex-row gap-6 max-h-[90vh]"
      >
        {/* Subtle orange/gold decorative visual accents on the white canvas */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-yellow-500/5 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-950 rounded-full w-8 h-8 flex items-center justify-center cursor-pointer transition-colors border border-slate-200"
          title="Закрыть"
        >
          <X className="w-4 h-4" />
        </button>

        {/* LEFT COLUMN: Premium Selected Skin Interactive Preview Card */}
        <div className="w-full md:w-64 flex flex-col justify-between items-center bg-slate-50 rounded-2xl p-5 border border-slate-200/85">
          <div className="text-center w-full">
            <span className="text-[10px] font-black tracking-widest text-amber-600 bg-amber-50 py-1 px-3 rounded-full border border-amber-200 uppercase">
              Выбор Скина
            </span>
            <h3 className="font-display font-black text-lg text-slate-950 mt-2 truncate max-w-full">
              {playerName}
            </h3>
            <p className="text-[11px] text-slate-500 font-medium">
              Кастомизация внешности героя
            </p>
          </div>

          {/* Interactive Live Character Display box with a white pedestal */}
          <div className="my-6 flex flex-col items-center justify-center relative w-full h-44 bg-white rounded-2xl border-2 border-slate-200 shadow-inner overflow-hidden group">
            {/* Soft grid background representing character design stage */}
            <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
            
            {/* The character model */}
            <div className="transform scale-125 transition-transform group-hover:scale-135">
              <CharacterSkin 
                skinIndex={tempSkinIndex} 
                size="xl" 
                animate={true} 
              />
            </div>

            {/* Glowing isometric circle base */}
            <div className="w-16 h-4 bg-amber-500/10 border border-amber-500/30 rounded-full absolute bottom-4 blur-[1px]" />
          </div>

          <div className="w-full text-center">
            <h4 className="font-display font-extrabold text-sm text-slate-950 uppercase tracking-tight">
              {getSkinName(tempSkinIndex)}
            </h4>
            <p className="text-[10px] text-slate-400 mt-1">
              Скин №{tempSkinIndex} из 32 • Включает анимацию движения
            </p>
          </div>

          {/* Action Confirm Button */}
          <button
            onClick={handleConfirm}
            className="w-full mt-4 py-3 px-4 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black rounded-xl cursor-pointer shadow-md transition-all text-center uppercase text-xs tracking-wider flex items-center justify-center gap-1.5"
          >
            <span>Применить</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* RIGHT COLUMN: Grid of all 32 skins on the clean white background */}
        <div className="flex-1 flex flex-col justify-between overflow-hidden">
          <div>
            <h2 className="font-display font-black text-xl text-slate-950 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-500 fill-yellow-500" />
              Королевская Гардеробная
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Нажмите на любую из плиток, чтобы примерить новый пиксельный скин. Наведите курсор для просмотра ходьбы!
            </p>
          </div>

          {/* 32-skins grid (Scrollable) */}
          <div className="my-4 overflow-y-auto pr-1 grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2.5 max-h-[350px] md:max-h-[420px]">
            {skins.map((skinIdx) => {
              const isSelected = skinIdx === tempSkinIndex;
              const isHovered = skinIdx === hoveredIndex;
              return (
                <button
                  key={`select-skin-tile-${skinIdx}`}
                  onClick={() => setTempSkinIndex(skinIdx)}
                  onMouseEnter={() => setHoveredIndex(skinIdx)}
                  onMouseLeave={() => setHoveredIndex(null)}
                  className={`relative p-2 rounded-2xl flex flex-col items-center justify-center border-2 transition-all cursor-pointer ${
                    isSelected 
                      ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-400 shadow-md scale-102' 
                      : 'bg-slate-50 border-slate-200/80 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                  title={getSkinName(skinIdx)}
                >
                  {/* Miniature frame preview */}
                  <div className="h-11 flex items-center justify-center mb-1">
                    <CharacterSkin 
                      skinIndex={skinIdx} 
                      size="md" 
                      animate={isHovered || isSelected} 
                    />
                  </div>

                  {/* Character Index label */}
                  <span className={`text-[9px] font-bold font-mono ${isSelected ? 'text-amber-700' : 'text-slate-400'}`}>
                    #{skinIdx}
                  </span>

                  {/* Selection dot */}
                  {isSelected && (
                    <div className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-amber-500 border border-white" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Credits & License row */}
          <div className="border-t border-slate-100 pt-3 flex flex-col sm:flex-row justify-between items-center text-[9px] text-slate-400 gap-2">
            <span>© 2026 Dokapon Kingdom Board Game Replica</span>
            <span className="font-semibold italic text-slate-500 bg-slate-50 py-0.5 px-2 rounded-md border border-slate-200/60">
              Спрайты: Super Retro World Character Pack (by Gif, Noiracide, Romi)
            </span>
          </div>
        </div>

      </div>
    </div>
  );
}
