import React, { useState, useEffect, useRef } from 'react';
import { GameNode, Player, NodeType } from '../types';
import CharacterSkin from './CharacterSkin';
import { 
  Swords, Shield, Coins, Gift, ShoppingBag, Crown, Compass, 
  CornerDownRight, RotateCcw, Heart, Eye, HelpCircle, AlertTriangle, ChevronRight, Backpack
} from 'lucide-react';

interface MapBoardProps {
  nodes: GameNode[];
  players: Player[];
  activePlayerId: string;
  movesRemaining: number;
  currentWalkingNodeId: string;
  moveHistory: string[];
  isWalking: boolean;
  onTakeStep: (nodeId: string) => void;
  onResetMove: () => void;
  onUseItem: (itemId: string) => void;
  onRollDice: () => void;
  kingFirstReachClaimed: boolean;
  kingWinnerName: string | null;
  turnCount?: number;
}

export default function MapBoard({
  nodes,
  players,
  activePlayerId,
  movesRemaining,
  currentWalkingNodeId,
  moveHistory,
  isWalking,
  onTakeStep,
  onResetMove,
  onUseItem,
  onRollDice,
  kingFirstReachClaimed,
  kingWinnerName,
  turnCount = 1
}: MapBoardProps) {
  const activePlayer = players.find(p => p.id === activePlayerId);
  const viewportRef = useRef<HTMLDivElement>(null);

  // --- Map Navigation / Drag-to-Pan state ---
  const [dragState, setDragState] = useState({
    isDragging: false,
    startX: 0,
    startY: 0,
    scrollLeft: 0,
    scrollTop: 0
  });

  // UI Modes
  const [activeTab, setActiveTab] = useState<'map' | 'backpack' | 'inspect' | 'rules'>('map');
  const [inspectingNode, setInspectingNode] = useState<GameNode | null>(null);
  const [showRulesModal, setShowRulesModal] = useState<boolean>(false);

  // --- Dynamic Day of the Week calculation from turnCount ---
  const daysOfWeekRu = ['Понедельник ☀️', 'Вторник ⛅', 'Среда 🌧️', 'Четверг ⛈️', 'Пятница 🍃', 'Суббота 🌟', 'Воскресенье 👑'];
  const daysOfWeekEn = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  const currentDayIndex = (turnCount - 1) % 7;
  const currentWeek = Math.floor((turnCount - 1) / 7) + 1;
  const currentDayName = daysOfWeekRu[currentDayIndex];
  const currentDayShort = daysOfWeekEn[currentDayIndex];

  // --- True Isometric projection formula scaled up for massive map ---
  const getIsoCoords = (node: GameNode) => {
    // dx and dy go from -50 to +50 (percentage offset)
    const dx = node.x - 50; 
    const dy = node.y - 50; 
    
    // Spaced out flat coordinates
    const flatX = dx * 19.5 + 1200; 
    const flatY = dy * 15.5 + 1200; 
    
    // Rotate into isometric perspective beautifully centered in our 3800x2400 canvas
    const isoX = (flatX - flatY) * 0.95 + 1800;
    const isoY = (flatX + flatY) * 0.45 + 250;
    
    return { x: isoX, y: isoY };
  };

  // Auto-scroll center-focus camera on the active player node or current walking path step
  useEffect(() => {
    if (viewportRef.current && activePlayer) {
      // Follow the player step-by-step during active movement, otherwise center on active player's rest location
      const focalNodeId = (isWalking && currentWalkingNodeId) ? currentWalkingNodeId : activePlayer.currentNodeId;
      const activeNode = nodes.find(n => n.id === focalNodeId);
      if (activeNode) {
        const { x, y } = getIsoCoords(activeNode);
        const viewWidth = viewportRef.current.clientWidth;
        const viewHeight = viewportRef.current.clientHeight;
        
        // Smooth scroll centering
        viewportRef.current.scrollTo({
          left: x - viewWidth / 2,
          top: y - viewHeight / 2,
          behavior: 'smooth'
        });
      }
    }
  }, [activePlayerId, currentWalkingNodeId, isWalking]);

  // --- Dragging Handlers ---
  const handleMouseDown = (e: React.MouseEvent) => {
    // Prevent drag trigger on node button / interface clicks
    if (
      (e.target as HTMLElement).closest('.clickable-node') || 
      (e.target as HTMLElement).closest('button') || 
      (e.target as HTMLElement).closest('.ui-container')
    ) {
      return;
    }
    
    setDragState({
      isDragging: true,
      startX: e.clientX,
      startY: e.clientY,
      scrollLeft: viewportRef.current?.scrollLeft || 0,
      scrollTop: viewportRef.current?.scrollTop || 0
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!dragState.isDragging || !viewportRef.current) return;
    e.preventDefault();
    const walkX = e.clientX - dragState.startX;
    const walkY = e.clientY - dragState.startY;
    viewportRef.current.scrollLeft = dragState.scrollLeft - walkX;
    viewportRef.current.scrollTop = dragState.scrollTop - walkY;
  };

  const handleMouseUp = () => {
    setDragState(prev => ({ ...prev, isDragging: false }));
  };

  // Helper for Node plate colors (tilted disc pads)
  const getNodePlateStyles = (node: GameNode) => {
    if (node.type === 'king_castle') return 'fill-amber-400 stroke-amber-200 drop-shadow-[0_4px_10px_rgba(245,158,11,0.6)]';
    if (node.type === 'shop') return 'fill-indigo-500 stroke-indigo-200 drop-shadow-[0_4px_8px_rgba(99,102,241,0.5)]';
    if (node.type === 'chest') return 'fill-yellow-500 stroke-yellow-200 drop-shadow-[0_4px_8px_rgba(234,179,8,0.5)]';
    if (node.type === 'town') {
      if (node.townOwnerId) {
        const owner = players.find(p => p.id === node.townOwnerId);
        if (owner?.id === 'p1') return 'fill-red-500 stroke-red-200 drop-shadow-[0_4px_6px_rgba(239,68,68,0.5)]';
        if (owner?.id === 'p2') return 'fill-blue-500 stroke-blue-200 drop-shadow-[0_4px_6px_rgba(59,130,246,0.5)]';
        if (owner?.id === 'p3') return 'fill-emerald-500 stroke-emerald-200 drop-shadow-[0_4px_6px_rgba(16,185,129,0.5)]';
        return 'fill-purple-500 stroke-purple-200 drop-shadow-[0_4px_6px_rgba(168,85,247,0.5)]';
      }
      return 'fill-rose-600 stroke-white drop-shadow-[0_4px_6px_rgba(225,29,72,0.6)]'; // Siege
    }
    return 'fill-emerald-400 stroke-emerald-100 drop-shadow-[0_3px_5px_rgba(16,185,129,0.3)]'; // Empty
  };

  const getPlayerCardColor = (playerId: string) => {
    switch (playerId) {
      case 'p1': return 'bg-red-500/85';
      case 'p2': return 'bg-blue-500/85';
      case 'p3': return 'bg-emerald-500/85';
      default: return 'bg-purple-500/85';
    }
  };

  // Get rank suffix and label (1st, 2nd, etc.)
  const getPlayerRankString = (player: Player) => {
    // Sort players by total wealth (gold + 100 gold value per liberated village)
    const sorted = [...players].sort((a,b) => (b.townsOwned.length * 120 + b.gold) - (a.townsOwned.length * 120 + a.gold));
    const rank = sorted.findIndex(p => p.id === player.id) + 1;
    if (rank === 1) return '1st';
    if (rank === 2) return '2nd';
    if (rank === 3) return '3rd';
    return `${rank}th`;
  };

  // Prepare pathway connections projected in isometric space
  const renderedLines: React.ReactElement[] = [];
  const processedConnections = new Set<string>();

  nodes.forEach(node => {
    node.neighbors.forEach(neighId => {
      const neigh = nodes.find(n => n.id === neighId);
      if (neigh) {
        const key = [node.id, neigh.id].sort().join('-');
        if (!processedConnections.has(key)) {
          processedConnections.add(key);
          const c1 = getIsoCoords(node);
          const c2 = getIsoCoords(neigh);
          renderedLines.push(
            <g key={key}>
              {/* Thick shadow path */}
              <line
                x1={c1.x}
                y1={c1.y}
                x2={c2.x}
                y2={c2.y}
                className="stroke-amber-950/40 stroke-[10] stroke-linecap-round"
              />
              {/* Outer bright neon yellow JRPG board connection */}
              <line
                x1={c1.x}
                y1={c1.y}
                x2={c2.x}
                y2={c2.y}
                className="stroke-amber-300 stroke-[5] stroke-linecap-round cursor-pointer hover:stroke-yellow-200 transition-colors"
              />
              {/* Inner dashed light pattern representing steps path */}
              <line
                x1={c1.x}
                y1={c1.y}
                x2={c2.x}
                y2={c2.y}
                className="stroke-orange-500 stroke-[3] stroke-linecap-round stroke-dasharray-[5,10]"
              />
            </g>
          );
        }
      }
    });
  });

  // Calculate allowed next-step neighbor nodes during active walking phase (allowing backtrack steps in Dokapon style)
  const currentNode = nodes.find(n => n.id === currentWalkingNodeId);
  const nextAllowedStepIds = isWalking && currentNode
    ? currentNode.neighbors
    : [];

  return (
    <div id="map-board-wrapper" className="flex flex-col w-full relative select-none">
      
      {/* ========================================== */}
      {/* 1. TOP PREMIUM CONSOLE HEADER (DOKAPON REPLICA) */}
      {/* ========================================== */}
      <div className="w-full flex flex-col md:flex-row justify-between items-stretch gap-4 mb-4 z-30">
        
        {/* Left Side: Days/Week Wooden Calendar Block */}
        <div className="flex items-center gap-3 bg-gradient-to-br from-amber-700 via-amber-800 to-amber-950 p-3.5 rounded-2xl border-4 border-amber-600 shadow-xl max-w-sm">
          <div className="bg-yellow-100 text-amber-950 font-black px-4 py-2.5 rounded-xl border-2 border-amber-500 text-center font-mono flex flex-col justify-center min-w-[90px] shadow-inner">
            <span className="text-[10px] uppercase tracking-wider text-amber-700 font-bold">НЕДЕЛЯ</span>
            <span className="text-2xl font-black leading-none">{currentWeek}</span>
          </div>
          <div className="flex-1">
            <h4 className="font-display font-extrabold text-lg text-yellow-300 leading-tight">
              {currentDayName}
            </h4>
            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-mono text-amber-200">
              <span className="bg-amber-600/50 py-0.5 px-2 rounded-md font-bold uppercase">{currentDayShort}</span>
              <span>• Квестовый ход королевства</span>
            </div>
          </div>
        </div>

        {/* Right Side: Dynamic Premium Active Player JRPG Stat Banner */}
        {activePlayer && (
          <div className="flex-1 flex bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 p-1.5 rounded-3xl border-4 border-amber-950/80 shadow-2xl relative overflow-hidden items-center text-slate-900 justify-between">
            
            {/* Background elegant pattern details */}
            <div className="absolute inset-0 bg-radial-gradient from-transparent to-black/5 opacity-40 pointer-events-none" />

            {/* Leftmost Rank Emblem Block */}
            <div className="flex items-center gap-3.5 pl-3">
              <div className="flex flex-col items-center justify-center bg-gradient-to-b from-yellow-300 to-amber-600 text-amber-950 font-black rounded-full w-14 h-14 border-3 border-amber-950 shadow-md">
                <span className="text-[9px] font-bold uppercase tracking-widest text-amber-900 -mb-1">РАНГ</span>
                <span className="text-xl font-display font-black tracking-tighter italic">{getPlayerRankString(activePlayer)}</span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="bg-amber-950 text-yellow-300 text-[10px] font-black uppercase px-2 py-0.5 rounded-md font-mono border border-amber-900">
                    Lv.{activePlayer.level}
                  </span>
                  <h3 className="font-display font-black text-lg text-slate-950 tracking-tight leading-none drop-shadow-[0_1px_2px_rgba(255,255,255,0.4)]">
                    {activePlayer.shamedName || activePlayer.name}
                  </h3>
                </div>
                <p className="text-[11px] font-extrabold text-amber-950/80 uppercase font-sans tracking-wide mt-1">
                  ⚔️ {activePlayer.classType.toUpperCase()} • ДЕНЬГИ: <span className="text-amber-950 font-black font-mono text-sm">{activePlayer.gold} G</span>
                </p>
              </div>
            </div>

            {/* Middle: Grid of base stats (AT, DF, MG, SP) */}
            <div className="hidden lg:grid grid-cols-4 gap-x-4 bg-amber-950/10 px-5 py-2 rounded-2xl border border-amber-950/15 text-xs font-mono font-bold select-none text-amber-950">
              <div className="text-center">
                <div className="text-[9px] text-amber-950/60 uppercase">AT (Атк)</div>
                <div className="font-black text-lg text-slate-950">{activePlayer.stats.atk}</div>
              </div>
              <div className="text-center border-l border-amber-950/10 pl-3">
                <div className="text-[9px] text-amber-950/60 uppercase">DF (Защ)</div>
                <div className="font-black text-lg text-slate-950">{activePlayer.stats.def}</div>
              </div>
              <div className="text-center border-l border-amber-950/10 pl-3">
                <div className="text-[9px] text-amber-950/60 uppercase">MG (Маг)</div>
                <div className="font-black text-lg text-slate-950">{activePlayer.stats.mg}</div>
              </div>
              <div className="text-center border-l border-amber-950/10 pl-3">
                <div className="text-[9px] text-amber-950/60 uppercase">SP (Скор)</div>
                <div className="font-black text-lg text-slate-950">{activePlayer.stats.spd}</div>
              </div>
            </div>

            {/* Right: Giant Glowing HP Health Bar */}
            <div className="w-56 md:w-64 bg-amber-950/90 p-3 rounded-2xl border-2 border-amber-950 flex flex-col justify-center shadow-lg pr-4 ml-2">
              <div className="flex justify-between items-center mb-1 px-1">
                <span className="text-[10px] font-black text-amber-400 font-mono flex items-center gap-1">
                  <Heart className="w-3.5 h-3.5 fill-rose-500 stroke-none" /> HP (ЗДОРОВЬЕ)
                </span>
                <span className="text-[11px] font-black text-white font-mono">
                  {activePlayer.stats.hp} / {activePlayer.stats.maxHp}
                </span>
              </div>
              {/* Gradient progress container */}
              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden p-0.5 border border-slate-850">
                <div 
                  className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-emerald-400 to-teal-500 shadow-[0_0_10px_rgba(34,211,238,0.5)] transition-all duration-300"
                  style={{ width: `${(activePlayer.stats.hp / activePlayer.stats.maxHp) * 100}%` }}
                />
              </div>
            </div>

          </div>
        )}
      </div>

      {/* ========================================== */}
      {/* 2. DUAL-COLUMN LAYOUT: ACTION MENU & 3D MAP */}
      {/* ========================================== */}
      <div className="grid grid-cols-12 gap-5 items-stretch w-full relative">
        
        {/* LEFT COLUMN: Golden Vintage JRPG Circular Button Rail (1 Column width on desktop) */}
        <div className="col-span-12 md:col-span-1 flex md:flex-col justify-center items-center gap-3.5 z-20">
          
          {/* MOVE BUTTON */}
          <button
            onClick={() => {
              if (!isWalking && !activePlayer?.isAi) {
                onRollDice();
              }
            }}
            disabled={isWalking || activePlayer?.isAi}
            className={`w-16 h-16 rounded-full flex flex-col items-center justify-center relative cursor-pointer border-4 border-amber-500 shadow-xl transition-all hover:scale-110 active:scale-90 select-none bg-radial-gradient ${
              isWalking 
                ? 'from-slate-800 to-slate-950 text-slate-500 border-slate-700 opacity-50' 
                : 'from-amber-400 via-yellow-300 to-amber-600 text-amber-950 font-black hover:border-yellow-200 shadow-yellow-500/20'
            }`}
            title="Бросить спиннер Dokapon"
          >
            <Compass className={`w-6 h-6 ${isWalking ? '' : 'animate-spin'}`} style={{ animationDuration: '6s' }} />
            <span className="text-[8px] font-black tracking-tighter mt-0.5 uppercase">СПИН</span>
          </button>

          {/* BACKPACK BUTTON */}
          <button
            onClick={() => setActiveTab(activeTab === 'backpack' ? 'map' : 'backpack')}
            className={`w-14 h-14 rounded-full flex flex-col items-center justify-center relative cursor-pointer border-3 border-amber-600 shadow-lg transition-all hover:scale-110 active:scale-95 ${
              activeTab === 'backpack'
                ? 'bg-yellow-300 text-amber-950 border-yellow-200'
                : 'bg-slate-900 hover:bg-slate-850 text-amber-400 hover:text-yellow-300'
            }`}
            title="Просмотр рюкзака"
          >
            <Backpack className="w-5 h-5" />
            <span className="text-[8px] font-bold tracking-tight mt-0.5 uppercase">РЮКЗАК</span>
          </button>

          {/* INSPECT MODE BUTTON */}
          <button
            onClick={() => {
              setActiveTab(activeTab === 'inspect' ? 'map' : 'inspect');
              setInspectingNode(null);
            }}
            className={`w-14 h-14 rounded-full flex flex-col items-center justify-center relative cursor-pointer border-3 border-amber-600 shadow-lg transition-all hover:scale-110 active:scale-95 ${
              activeTab === 'inspect'
                ? 'bg-yellow-300 text-amber-950 border-yellow-200'
                : 'bg-slate-900 hover:bg-slate-850 text-amber-400 hover:text-yellow-300'
            }`}
            title="Инспекция карты"
          >
            <Eye className="w-5 h-5" />
            <span className="text-[8px] font-bold tracking-tight mt-0.5 uppercase">КАРТА</span>
          </button>

          {/* GAME RULES BUTTON */}
          <button
            onClick={() => setShowRulesModal(true)}
            className="w-14 h-14 rounded-full flex flex-col items-center justify-center relative cursor-pointer border-3 border-amber-600 bg-slate-900 hover:bg-slate-850 text-amber-400 hover:text-yellow-300 shadow-lg transition-all hover:scale-110 active:scale-95"
            title="Правила Dokapon"
          >
            <HelpCircle className="w-5 h-5" />
            <span className="text-[8px] font-bold tracking-tight mt-0.5 uppercase">СПРАВКА</span>
          </button>

        </div>

        {/* RIGHT COLUMN: Interactive 3D Scrollable Map Canvas - 11 Column width */}
        <div className="col-span-12 md:col-span-11 flex flex-col relative">
          
          {/* Floating Instructions Overlay */}
          <div className="absolute top-3 left-3 bg-slate-950/85 text-amber-300 border border-amber-600/30 py-1.5 px-3.5 rounded-xl text-[10px] font-semibold tracking-wide z-20 flex items-center gap-2 shadow-xl">
            <span className="animate-pulse">🖱️</span>
            <span>Зажмите левую кнопку мыши на траве и двигайте, чтобы прокручивать карту!</span>
          </div>

          {/* Main Map Viewport Screen Frame */}
          <div 
            ref={viewportRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className={`w-full h-[500px] md:h-[600px] rounded-3xl border-4 border-amber-950 overflow-hidden relative shadow-2xl bg-gradient-to-b from-sky-400 to-sky-600 ${
              dragState.isDragging ? 'cursor-grabbing' : 'cursor-grab'
            }`}
          >
            {/* The actual 3D virtual landscape map (massively scaled up) */}
            <div 
              className="w-[3800px] h-[2400px] absolute bg-gradient-to-b from-emerald-600 via-green-500 to-emerald-700 relative overflow-hidden"
              style={{
                backgroundImage: 'radial-gradient(#10b981 12%, transparent 12%), radial-gradient(#059669 12%, transparent 12%)',
                backgroundSize: '40px 40px',
                backgroundPosition: '0 0, 20px 20px'
              }}
            >
              {/* Sky gradient background overlay at top */}
              <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-sky-300/40 to-transparent pointer-events-none" />

              {/* Decorative 3D Isometric Scenic Details inside Map */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10 select-none">
                {/* 1. Sparkling River Pathway winding across the massive map */}
                <path
                  d="M 200,1200 Q 1800,400 2100,1800 T 3600,2000"
                  fill="none"
                  className="stroke-cyan-500/80 stroke-[48] stroke-linecap-round"
                />
                <path
                  d="M 200,1200 Q 1800,400 2100,1800 T 3600,2000"
                  fill="none"
                  className="stroke-cyan-300 stroke-[24] stroke-linecap-round"
                />
                <path
                  d="M 200,1200 Q 1800,400 2100,1800 T 3600,2000"
                  fill="none"
                  className="stroke-white stroke-[3] stroke-linecap-round stroke-dasharray-[12,32]"
                />

                {/* Draw connecting roads */}
                {renderedLines}
                
                {/* Ground plate disc pads for each node */}
                {nodes.map(node => {
                  const { x, y } = getIsoCoords(node);
                  return (
                    <g key={`plate-${node.id}`}>
                      {/* Drop shadow ellipse */}
                      <ellipse cx={x} cy={y + 3} rx="34" ry="17" className="fill-black/35" />
                      {/* Highlight border ellipse */}
                      <ellipse cx={x} cy={y} rx="30" ry="15" className="fill-slate-900 stroke-amber-500 stroke-2" />
                      {/* Center theme disc pad */}
                      <ellipse cx={x} cy={y} rx="26" ry="13" className={`${getNodePlateStyles(node)}`} />
                    </g>
                  );
                })}
              </svg>

              {/* 2. Overlapping Bridges over river intersection coordinates adjusted for 3800x2400 scale */}
              {/* Let's draw bridge structures at absolute coordinates */}
              <div className="absolute left-[1800px] top-[950px] w-24 h-12 bg-amber-800 border-2 border-amber-950 rounded-lg shadow-xl transform rotate-12 z-10 flex items-center justify-center font-mono text-[9px] font-bold text-yellow-200">
                🌉 Мост
              </div>
              <div className="absolute left-[2500px] top-[1400px] w-24 h-12 bg-amber-800 border-2 border-amber-950 rounded-lg shadow-xl transform -rotate-12 z-10 flex items-center justify-center font-mono text-[9px] font-bold text-yellow-200">
                🌉 Мост
              </div>

              {/* 3. Upright Standing Billboards for Cities, Towns, Castles & Chests */}
              {nodes.map(node => {
                const { x, y } = getIsoCoords(node);
                const isAllowedNext = nextAllowedStepIds.includes(node.id);
                const isCurrentWalking = node.id === currentWalkingNodeId;

                // Determine vector landmark assets to render upright (billboard sprite style)
                let landmarkElement = null;
                if (node.type === 'king_castle') {
                  landmarkElement = (
                    <div className="relative flex flex-col items-center">
                      <div className="animate-bounce" style={{ animationDuration: '4s' }}>
                        <div className="w-20 h-24 bg-gradient-to-b from-amber-200 to-amber-600 rounded-lg border-3 border-amber-950 flex flex-col justify-between items-center p-1 shadow-2xl relative">
                          <Crown className="w-10 h-10 text-yellow-100 animate-pulse mt-2 filter drop-shadow" />
                          <span className="text-[8px] font-black bg-amber-950 text-yellow-300 rounded px-1 text-center border border-amber-500 py-0.5">ЗАМОК КОРОЛЯ</span>
                          {/* Royal waving flag */}
                          <div className="absolute -top-4 right-0 w-8 h-4 bg-red-600 border border-amber-950 rounded-md font-bold text-[8px] text-white text-center leading-none flex items-center justify-center animate-wiggle">👑</div>
                        </div>
                      </div>
                      <div className="w-6 h-6 rounded-full bg-black/45 absolute -bottom-3 blur-sm" />
                    </div>
                  );
                } else if (node.type === 'shop') {
                  landmarkElement = (
                    <div className="relative flex flex-col items-center">
                      <div className="w-14 h-16 bg-indigo-900 border-2 border-amber-400 rounded-xl shadow-lg flex flex-col justify-between items-center p-1">
                        <span className="text-xl animate-pulse">🔮</span>
                        <span className="text-[7px] font-bold text-indigo-200 bg-slate-950 py-0.5 px-1 rounded border border-indigo-500 uppercase tracking-tighter">ЛАВКА МАГИИ</span>
                      </div>
                      <div className="w-4 h-4 rounded-full bg-black/30 absolute -bottom-2 blur-sm" />
                    </div>
                  );
                } else if (node.type === 'chest') {
                  landmarkElement = (
                    <div className="relative flex flex-col items-center group cursor-pointer">
                      <div className="w-10 h-10 bg-gradient-to-b from-amber-500 to-yellow-600 border-2 border-amber-950 rounded-lg shadow-lg flex items-center justify-center text-lg hover:scale-110 active:scale-95 transition-all">
                        📦
                      </div>
                      <div className="w-3 h-3 rounded-full bg-black/45 absolute -bottom-1 blur-sm" />
                    </div>
                  );
                } else if (node.type === 'town') {
                  const isSiege = !node.townOwnerId;
                  landmarkElement = (
                    <div className="relative flex flex-col items-center">
                      <div className={`w-14 h-14 rounded-xl border-2 shadow-xl flex flex-col justify-between items-center p-1.5 ${
                        isSiege 
                          ? 'bg-rose-950/90 border-rose-500 animate-pulse' 
                          : 'bg-emerald-950/90 border-emerald-400'
                      }`}>
                        <span className="text-lg">{isSiege ? '👺' : '🏡'}</span>
                        <span className="text-[7.5px] font-black text-white bg-slate-950 py-0.5 px-1 rounded uppercase tracking-tighter text-center max-w-full truncate">
                          {isSiege ? 'ОСАДА!' : 'ДЕРЕВНЯ'}
                        </span>
                      </div>
                      <div className="w-4 h-4 rounded-full bg-black/45 absolute -bottom-1.5 blur-sm" />
                    </div>
                  );
                } else {
                  // Empty meadow - random scenery
                  const sceneryEmoji = (parseInt(node.id.replace(/\D/g, '')) || 0) % 3 === 0 ? '🌲' : '🍄';
                  landmarkElement = (
                    <div className="relative flex flex-col items-center">
                      <span className="text-2xl filter drop-shadow-[0_2px_3px_rgba(0,0,0,0.3)]">{sceneryEmoji}</span>
                    </div>
                  );
                }

                return (
                  <div
                    key={`landmark-${node.id}`}
                    className="absolute z-10 flex flex-col items-center"
                    style={{
                      left: `${x}px`,
                      top: `${y - 12}px`, // Place standee on top of pad
                      transform: 'translate(-50%, -100%)'
                    }}
                  >
                    {/* Node Name Tag wooden signpost */}
                    <div className="mb-2 bg-gradient-to-r from-amber-900 to-amber-950 text-yellow-100 border border-amber-700 rounded-md py-0.5 px-2 text-[9px] font-mono shadow-md text-center max-w-[120px] truncate leading-none">
                      {node.name.replace(' (В осаде!)', '')}
                    </div>

                    {/* Landmark Object */}
                    {landmarkElement}

                    {/* Step Highlight / Select Target Click Overlay */}
                    {isWalking && isAllowedNext && (
                      <button
                        onClick={() => onTakeStep(node.id)}
                        className="absolute -inset-4 rounded-full border-4 border-dashed border-yellow-300 bg-yellow-400/25 animate-ping cursor-pointer z-30 clickable-node flex items-center justify-center text-amber-950 font-black text-xs"
                      >
                        ШАГ!
                      </button>
                    )}

                    {/* Highlight outline for walk path */}
                    {isCurrentWalking && (
                      <div className="absolute -inset-2 rounded-full border-2 border-white animate-pulse" />
                    )}
                  </div>
                );
              })}

              {/* 4. Upright Animated Player Characters Standees */}
              {players.map(p => {
                if (p.isDead) return null;
                const isActive = p.id === activePlayerId;
                
                // If this is the active player and they are walking, render them at their current step node
                const displayNodeId = (isActive && isWalking && currentWalkingNodeId) 
                  ? currentWalkingNodeId 
                  : p.currentNodeId;
                
                const node = nodes.find(n => n.id === displayNodeId);
                if (!node) return null;
                const { x, y } = getIsoCoords(node);

                return (
                  <div
                    key={`standee-${p.id}`}
                    className={`absolute z-20 flex flex-col items-center pointer-events-none transition-all duration-300 ${
                      isActive ? 'scale-110' : 'opacity-90'
                    }`}
                    style={{
                      left: `${x}px`,
                      top: `${y + 15}px`, // centered with small downward billboard offset
                      transform: 'translate(-50%, -100%)'
                    }}
                  >
                    {/* Floating downward selection arrow for ACTIVE PLAYER */}
                    {isActive && (
                      <div className="mb-1 text-center animate-bounce">
                        <span className="bg-yellow-400 text-amber-950 text-[8px] font-black uppercase px-2 py-0.5 rounded border border-amber-950 shadow-md">
                          ВАШ ХОД! 👇
                        </span>
                      </div>
                    )}

                    {/* Transparent character avatar container (no colored outline or card background) */}
                    <div className={`flex flex-col items-center relative transition-all ${
                      isActive ? 'animate-bounce scale-110' : ''
                    }`}
                    style={{ animationDuration: isActive ? '1.5s' : '0s' }}
                    >
                      {/* Character head pixel-art skin */}
                      <div className="flex items-center justify-center h-10 select-none">
                        {p.isDarkling ? (
                          <CharacterSkin skinIndex={25} size="md" animate={isActive} direction={p.direction || 'down'} />
                        ) : p.shamedName ? (
                          <CharacterSkin skinIndex={21} size="md" animate={isActive} direction={p.direction || 'down'} />
                        ) : (
                          <CharacterSkin skinIndex={p.skinIndex || 1} size="md" animate={isActive} direction={p.direction || 'down'} />
                        )}
                      </div>
                    </div>

                    {/* Neutral, elegant slate name tag below character (no player-colored outlines or glowing dots) */}
                    <div className="mt-1 border border-slate-800 rounded px-1.5 py-0.5 text-[8px] font-mono font-black text-white shadow-md flex items-center gap-1 bg-slate-950/95">
                      <span>{p.shamedName || p.name.substring(0, 10)}</span>
                    </div>

                    {/* Standee Shadow Base */}
                    <ellipse cx="24" cy="5" rx="16" ry="8" className="fill-black/45" />
                  </div>
                );
              })}

            </div>
          </div>

          {/* Sub-Panel Options: BACKPACK TAB OVERLAY */}
          {activeTab === 'backpack' && activePlayer && (
            <div className="absolute inset-x-5 bottom-5 bg-slate-950/95 border-3 border-amber-600 rounded-3xl p-5 shadow-2xl z-40 ui-container animate-fade-in text-slate-100">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center gap-2">
                  <Backpack className="w-5 h-5 text-amber-400" />
                  <h3 className="font-display font-black text-amber-300">Ваш Рюкзак ({activePlayer.items.length}/6 предметов)</h3>
                </div>
                <button 
                  onClick={() => setActiveTab('map')}
                  className="py-1 px-3 bg-slate-800 hover:bg-slate-700 text-xs rounded-xl cursor-pointer"
                >
                  Закрыть ✕
                </button>
              </div>

              {activePlayer.items.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-4">Рюкзак пуст. Посетите золотой сундук или магическую лавку, чтобы приобрести расходники!</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {activePlayer.items.map((item, idx) => (
                    <div key={`${item.id}-${idx}`} className="bg-slate-900 border border-slate-800 p-3 rounded-2xl flex flex-col justify-between items-stretch">
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-bold text-xs text-yellow-300">📦 {item.name}</span>
                          <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">{item.type.toUpperCase()}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">{item.description}</p>
                      </div>
                      <button
                        onClick={() => {
                          onUseItem(item.id);
                          setActiveTab('map');
                        }}
                        disabled={isWalking || activePlayer.isAi}
                        className="mt-3 py-1.5 px-3 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 text-[10px] font-black rounded-lg cursor-pointer disabled:opacity-40 transition-all text-center uppercase"
                      >
                        {isWalking ? 'Заняты движением' : 'Активировать предмет'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Sub-Panel Options: INSPECT MODE INFO PANEL */}
          {activeTab === 'inspect' && (
            <div className="absolute inset-x-5 bottom-5 bg-slate-950/95 border-3 border-amber-600 rounded-3xl p-5 shadow-2xl z-40 ui-container animate-fade-in text-slate-100 flex flex-col md:flex-row gap-4 items-center">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Eye className="w-5 h-5 text-yellow-400" />
                  <h3 className="font-display font-black text-yellow-300">Режим Осмотра Докапона</h3>
                </div>
                <p className="text-xs text-slate-300">
                  Выбирайте и изучайте детальные свойства любой из ключевых точек на карте королевства:
                </p>

                {/* Quick select list of towns */}
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {nodes.map(n => (
                    <button
                      key={n.id}
                      onClick={() => setInspectingNode(n)}
                      className={`py-1 px-2.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                        inspectingNode?.id === n.id
                          ? 'bg-amber-400 text-amber-950 border-amber-300'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {n.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              {inspectingNode ? (
                <div className="w-full md:w-80 bg-slate-900 border-2 border-amber-600/30 p-4 rounded-2xl">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-sm text-yellow-300">{inspectingNode.name}</h4>
                    <span className="text-[9px] bg-amber-500/10 text-amber-300 font-bold border border-amber-500/30 py-0.5 px-2 rounded-md uppercase">
                      {inspectingNode.type.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-300 space-y-1.5">
                    <div>📍 Координаты на карте: <span className="font-mono text-slate-400">({inspectingNode.x}, {inspectingNode.y})</span></div>
                    {inspectingNode.type === 'town' && (
                      <>
                        <div>🏡 Владелец: <span className="text-blue-300 font-bold">
                          {players.find(p => p.id === inspectingNode.townOwnerId)?.name || 'Дикие Гоблины 👹'}
                        </span></div>
                        <div>💸 Сумма налога: <span className="text-amber-400 font-bold">{inspectingNode.townTax || 50} золотых</span></div>
                        <div>📈 Поколение прибыли: <span className="text-emerald-400 font-bold">+{inspectingNode.townIncome || 30} зол./круг</span></div>
                      </>
                    )}
                    {inspectingNode.type === 'shop' && <p className="text-slate-400 italic mt-1">Здесь вы можете приобрести самое передовое снаряжение JRPG — щиты, клинки и магические заклинания атаки/защиты.</p>}
                    {inspectingNode.type === 'chest' && <p className="text-slate-400 italic mt-1">Случайные золотые подарки, расходные свитки, кристаллы деформации пространства... берегитесь заминированных ловушек!</p>}
                    {inspectingNode.type === 'king_castle' && <p className="text-slate-400 italic mt-1">Престол Короля Докапона. Здесь вы получите благословение в +10 характеристик, а в финале сразитесь с Тёмным Лордом!</p>}
                  </div>
                </div>
              ) : (
                <div className="w-full md:w-80 py-6 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-2xl">
                  Выберите клетку для просмотра свойств
                </div>
              )}
            </div>
          )}

        </div>

      </div>

      {/* ========================================== */}
      {/* 3. FLOATING PASSIVE PLAYER STATUS PROFILE BARS */}
      {/* ========================================== */}
      <div className="mt-5 grid grid-cols-1 md:grid-cols-4 gap-4 z-20">
        {players.map(p => {
          const isCurrent = p.id === activePlayerId;
          const rankStr = getPlayerRankString(p);
          return (
            <div 
              key={`mini-p-${p.id}`} 
              className={`p-3 rounded-2xl border flex items-center gap-3 transition-all ${
                isCurrent
                  ? 'bg-gradient-to-r from-amber-900/60 to-slate-900 border-amber-500 shadow-md scale-102'
                  : p.isDead 
                    ? 'bg-slate-950/40 border-slate-900 opacity-60' 
                    : 'bg-slate-900/90 border-slate-800'
              }`}
            >
              {/* Cute mini avatar */}
              <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm overflow-hidden ${
                p.isDead ? 'bg-slate-950' : getPlayerCardColor(p.id)
              }`}>
                {p.isDead ? '💀' : p.isDarkling ? (
                  <CharacterSkin skinIndex={25} size="sm" animate={isCurrent} />
                ) : p.shamedName ? (
                  <CharacterSkin skinIndex={21} size="sm" animate={isCurrent} />
                ) : (
                  <CharacterSkin skinIndex={p.skinIndex || 1} size="sm" animate={isCurrent} />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-xs text-slate-200 truncate pr-1">
                    {p.shamedName || p.name}
                  </span>
                  <span className="text-[10px] font-bold text-amber-400">#{rankStr}</span>
                </div>
                {/* Health bar representation */}
                <div className="mt-1 flex items-center gap-1.5">
                  <div className="flex-1 bg-slate-950 h-1.5 rounded-full overflow-hidden p-0.5">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        p.isDead ? 'bg-slate-800' : 'bg-gradient-to-r from-rose-500 to-amber-400'
                      }`}
                      style={{ width: `${p.isDead ? 0 : (p.stats.hp / p.stats.maxHp) * 100}%` }}
                    />
                  </div>
                  <span className="text-[9px] font-mono text-slate-400">
                    {p.isDead ? 'DEAD' : `${p.stats.hp}/${p.stats.maxHp}`}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ========================================== */}
      {/* 4. MODAL: FULL RULES AND HELP DOCUMENTATION */}
      {/* ========================================== */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 border-4 border-amber-500 rounded-3xl p-6 shadow-2xl max-w-lg w-full text-slate-200 relative">
            <button 
              onClick={() => setShowRulesModal(false)}
              className="absolute top-4 right-4 bg-slate-800 hover:bg-slate-700 text-slate-100 hover:text-white rounded-full w-8 h-8 flex items-center justify-center cursor-pointer transition-colors border border-slate-700"
            >
              ✕
            </button>
            
            <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-3">
              <Crown className="w-6 h-6 text-yellow-400 animate-pulse" />
              <h2 className="font-display font-black text-xl text-yellow-300 uppercase">Справка Королевства Dokapon</h2>
            </div>

            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 text-xs font-sans text-slate-300 leading-relaxed">
              <div>
                <h3 className="font-bold text-yellow-400 uppercase mb-1">🎮 Как играть и ходить:</h3>
                <p>Нажмите большую круглую золотую кнопку 🎲 <strong>СПИН</strong> на левой панели. Спиннер укажет количество шагов. Нажмите подсвеченные соседние плитки на 3D карте, чтобы сделать пошаговый переход.</p>
              </div>

              <div>
                <h3 className="font-bold text-yellow-400 uppercase mb-1">🏡 Зачем освобождать деревни (Village Siege):</h3>
                <p>Приземлившись на клетку Деревни (🏡), вы сразитесь с монстром-оккупантом. В случае победы деревня перейдет под ваше покровительство и будет приносить налог, увеличивая ваше богатство на королевском ранге!</p>
              </div>

              <div>
                <h3 className="font-bold text-yellow-400 uppercase mb-1">👑 Квест от Короля (Гонка за статами!):</h3>
                <p>Тот искатель приключений, который первым посетит Королевский Замок в центре карты, получит уникальный королевский дар — <strong>+10 свободных характеристик</strong>!</p>
              </div>

              <div>
                <h3 className="font-bold text-yellow-400 uppercase mb-1">😈 Пакт Демона Бездны (Darkling Comeback):</h3>
                <p>Отстающий в богатстве игрок во время своего хода получает уникальное предложение — превратиться в мощного демона DARKLING на 3 хода, удваивая свои статы атаки и защиты, чтобы отомстить лидерам!</p>
              </div>

              <div>
                <h3 className="font-bold text-yellow-400 uppercase mb-1">⚔️ Дуэли столкновения (PvP Shame):</h3>
                <p>Если вы закончите ход на одной плитке с соперником, начнется PvP-дуэль! Победитель может отобрать золото, конфисковать одну из его деревень или с позором переименовать проигравшего (Клеймо Позора)!</p>
              </div>
            </div>

            <button
              onClick={() => setShowRulesModal(false)}
              className="mt-6 w-full py-3 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black rounded-xl cursor-pointer shadow-lg transition-all text-center uppercase text-xs"
            >
              Вернуться на Поле Боя! ⚔️
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
