import React, { useState } from 'react';
import { Player, Stats } from '../types';
import { Plus, ShieldAlert } from 'lucide-react';

interface StatDistributionProps {
  player: Player;
  onConfirm: (allocatedStats: Stats, remainingPoints: number) => void;
  title?: string;
  subtitle?: string;
}

export default function StatDistribution({
  player,
  onConfirm,
  title = "Повышение Характеристик! 🎖️",
  subtitle = "Распределите свободные очки для усиления вашего персонажа."
}: StatDistributionProps) {
  const [tempStats, setTempStats] = useState<Stats>({ ...player.stats });
  const [points, setPoints] = useState<number>(player.statPoints);

  const handleIncrement = (statKey: keyof Stats, incrementAmount: number) => {
    if (points <= 0) return;
    setTempStats(prev => {
      const current = prev[statKey];
      let updated = current + incrementAmount;
      return {
        ...prev,
        [statKey]: updated
      };
    });
    setPoints(prev => prev - 1);
  };

  const handleReset = () => {
    setTempStats({ ...player.stats });
    setPoints(player.statPoints);
  };

  const handleConfirm = () => {
    onConfirm(tempStats, points);
  };

  return (
    <div id="stat-dist-modal" className="bg-slate-900/95 border-2 border-amber-500/50 rounded-2xl p-6 max-w-md w-full mx-auto shadow-2xl backdrop-blur-md animate-fade-in text-slate-100">
      <div className="text-center mb-6">
        <h3 className="font-display text-2xl font-bold text-amber-400 tracking-tight">{title}</h3>
        <p className="text-sm text-slate-300 mt-1">{subtitle}</p>
        <p className="text-xs text-slate-400 mt-1 italic">Игрок: <span className="text-amber-300 font-semibold">{player.shamedName || player.name}</span> ({player.classType.toUpperCase()})</p>
      </div>

      <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-center mb-6">
        <span className="text-xs uppercase text-amber-400 font-mono tracking-wider">Свободные очки (Stat Points)</span>
        <div className="text-3xl font-display font-bold text-amber-300">{points}</div>
      </div>

      <div className="space-y-4">
        {/* HP */}
        <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display font-semibold text-rose-400">ОЗ (HP)</span>
              <span className="text-xs text-slate-400 font-mono">+{tempStats.maxHp - player.stats.maxHp}</span>
            </div>
            <p className="text-[10px] text-slate-400">Максимум здоровья (+10 за очко)</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-lg font-bold text-slate-200">{tempStats.maxHp}</span>
            <button
              onClick={() => handleIncrement('maxHp', 10)}
              disabled={points <= 0}
              className="bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:hover:bg-rose-600 text-white p-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ATK */}
        <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display font-semibold text-orange-400">АТК (ATK)</span>
              <span className="text-xs text-slate-400 font-mono">+{tempStats.atk - player.stats.atk}</span>
            </div>
            <p className="text-[10px] text-slate-400">Физический урон оружия и обычных ударов</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-lg font-bold text-slate-200">{tempStats.atk}</span>
            <button
              onClick={() => handleIncrement('atk', 1)}
              disabled={points <= 0}
              className="bg-orange-600 hover:bg-orange-500 disabled:opacity-40 disabled:hover:bg-orange-600 text-white p-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* DEF */}
        <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display font-semibold text-blue-400">ЗАЩ (DEF)</span>
              <span className="text-xs text-slate-400 font-mono">+{tempStats.def - player.stats.def}</span>
            </div>
            <p className="text-[10px] text-slate-400">Снижает входящий урон и усиливает блок</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-lg font-bold text-slate-200">{tempStats.def}</span>
            <button
              onClick={() => handleIncrement('def', 1)}
              disabled={points <= 0}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:hover:bg-blue-600 text-white p-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* MG */}
        <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display font-semibold text-purple-400">МАГ (MG)</span>
              <span className="text-xs text-slate-400 font-mono">+{tempStats.mg - player.stats.mg}</span>
            </div>
            <p className="text-[10px] text-slate-400">Сила заклинаний и защита от чужой магии</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-lg font-bold text-slate-200">{tempStats.mg}</span>
            <button
              onClick={() => handleIncrement('mg', 1)}
              disabled={points <= 0}
              className="bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:hover:bg-purple-600 text-white p-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* SPD */}
        <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display font-semibold text-emerald-400">СКОР (SPD)</span>
              <span className="text-xs text-slate-400 font-mono">+{tempStats.spd - player.stats.spd}</span>
            </div>
            <p className="text-[10px] text-slate-400">Влияет на очередность, бегство и точность</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-lg font-bold text-slate-200">{tempStats.spd}</span>
            <button
              onClick={() => handleIncrement('spd', 1)}
              disabled={points <= 0}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white p-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex gap-3 mt-8">
        <button
          onClick={handleReset}
          className="flex-1 py-2 px-4 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-all font-semibold text-sm cursor-pointer"
        >
          Сбросить
        </button>
        <button
          onClick={handleConfirm}
          className="flex-2 py-2 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20 transition-all text-sm cursor-pointer"
        >
          Применить ({points} очк. осталось)
        </button>
      </div>
    </div>
  );
}
