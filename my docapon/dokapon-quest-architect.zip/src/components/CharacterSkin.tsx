import React, { useState, useEffect } from 'react';

interface CharacterSkinProps {
  skinIndex: number;
  size?: 'sm' | 'md' | 'lg' | 'xl' | number; // presets or custom scale multiplier
  direction?: 'down' | 'left' | 'right' | 'up';
  animate?: boolean;
  className?: string;
}

export default function CharacterSkin({
  skinIndex,
  size = 'md',
  direction = 'down',
  animate = false,
  className = ''
}: CharacterSkinProps) {
  const [frame, setFrame] = useState(1); // 0, 1, 2 frames cycle

  // Optional walking animation loop
  useEffect(() => {
    if (!animate) {
      setFrame(1); // Idle frame (middle)
      return;
    }
    const interval = setInterval(() => {
      setFrame(prev => {
        // Frame cycle: 0 -> 1 -> 2 -> 1 -> ...
        // Simplest is 0 -> 1 -> 2 -> 0
        return (prev + 1) % 3;
      });
    }, 250);
    return () => clearInterval(interval);
  }, [animate]);

  // Map direction to row index (0 to 3)
  const dirRows = {
    down: 0,
    left: 1,
    right: 2,
    up: 3
  };
  const row = dirRows[direction];

  // Base frame dimensions
  const baseWidth = 16;
  const baseHeight = 20;

  // Compute actual rendering scale
  let scale = 2; // default md (32x40)
  if (size === 'sm') scale = 1;      // 16x20
  if (size === 'md') scale = 2;      // 32x40
  if (size === 'lg') scale = 3;      // 48x60
  if (size === 'xl') scale = 4;      // 64x80
  if (typeof size === 'number') scale = size;

  const width = baseWidth * scale;
  const height = baseHeight * scale;

  // Background size to keep sprite aspect ratio
  const bgWidth = baseWidth * 3 * scale;
  const bgHeight = baseHeight * 4 * scale;

  // Background position offset in pixels
  const posX = -frame * width;
  const posY = -row * height;

  const imageUrl = `/skins/SuperRetroWorld_CharacterPack_Full/sprite_split/character_${skinIndex}/character_${skinIndex}_frame16x20.png`;

  return (
    <div
      id={`skin-char-${skinIndex}`}
      className={`inline-block select-none ${className}`}
      style={{
        width: `${width}px`,
        height: `${height}px`,
        backgroundImage: `url("${imageUrl}")`,
        backgroundSize: `${bgWidth}px ${bgHeight}px`,
        backgroundPosition: `${posX}px ${posY}px`,
        backgroundRepeat: 'no-repeat',
        imageRendering: 'pixelated'
      }}
    />
  );
}
