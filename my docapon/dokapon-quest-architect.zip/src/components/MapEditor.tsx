import React, { useState, useEffect, useRef } from 'react';
import { BoardMap, GameNode, NodeType } from '../types';
import { MAP_NODES } from '../data/gameData';
import { 
  ArrowLeft, Plus, Trash2, Link, Link2Off, Save, FolderOpen, 
  Map, Edit3, CheckCircle, AlertCircle, Layout, HelpCircle, RefreshCw
} from 'lucide-react';

interface MapEditorProps {
  lang: 'ru' | 'en';
  onBackToMenu: () => void;
}

export default function MapEditor({ lang, onBackToMenu }: MapEditorProps) {
  const [maps, setMaps] = useState<BoardMap[]>([]);
  const [selectedMapId, setSelectedMapId] = useState<string | null>(null);
  const [editingNodes, setEditingNodes] = useState<GameNode[]>([]);
  const [mapName, setMapName] = useState('');
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [connectWithNodeId, setConnectWithNodeId] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Refs for the viewport and canvas
  const editorViewportRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  // Editor Camera Drag-to-Pan state
  const [editorPanState, setEditorPanState] = useState({
    isPanning: false,
    startX: 0,
    startY: 0,
    scrollLeft: 0,
    scrollTop: 0
  });

  // State to track if we are dragging a node
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null);

  // Custom Iframe-safe confirmation for map deletions
  const [confirmDeleteMapId, setConfirmDeleteMapId] = useState<string | null>(null);

  // --- Translation Dictionary ---
  const t = {
    ru: {
      title: 'Редактор Карт DocoPixel6 🛠️',
      subtitle: 'Создавайте свои уникальные миры для Dokapon Kingdom',
      back: 'Назад в меню',
      myMaps: 'Ваши сохраненные карты',
      noCustomMaps: 'У вас пока нет сохраненных карт.',
      createBtn: 'Создать новую карту',
      mapNamePlaceholder: 'Название карты...',
      saveSuccess: 'Карта успешно сохранена!',
      deleteConfirm: 'Вы уверены, что хотите удалить эту карту?',
      nodeSettings: 'Настройки выбранной клетки',
      nodeName: 'Название клетки',
      nodeType: 'Тип клетки',
      nodeCoords: 'Координаты (X / Y)',
      addNode: 'Добавить клетку',
      deleteNode: 'Удалить клетку',
      connectNodes: 'Управление связями',
      connectWith: 'Связать с:',
      toggleLink: 'Связать / Разъединить',
      validationStartMissing: 'Ошибка: На карте должна быть стартовая деревня с ID "start"!',
      validationCastleMissing: 'Ошибка: На карте должен быть Королевский Замок с ID "king_castle"!',
      validationOrphan: 'Предупреждение: Есть изолированные клетки без связей!',
      saveBtn: 'Сохранить карту',
      exitEditor: 'Выйти из редактора',
      defaultMapCopy: 'Копия стандартной карты',
      empty: 'Пустая клетка',
      shop: 'Магазин экипировки',
      town: 'Деревня монстров',
      chest: 'Сундук с добычей',
      king_castle: 'Королевский замок',
      helpTitle: 'Как это работает?',
      helpStep1: '1. Нажмите "Создать новую карту" или выберите существующую.',
      helpStep2: '2. Добавляйте новые клетки и перетаскивайте их ползунками X и Y.',
      helpStep3: '3. Выделите клетку, выберите другую из списка "Связать с" и нажмите кнопку связи для соединения.',
      helpStep4: '4. Убедитесь, что у вас есть стартовая деревня ("start") и замок ("king_castle") перед сохранением.',
    },
    en: {
      title: 'DocoPixel6 Map Editor 🛠️',
      subtitle: 'Create your custom adventure boards for Dokapon',
      back: 'Back to Menu',
      myMaps: 'Your Saved Boards',
      noCustomMaps: 'No custom boards created yet.',
      createBtn: 'Create New Map',
      mapNamePlaceholder: 'Board Name...',
      saveSuccess: 'Board saved successfully!',
      deleteConfirm: 'Are you sure you want to delete this board?',
      nodeSettings: 'Selected Node Settings',
      nodeName: 'Node Name',
      nodeType: 'Node Type',
      nodeCoords: 'Coordinates (X / Y)',
      addNode: 'Add New Node',
      deleteNode: 'Delete Node',
      connectNodes: 'Manage Connections',
      connectWith: 'Connect with:',
      toggleLink: 'Toggle Connect / Disconnect',
      validationStartMissing: 'Error: Board must contain a start village with ID "start"!',
      validationCastleMissing: 'Error: Board must contain a King Castle with ID "king_castle"!',
      validationOrphan: 'Warning: Some nodes are completely disconnected!',
      saveBtn: 'Save Board',
      exitEditor: 'Exit Editor',
      defaultMapCopy: 'Default Board Copy',
      empty: 'Empty Plain Tile',
      shop: 'Equipment Shop',
      town: 'Monster Village',
      chest: 'Loot Chest',
      king_castle: 'King\'s Castle',
      helpTitle: 'How to use?',
      helpStep1: '1. Click "Create New Map" or select an existing custom board to edit.',
      helpStep2: '2. Add new nodes and adjust their positions using the X/Y coordinate sliders.',
      helpStep3: '3. Select a node, choose another from the dropdown, and press "Toggle Connect" to link them.',
      helpStep4: '4. Every board must include a "start" node and a "king_castle" node to be playable.',
    }
  }[lang];

  // Load custom maps from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('docopixel_custom_maps');
    if (saved) {
      try {
        setMaps(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load custom maps', e);
      }
    }
  }, []);

  // Save maps helper
  const saveAllMaps = (updatedMaps: BoardMap[]) => {
    setMaps(updatedMaps);
    localStorage.setItem('docopixel_custom_maps', JSON.stringify(updatedMaps));
  };

  // Start designing a completely brand new map
  const handleCreateNewMap = () => {
    const newId = `custom_${Date.now()}`;
    const newMap: BoardMap = {
      id: newId,
      name: lang === 'ru' ? 'Пользовательская карта' : 'My Custom Map',
      isCustom: true,
      nodes: [] // Start completely empty!
    };

    const updated = [...maps, newMap];
    saveAllMaps(updated);
    handleSelectMap(newMap);
  };

  // Assign a node to a special role ('start' or 'king_castle')
  const makeNodeSpecial = (nodeId: string, role: 'start' | 'king_castle') => {
    const selected = editingNodes.find(n => n.id === nodeId);
    if (!selected) return;
    if (selected.id === role) return; // Already has this role

    const oldSpecialNode = editingNodes.find(n => n.id === role);
    const newRandomId = `node_${Date.now()}`;
    
    // Mapping of node ID renames: old ID -> new ID
    const renamingMap: Record<string, string> = {
      [nodeId]: role,
    };
    if (oldSpecialNode) {
      renamingMap[role] = newRandomId;
    }

    const updatedNodes = editingNodes.map(n => {
      // 1. Rename ID if applicable
      let newId = n.id;
      if (renamingMap[n.id]) {
        newId = renamingMap[n.id];
      }

      // 2. Adjust type based on assigned role
      let newType = n.type;
      if (n.id === nodeId) {
        newType = role === 'start' ? 'empty' : 'king_castle';
      } else if (oldSpecialNode && n.id === oldSpecialNode.id) {
        newType = 'empty';
      }

      // 3. Set standard special name
      let newName = n.name;
      if (n.id === nodeId) {
        newName = role === 'start'
          ? (lang === 'ru' ? 'Стартовая Деревня 🏡' : 'Start Village 🏡')
          : (lang === 'ru' ? 'Королевский Замок 👑' : 'Royal Castle 👑');
      } else if (oldSpecialNode && n.id === oldSpecialNode.id) {
        newName = lang === 'ru' ? 'Поляна' : 'Plain Tile';
      }

      // 4. Update neighbors references
      const updatedNeighbors = n.neighbors.map(neighId => {
        return renamingMap[neighId] || neighId;
      });

      return {
        ...n,
        id: newId,
        type: newType,
        name: newName,
        neighbors: updatedNeighbors
      };
    });

    setEditingNodes(updatedNodes);
    setSelectedNodeId(role); // Keep selection on this role
    if (connectWithNodeId === nodeId) setConnectWithNodeId(role);
  };

  // Start designing based on a copy of default map so users have a template
  const handleCopyDefaultMap = () => {
    const newId = `custom_copy_${Date.now()}`;
    const clonedNodes: GameNode[] = JSON.parse(JSON.stringify(MAP_NODES));
    
    const newMap: BoardMap = {
      id: newId,
      name: lang === 'ru' ? 'Копия Королевства (Кастом)' : 'Cloned Kingdom (Custom)',
      isCustom: true,
      nodes: clonedNodes
    };

    const updated = [...maps, newMap];
    saveAllMaps(updated);
    handleSelectMap(newMap);
  };

  const handleSelectMap = (map: BoardMap) => {
    setSelectedMapId(map.id);
    setMapName(map.name);
    setEditingNodes(JSON.parse(JSON.stringify(map.nodes)));
    setSelectedNodeId(map.nodes[0]?.id || null);
    setConnectWithNodeId(null);
    setValidationError(null);
    setSuccessMsg(null);
  };

  // Auto-scroll center-focus on selection
  useEffect(() => {
    if (selectedMapId && editorViewportRef.current) {
      const timer = setTimeout(() => {
        if (!editorViewportRef.current) return;
        const startNode = editingNodes.find(n => n.id === 'start');
        const nodeToFocus = startNode || editingNodes[0];
        const targetX = nodeToFocus ? (nodeToFocus.x / 100) * 2400 : 1200;
        const targetY = nodeToFocus ? (nodeToFocus.y / 100) * 1800 : 900;

        const viewWidth = editorViewportRef.current.clientWidth;
        const viewHeight = editorViewportRef.current.clientHeight;

        editorViewportRef.current.scrollTo({
          left: Math.max(0, targetX - viewWidth / 2),
          top: Math.max(0, targetY - viewHeight / 2),
          behavior: 'smooth'
        });
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [selectedMapId]);

  const handleDeleteMap = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDeleteMapId(id);
  };

  const handleConfirmDelete = (id: string) => {
    const updated = maps.filter(m => m.id !== id);
    saveAllMaps(updated);
    if (selectedMapId === id) {
      setSelectedMapId(null);
      setEditingNodes([]);
    }
    setConfirmDeleteMapId(null);
  };

  // Node operations
  const handleAddNode = () => {
    let newId = `node_${Date.now()}`;
    const isStart = editingNodes.length === 0;
    const isCastle = editingNodes.length === 1;

    if (isStart) {
      newId = 'start';
    } else if (isCastle) {
      newId = 'king_castle';
    }
    
    // Smart spawn coordinates: offset from selected node, or center of screen, or center of canvas
    let spawnX = 50;
    let spawnY = 50;

    if (selectedNodeId) {
      const sel = editingNodes.find(n => n.id === selectedNodeId);
      if (sel) {
        spawnX = Math.max(5, Math.min(95, sel.x + 8));
        spawnY = Math.max(5, Math.min(95, sel.y + 8));
      }
    } else if (editorViewportRef.current && canvasRef.current) {
      const view = editorViewportRef.current;
      const canvasW = canvasRef.current.clientWidth || 2400;
      const canvasH = canvasRef.current.clientHeight || 1800;
      
      const centerX = view.scrollLeft + view.clientWidth / 2;
      const centerY = view.scrollTop + view.clientHeight / 2;
      
      spawnX = Math.round((centerX / canvasW) * 100);
      spawnY = Math.round((centerY / canvasH) * 100);
    }

    const newNode: GameNode = {
      id: newId,
      name: isStart 
        ? (lang === 'ru' ? 'Стартовая Деревня 🏡' : 'Start Village 🏡')
        : isCastle 
          ? (lang === 'ru' ? 'Королевский Замок 👑' : 'Royal Castle 👑')
          : `${lang === 'ru' ? 'Поляна' : 'Tile'} #${editingNodes.length + 1}`,
      type: isCastle ? 'king_castle' : 'empty',
      x: spawnX,
      y: spawnY,
      neighbors: []
    };
    setEditingNodes([...editingNodes, newNode]);
    setSelectedNodeId(newId);
  };

  const handleDeleteNode = (nodeId: string) => {
    if (nodeId === 'start' || nodeId === 'king_castle') {
      alert(lang === 'ru' ? 'Нельзя удалять стартовую точку или замок!' : 'Cannot delete Start or King Castle node!');
      return;
    }
    // Remove node and connections to it
    const updated = editingNodes
      .filter(n => n.id !== nodeId)
      .map(n => ({
        ...n,
        neighbors: n.neighbors.filter(neighborId => neighborId !== nodeId)
      }));
    setEditingNodes(updated);
    setSelectedNodeId(updated[0]?.id || null);
    if (connectWithNodeId === nodeId) setConnectWithNodeId(null);
  };

  const handleUpdateNodeProp = (nodeId: string, key: keyof GameNode, value: any) => {
    setEditingNodes(prev => prev.map(n => {
      if (n.id === nodeId) {
        const updated = { ...n, [key]: value };
        
        // Auto-assign default town parameters if changed to 'town'
        if (key === 'type' && value === 'town') {
          if (!updated.townMonster) {
            updated.townMonster = {
              name: lang === 'ru' ? 'Свирепый Орк-Узурпатор 🐗' : 'Vicious Orc Usurper 🐗',
              stats: { hp: 70, maxHp: 70, atk: 18, def: 12, mg: 6, spd: 8 },
              rewardExp: 100,
              rewardGold: 150,
              isBoss: true
            };
          }
          if (updated.townTax === undefined) updated.townTax = 80;
          if (updated.townIncome === undefined) updated.townIncome = 40;
        }

        // Auto-assign default chest parameters if changed to 'chest'
        if (key === 'type' && value === 'chest') {
          if (updated.chestRewardType === undefined) updated.chestRewardType = 'gold';
        }

        return updated;
      }
      return n;
    }));
  };

  // Connecting two nodes toggler
  const handleToggleConnection = () => {
    if (!selectedNodeId || !connectWithNodeId || selectedNodeId === connectWithNodeId) return;

    setEditingNodes(prev => {
      return prev.map(n => {
        if (n.id === selectedNodeId) {
          const exists = n.neighbors.includes(connectWithNodeId);
          return {
            ...n,
            neighbors: exists 
              ? n.neighbors.filter(id => id !== connectWithNodeId)
              : [...n.neighbors, connectWithNodeId]
          };
        }
        if (n.id === connectWithNodeId) {
          const exists = n.neighbors.includes(selectedNodeId);
          return {
            ...n,
            neighbors: exists 
              ? n.neighbors.filter(id => id !== selectedNodeId)
              : [...n.neighbors, selectedNodeId]
          };
        }
        return n;
      });
    });
  };

  // Validation before save
  const handleSaveCurrentMap = () => {
    setValidationError(null);
    setSuccessMsg(null);

    // Ensure start exists
    const hasStart = editingNodes.some(n => n.id === 'start');
    if (!hasStart) {
      setValidationError(t.validationStartMissing);
      return;
    }

    // Ensure castle exists
    const hasCastle = editingNodes.some(n => n.id === 'king_castle');
    if (!hasCastle) {
      setValidationError(t.validationCastleMissing);
      return;
    }

    // Warning about orphans
    const hasOrphans = editingNodes.some(n => n.neighbors.length === 0);
    
    // Save map
    const updatedMaps = maps.map(m => {
      if (m.id === selectedMapId) {
        return {
          ...m,
          name: mapName.trim() || m.name,
          nodes: editingNodes
        };
      }
      return m;
    });

    saveAllMaps(updatedMaps);
    setSuccessMsg(t.saveSuccess + (hasOrphans ? ` (${t.validationOrphan})` : ''));
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  // Pointer events for panning camera and dragging nodes
  const handleEditorPointerDown = (e: React.PointerEvent) => {
    const target = e.target as HTMLElement;
    
    // Check if clicking a node element
    const nodeEl = target.closest('.clickable-node');
    if (nodeEl) {
      const nodeId = nodeEl.getAttribute('data-node-id');
      if (nodeId) {
        setDraggedNodeId(nodeId);
        setSelectedNodeId(nodeId);
        setConnectWithNodeId(null);
        try {
          nodeEl.setPointerCapture(e.pointerId);
        } catch (err) {}
      }
      return;
    }

    if (target.closest('button') || target.closest('select') || target.closest('input')) {
      return;
    }

    // Set dragging camera state
    setEditorPanState({
      isPanning: true,
      startX: e.clientX,
      startY: e.clientY,
      scrollLeft: editorViewportRef.current?.scrollLeft || 0,
      scrollTop: editorViewportRef.current?.scrollTop || 0
    });
    try {
      target.setPointerCapture(e.pointerId);
    } catch (err) {}
  };

  const handleEditorPointerMove = (e: React.PointerEvent) => {
    if (draggedNodeId && canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      const rawX = ((e.clientX - rect.left) / rect.width) * 100;
      const rawY = ((e.clientY - rect.top) / rect.height) * 100;
      const newX = Math.max(2, Math.min(98, Math.round(rawX)));
      const newY = Math.max(2, Math.min(98, Math.round(rawY)));
      
      setEditingNodes(prev => prev.map(n => {
        if (n.id === draggedNodeId) {
          return { ...n, x: newX, y: newY };
        }
        return n;
      }));
      return;
    }

    if (editorPanState.isPanning && editorViewportRef.current) {
      e.preventDefault();
      const dx = e.clientX - editorPanState.startX;
      const dy = e.clientY - editorPanState.startY;
      editorViewportRef.current.scrollLeft = editorPanState.scrollLeft - dx;
      editorViewportRef.current.scrollTop = editorPanState.scrollTop - dy;
    }
  };

  const handleEditorPointerUp = (e: React.PointerEvent) => {
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {}
    setEditorPanState(prev => ({ ...prev, isPanning: false }));
    setDraggedNodeId(null);
  };

  const selectedNode = editingNodes.find(n => n.id === selectedNodeId);

  return (
    <div id="map-editor-screen" className="min-h-screen bg-slate-950 text-slate-100 p-6 flex flex-col font-sans select-none">
      
      {/* Header Bar */}
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-900 pb-4 mb-6">
        <div>
          <button 
            onClick={onBackToMenu}
            className="flex items-center gap-2 text-xs font-bold text-amber-500 hover:text-amber-400 cursor-pointer uppercase tracking-wider mb-2"
          >
            <ArrowLeft className="w-4 h-4" />
            {t.back}
          </button>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2 font-display">
            <Layout className="w-6 h-6 text-amber-500" />
            {t.title}
          </h1>
          <p className="text-xs text-slate-400 mt-1">{t.subtitle}</p>
        </div>

        <div className="flex gap-2">
          {selectedMapId && (
            <button
              onClick={handleSaveCurrentMap}
              className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black rounded-xl cursor-pointer text-xs uppercase tracking-wider shadow-md flex items-center gap-1.5 transition-all"
            >
              <Save className="w-4 h-4" />
              {t.saveBtn}
            </button>
          )}
          <button
            onClick={() => setSelectedMapId(null)}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold rounded-xl cursor-pointer text-xs uppercase tracking-wider transition-colors"
          >
            {t.exitEditor}
          </button>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-hidden">
        
        {/* Left Side: Map List / Help Guide */}
        <div className="lg:col-span-3 flex flex-col gap-6 max-h-[80vh] overflow-y-auto">
          
          {/* Map List */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5">
            <h2 className="text-sm font-black uppercase text-slate-300 tracking-wider mb-4 flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-amber-400" />
              {t.myMaps}
            </h2>

            <div className="space-y-2 mb-4">
              {maps.length === 0 ? (
                <p className="text-xs text-slate-500 italic p-3 text-center bg-slate-950/50 rounded-xl border border-slate-800/40">
                  {t.noCustomMaps}
                </p>
              ) : (
                maps.map(map => {
                  const isSelected = map.id === selectedMapId;
                  const isConfirming = map.id === confirmDeleteMapId;

                  if (isConfirming) {
                    return (
                      <div
                        key={map.id}
                        className="p-3 rounded-2xl border-2 border-red-500 bg-red-950/25 flex items-center justify-between"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <span className="text-[10px] font-black uppercase text-red-400">
                          {lang === 'ru' ? 'Удалить?' : 'Delete?'}
                        </span>
                        <div className="flex gap-1.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleConfirmDelete(map.id);
                            }}
                            className="px-2 py-1 bg-red-600 hover:bg-red-500 text-white rounded text-[10px] font-bold transition-all cursor-pointer"
                          >
                            {lang === 'ru' ? 'Да' : 'Yes'}
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmDeleteMapId(null);
                            }}
                            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-bold transition-all cursor-pointer"
                          >
                            {lang === 'ru' ? 'Нет' : 'No'}
                          </button>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={map.id}
                      onClick={() => handleSelectMap(map)}
                      className={`group p-3 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between ${
                        isSelected 
                          ? 'bg-amber-950/20 border-amber-500' 
                          : 'bg-slate-950/40 border-slate-850 hover:bg-slate-950/80 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Map className={`w-4 h-4 flex-shrink-0 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                        <span className={`text-xs font-black truncate ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                          {map.name}
                        </span>
                      </div>
                      
                      <button
                        onClick={(e) => handleDeleteMap(map.id, e)}
                        className="p-1.5 hover:bg-red-500/10 text-slate-500 hover:text-red-400 rounded-lg cursor-pointer transition-all flex-shrink-0"
                        title={lang === 'ru' ? 'Удалить карту' : 'Delete board'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            {/* Creation Buttons */}
            <div className="space-y-2 pt-3 border-t border-slate-850">
              <button
                onClick={handleCreateNewMap}
                className="w-full py-2.5 px-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold rounded-xl cursor-pointer text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md"
              >
                <Plus className="w-4 h-4" />
                {t.createBtn}
              </button>

              <button
                onClick={handleCopyDefaultMap}
                className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-extrabold rounded-xl cursor-pointer text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                {t.defaultMapCopy}
              </button>
            </div>
          </div>

          {/* Quick Guide */}
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-3xl p-5">
            <h3 className="text-xs font-black uppercase text-amber-500 tracking-wider mb-2.5 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4" />
              {t.helpTitle}
            </h3>
            <ul className="text-[10px] text-slate-400 space-y-2 font-medium">
              <li>{t.helpStep1}</li>
              <li>{t.helpStep2}</li>
              <li>{t.helpStep3}</li>
              <li>{t.helpStep4}</li>
            </ul>
          </div>

        </div>

        {/* Right Side: Interactive 2D Grid & Controls */}
        <div className="lg:col-span-9 flex flex-col md:flex-row gap-6 max-h-[80vh]">
          
          {selectedMapId ? (
            <>
              {/* Center: The Board Visual Editor Grid */}
              <div className="flex-1 bg-slate-900 border border-slate-800 rounded-3xl p-4 flex flex-col overflow-hidden relative">
                
                {/* Map Name input */}
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3 mb-4">
                  <Edit3 className="w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={mapName}
                    onChange={(e) => setMapName(e.target.value)}
                    placeholder={t.mapNamePlaceholder}
                    className="bg-transparent text-sm font-black text-white focus:outline-none w-full border-b border-transparent focus:border-slate-700 pb-0.5"
                  />
                </div>

                {/* The 2D coordinate grid canvas viewport */}
                <div 
                  ref={editorViewportRef}
                  onPointerDown={handleEditorPointerDown}
                  onPointerMove={handleEditorPointerMove}
                  onPointerUp={handleEditorPointerUp}
                  className="flex-1 bg-slate-950 rounded-2xl relative border border-slate-850 overflow-hidden min-h-[400px] cursor-grab active:cursor-grabbing select-none"
                  style={{ touchAction: 'none' }}
                >
                  
                  {/* The actual massive virtual canvas where nodes exist */}
                  <div 
                    ref={canvasRef}
                    className="w-[2400px] h-[1800px] absolute bg-slate-950 bg-[radial-gradient(#1e293b_1.5px,transparent_1.5px)] [background-size:24px_24px] select-none"
                  >
                    
                    {/* Visual connections lines */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none">
                      {editingNodes.map(node => {
                        return node.neighbors.map(neighId => {
                          const neigh = editingNodes.find(n => n.id === neighId);
                          if (neigh) {
                            return (
                              <line
                                key={`${node.id}-${neigh.id}`}
                                x1={`${node.x}%`}
                                y1={`${node.y}%`}
                                x2={`${neigh.x}%`}
                                y2={`${neigh.y}%`}
                                className="stroke-amber-500/35 hover:stroke-amber-400/80 stroke-2 transition-all"
                              />
                            );
                          }
                          return null;
                        });
                      })}
                    </svg>

                    {/* Render Node Circles inside the custom canvas map space (clean solid discs with type indicators) */}
                    {editingNodes.map(node => {
                      const isSelected = node.id === selectedNodeId;
                      const isTarget = node.id === connectWithNodeId;
                      
                      // Colors based on Node type
                      let nodeColor = 'bg-emerald-500 ring-emerald-400/40';
                      if (node.id === 'start') nodeColor = 'bg-teal-400 ring-teal-400/30';
                      else if (node.id === 'king_castle') nodeColor = 'bg-amber-500 ring-amber-400/30';
                      else if (node.type === 'shop') nodeColor = 'bg-indigo-500 ring-indigo-400/45';
                      else if (node.type === 'chest') nodeColor = 'bg-yellow-500 ring-yellow-400/45';
                      else if (node.type === 'town') nodeColor = 'bg-rose-500 ring-rose-400/45';

                      return (
                        <button
                          key={node.id}
                          data-node-id={node.id}
                          style={{
                            left: `${node.x}%`,
                            top: `${node.y}%`,
                            transform: 'translate(-50%, -50%)',
                            touchAction: 'none'
                          }}
                          className={`clickable-node absolute w-9 h-9 rounded-full flex items-center justify-center font-black font-sans text-xs text-slate-950 transition-all cursor-pointer ring-4 ${nodeColor} ${
                            isSelected 
                              ? 'scale-125 border-4 border-white ring-amber-500/70 z-20 shadow-lg shadow-amber-500/30' 
                              : isTarget 
                                ? 'scale-115 border-2 border-yellow-400 ring-yellow-400/50 z-10' 
                                : 'hover:scale-110'
                          }`}
                          title={`${node.name} (${node.id})`}
                        >
                          {node.id === 'start' ? 'S' : node.id === 'king_castle' ? 'C' : ''}
                        </button>
                      );
                    })}

                    {/* Empty Map Guide Overlay */}
                    {editingNodes.length === 0 && (
                      <div className="absolute inset-0 flex flex-col justify-center items-center text-center p-6 z-10 pointer-events-none">
                        <span className="text-3xl mb-2 animate-bounce">📍</span>
                        <p className="text-xs font-black text-amber-500 uppercase tracking-widest">Карта пуста</p>
                        <p className="text-[11px] text-slate-400 mt-1 max-w-xs leading-relaxed">
                          {lang === 'ru' 
                            ? 'Используйте кнопку "+ Добавить клетку" справа, чтобы начать проектирование вашего игрового мира!' 
                            : 'Use the "+ Add Tile" button on the right to start building your custom world!'}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Canvas instructions */}
                  <div className="absolute bottom-3 left-3 text-[10px] text-slate-300 bg-slate-900/95 px-3 py-1.5 rounded-xl border border-slate-800 pointer-events-none font-sans font-bold flex items-center gap-1.5 shadow-md z-10 max-w-[80%]">
                    <span className="text-amber-500">💡</span>
                    <span>
                      {lang === 'ru' 
                        ? 'Перетаскивайте фон для движения • Перетаскивайте клетки зажатием клика!' 
                        : 'Drag background to pan view • Drag node circles directly to reposition!'}
                    </span>
                  </div>

                  <div className="absolute bottom-3 right-3 text-[10px] text-slate-500 bg-slate-900/85 px-2.5 py-1 rounded-md border border-slate-800 pointer-events-none font-mono z-10">
                    Карта: {editingNodes.length} кл. • Коорд: X(0-100) Y(0-100)
                  </div>
                </div>

                {/* Footer validation messages */}
                <div className="mt-4">
                  {validationError && (
                    <div className="flex items-center gap-2 text-xs font-bold text-red-400 bg-red-950/20 border border-red-900/60 p-3 rounded-xl">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{validationError}</span>
                    </div>
                  )}

                  {successMsg && (
                    <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 bg-emerald-950/20 border border-emerald-900/60 p-3 rounded-xl animate-bounce">
                      <CheckCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{successMsg}</span>
                    </div>
                  )}
                </div>

              </div>

              {/* Right: Selected Node Properties panel with rich capabilities */}
              <div className="w-full md:w-80 bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between overflow-y-auto">
                <div className="space-y-5">
                  <h3 className="text-sm font-black uppercase text-slate-300 tracking-wider flex items-center gap-1.5 border-b border-slate-850 pb-2">
                    <Layout className="w-4 h-4 text-amber-500" />
                    {t.nodeSettings}
                  </h3>

                  {selectedNode ? (
                    <div className="space-y-4">
                      
                      {/* Node Name */}
                      <div>
                        <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1.5 font-bold">
                          {t.nodeName}
                        </label>
                        <input
                          type="text"
                          value={selectedNode.name}
                          onChange={(e) => handleUpdateNodeProp(selectedNode.id, 'name', e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 font-bold focus:outline-none focus:border-amber-500"
                        />

                        {/* Name presets helper for easy creation */}
                        <div className="mt-2 flex flex-wrap gap-1">
                          {lang === 'ru' ? (
                            ['Поляна 🌿', 'Лес магии 🌲', 'Торговый тракт', 'Болото зла 💀', 'Древние руины'].map(preset => (
                              <button
                                key={preset}
                                onClick={() => handleUpdateNodeProp(selectedNode.id, 'name', preset)}
                                className="px-2 py-0.5 bg-slate-950 hover:bg-slate-800 rounded text-[9px] font-bold text-slate-400 hover:text-white transition-all cursor-pointer"
                              >
                                {preset}
                              </button>
                            ))
                          ) : (
                            ['Plains 🌿', 'Magic Woods 🌲', 'Highway', 'Swamp 💀', 'Ancient Ruins'].map(preset => (
                              <button
                                key={preset}
                                onClick={() => handleUpdateNodeProp(selectedNode.id, 'name', preset)}
                                className="px-2 py-0.5 bg-slate-950 hover:bg-slate-800 rounded text-[9px] font-bold text-slate-400 hover:text-white transition-all cursor-pointer"
                              >
                                {preset}
                              </button>
                            ))
                          )}
                        </div>
                      </div>

                      {/* Special Role Assignment Panel */}
                      <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-850 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] uppercase font-mono font-bold text-slate-400">
                            {lang === 'ru' ? 'Старт игры (ID: start)' : 'Is Start Node'}
                          </span>
                          <button
                            onClick={() => makeNodeSpecial(selectedNode.id, 'start')}
                            disabled={selectedNode.id === 'start'}
                            className={`px-2.5 py-1 text-[9px] font-black rounded-lg transition-all ${
                              selectedNode.id === 'start'
                                ? 'bg-teal-500 text-slate-950 cursor-default'
                                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 cursor-pointer'
                            }`}
                          >
                            {selectedNode.id === 'start' ? '🏡 АКТИВЕН' : 'НАЗНАЧИТЬ'}
                          </button>
                        </div>

                        <div className="flex items-center justify-between border-t border-slate-900 pt-2.5">
                          <span className="text-[9px] uppercase font-mono font-bold text-slate-400">
                            {lang === 'ru' ? 'Замок короля (ID: king_castle)' : 'Is King Castle'}
                          </span>
                          <button
                            onClick={() => makeNodeSpecial(selectedNode.id, 'king_castle')}
                            disabled={selectedNode.id === 'king_castle'}
                            className={`px-2.5 py-1 text-[9px] font-black rounded-lg transition-all ${
                              selectedNode.id === 'king_castle'
                                ? 'bg-amber-500 text-slate-950 cursor-default'
                                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 cursor-pointer'
                            }`}
                          >
                            {selectedNode.id === 'king_castle' ? '👑 АКТИВЕН' : 'НАЗНАЧИТЬ'}
                          </button>
                        </div>
                      </div>

                      {/* Node Type Selector */}
                      <div>
                        <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1.5 font-bold">
                          {t.nodeType}
                        </label>
                        <select
                          value={selectedNode.type}
                          disabled={selectedNode.id === 'king_castle'}
                          onChange={(e) => handleUpdateNodeProp(selectedNode.id, 'type', e.target.value as NodeType)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 font-bold focus:outline-none focus:border-amber-500 cursor-pointer"
                        >
                          <option value="empty">{t.empty}</option>
                          <option value="shop">{t.shop}</option>
                          <option value="town">{t.town}</option>
                          <option value="chest">{t.chest}</option>
                          <option value="king_castle">{t.king_castle}</option>
                        </select>
                      </div>

                      {/* Conditional Chest Parameters */}
                      {selectedNode.type === 'chest' && (
                        <div>
                          <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1.5 font-bold">
                            💰 {lang === 'ru' ? 'Награда из сундука' : 'Chest Reward'}
                          </label>
                          <select
                            value={selectedNode.chestRewardType || 'gold'}
                            onChange={(e) => handleUpdateNodeProp(selectedNode.id, 'chestRewardType', e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-300 font-bold focus:outline-none focus:border-amber-500 cursor-pointer"
                          >
                            <option value="gold">💰 {lang === 'ru' ? 'Золотые монеты' : 'Gold coins'}</option>
                            <option value="item">🎒 {lang === 'ru' ? 'Полезный предмет' : 'Valuable Item'}</option>
                            <option value="spell">⚡ {lang === 'ru' ? 'Свиток магии' : 'Magic Spell'}</option>
                          </select>
                        </div>
                      )}

                      {/* Conditional Town Parameters */}
                      {selectedNode.type === 'town' && (
                        <div className="space-y-3 bg-slate-950/40 p-3 rounded-2xl border border-slate-850">
                          <div>
                            <div className="flex justify-between text-[10px] uppercase font-mono text-slate-400 mb-1 font-bold">
                              <span>🪙 {lang === 'ru' ? 'Налог:' : 'Tax:'}</span>
                              <span className="text-white">{selectedNode.townTax ?? 80} G</span>
                            </div>
                            <input
                              type="range"
                              min="20"
                              max="400"
                              step="10"
                              value={selectedNode.townTax ?? 80}
                              onChange={(e) => handleUpdateNodeProp(selectedNode.id, 'townTax', parseInt(e.target.value))}
                              className="w-full accent-rose-500 cursor-pointer h-1 rounded bg-slate-800"
                            />
                          </div>

                          <div>
                            <div className="flex justify-between text-[10px] uppercase font-mono text-slate-400 mb-1 font-bold">
                              <span>📈 {lang === 'ru' ? 'Доход:' : 'Income:'}</span>
                              <span className="text-white">{selectedNode.townIncome ?? 40} G</span>
                            </div>
                            <input
                              type="range"
                              min="10"
                              max="200"
                              step="5"
                              value={selectedNode.townIncome ?? 40}
                              onChange={(e) => handleUpdateNodeProp(selectedNode.id, 'townIncome', parseInt(e.target.value))}
                              className="w-full accent-emerald-500 cursor-pointer h-1 rounded bg-slate-800"
                            />
                          </div>
                        </div>
                      )}

                      {/* Coordinates Sliders */}
                      <div>
                        <div className="flex justify-between text-[10px] uppercase font-mono text-slate-400 mb-1 font-bold">
                          <span>X: {selectedNode.x}%</span>
                          <span>Y: {selectedNode.y}%</span>
                        </div>
                        <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-slate-850">
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-mono font-bold text-slate-500">X</span>
                            <input
                              type="range"
                              min="5"
                              max="95"
                              value={selectedNode.x}
                              onChange={(e) => handleUpdateNodeProp(selectedNode.id, 'x', parseInt(e.target.value))}
                              className="flex-1 accent-amber-500 cursor-pointer h-1 rounded bg-slate-800"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-mono font-bold text-slate-500">Y</span>
                            <input
                              type="range"
                              min="5"
                              max="95"
                              value={selectedNode.y}
                              onChange={(e) => handleUpdateNodeProp(selectedNode.id, 'y', parseInt(e.target.value))}
                              className="flex-1 accent-amber-500 cursor-pointer h-1 rounded bg-slate-800"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Connection Tools */}
                      <div className="pt-2 border-t border-slate-850">
                        <label className="block text-[10px] uppercase font-mono text-slate-400 mb-1.5 font-bold flex items-center gap-1">
                          <Link className="w-3 h-3 text-slate-400" />
                          {t.connectNodes}
                        </label>
                        
                        <div className="space-y-2">
                          <select
                            value={connectWithNodeId || ''}
                            onChange={(e) => setConnectWithNodeId(e.target.value || null)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-300 font-bold focus:outline-none focus:border-amber-500 cursor-pointer"
                          >
                            <option value="">-- {t.connectWith} --</option>
                            {editingNodes
                              .filter(n => n.id !== selectedNode.id)
                              .map(n => {
                                const isConnected = selectedNode.neighbors.includes(n.id);
                                return (
                                  <option key={`connect-opt-${n.id}`} value={n.id}>
                                    {isConnected ? '✓ Connected to: ' : '✗ Link with: '} {n.name}
                                  </option>
                                );
                              })}
                          </select>

                          <button
                            onClick={handleToggleConnection}
                            disabled={!connectWithNodeId}
                            className={`w-full py-2 px-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                              connectWithNodeId 
                                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400' 
                                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                            }`}
                          >
                            <Link className="w-3.5 h-3.5" />
                            {t.toggleLink}
                          </button>
                        </div>
                      </div>

                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 italic">No node selected.</p>
                  )}
                </div>

                {/* Operations buttons */}
                <div className="space-y-2 mt-6 pt-4 border-t border-slate-850">
                  <button
                    onClick={handleAddNode}
                    className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-extrabold rounded-xl cursor-pointer text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Plus className="w-4 h-4 text-emerald-400" />
                    {t.addNode}
                  </button>

                  <button
                    onClick={() => selectedNodeId && handleDeleteNode(selectedNodeId)}
                    disabled={!selectedNodeId || selectedNodeId === 'start' || selectedNodeId === 'king_castle'}
                    className={`w-full py-2 px-3 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all ${
                      selectedNodeId && selectedNodeId !== 'start' && selectedNodeId !== 'king_castle'
                        ? 'bg-red-950/40 text-red-400 border border-red-900/60 hover:bg-red-900/30 cursor-pointer'
                        : 'bg-slate-850 text-slate-600 border border-transparent cursor-not-allowed'
                    }`}
                  >
                    <Trash2 className="w-4 h-4" />
                    {t.deleteNode}
                  </button>
                </div>

              </div>
            </>
          ) : (
            /* Selected map fallback visual */
            <div className="flex-1 bg-slate-900 border border-slate-800 rounded-3xl p-8 flex flex-col justify-center items-center text-center">
              <div className="w-20 h-20 bg-slate-950 rounded-full border border-slate-800 flex items-center justify-center mb-4">
                <Map className="w-10 h-10 text-amber-500" />
              </div>
              <h3 className="text-base font-black text-white">Редактирование карт DocoPixel6</h3>
              <p className="text-xs text-slate-400 max-w-sm mt-1">
                Выберите готовую карту из списка слева для её редактирования, создайте абсолютно новую с нуля, или скопируйте стандартное Королевство в качестве основы!
              </p>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
