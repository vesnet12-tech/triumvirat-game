import React, { useState, useEffect } from 'react';
import { Player, Monster, Stats, CombatState, CombatPhase, AttackerMove, DefenderMove, ClassType } from '../types';
import { CLASS_DEFINITIONS } from '../data/gameData';
import CharacterSkin from './CharacterSkin';
import { Swords, Shield, Heart, Sparkles, AlertTriangle, Play, HelpCircle, User, Award, Skull, RefreshCw } from 'lucide-react';

interface CombatScreenProps {
  player: Player;
  opponent: Player | Monster;
  isOpponentPlayer: boolean;
  townNodeId?: string;
  onCombatEnd: (result: {
    winnerId: string; // ID of player or 'monster'
    loserId: string; // ID of player or 'monster'
    goldChange: number;
    expChange: number;
    townLiberated: boolean;
    shameAction?: 'steal_gold' | 'steal_town' | 'steal_item' | 'shame_name' | null;
    shameNewName?: string | null;
  }) => void;
}

export default function CombatScreen({
  player,
  opponent,
  isOpponentPlayer,
  townNodeId,
  onCombatEnd
}: CombatScreenProps) {
  // 1. Initiative Choice State
  const [initiativeSelected, setInitiativeSelected] = useState<boolean>(false);
  const [playerChoosesFirst, setPlayerChoosesFirst] = useState<boolean>(true);
  const [initiativeLog, setInitiativeLog] = useState<string>('');

  // 2. Active combat participants states (to animate health deduction)
  const [playerHp, setPlayerHp] = useState<number>(player.stats.hp);
  const [opponentHp, setOpponentHp] = useState<number>(opponent.stats.hp);

  // Stats
  const playerStats = player.stats;
  const opponentStats = opponent.stats;

  // Active round state
  const [attackerIsPlayer, setAttackerIsPlayer] = useState<boolean>(true);
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [combatPhase, setCombatPhase] = useState<CombatPhase>('first_strike_choice');

  const [attackerMove, setAttackerMove] = useState<AttackerMove | null>(null);
  const [defenderMove, setDefenderMove] = useState<DefenderMove | null>(null);

  // Choice logs
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [animationEffect, setAnimationEffect] = useState<string | null>(null); // 'damage-p' | 'damage-o' | 'heal-p' | 'heal-o' | 'counter'

  // Shaming / Toxicity selection for PvP winning
  const [showShameModal, setShowShameModal] = useState<boolean>(false);
  const [shameAction, setShameAction] = useState<'steal_gold' | 'steal_town' | 'steal_item' | 'shame_name' | null>(null);
  const [newShameName, setNewShameName] = useState<string>('Криворукий Лузер');

  // Opponent name helper
  const getOpponentName = () => {
    if (isOpponentPlayer) {
      const p = opponent as Player;
      return p.shamedName || p.name;
    }
    return (opponent as Monster).name;
  };

  const getPlayerName = () => {
    return player.shamedName || player.name;
  };

  // Run initial card initiative draw
  const handleInitiativeSelection = (cardIndex: number) => {
    const playerWinsDraw = Math.random() > 0.45; // 55% chance or simple coin flip
    setPlayerChoosesFirst(playerWinsDraw);
    setAttackerIsPlayer(playerWinsDraw);
    setInitiativeLog(
      playerWinsDraw
        ? `Вы вытянули КАРТУ МЕЧА! ⚔️ Игрок ${getPlayerName()} бьет первым!`
        : `Противник вытянул КАРТУ МЕЧА! 🛡️ Игрок ${getPlayerName()} начинает в защите!`
    );
    setInitiativeSelected(true);
    setTimeout(() => {
      setCombatPhase('round_start');
    }, 2000);
  };

  // Handle combat AI for monsters or AI players
  const selectAiDefenderMove = (attMove: AttackerMove): DefenderMove => {
    // Smart probability-based defense choice
    const rand = Math.random();
    if (attMove === 'attack') {
      return rand < 0.65 ? 'defend' : rand < 0.85 ? 'give_up' : 'counter';
    } else if (attMove === 'strike') {
      return rand < 0.60 ? 'counter' : rand < 0.80 ? 'defend' : 'give_up';
    } else if (attMove === 'magic') {
      return rand < 0.70 ? 'mg_defend' : 'defend';
    } else {
      // skill
      return rand < 0.40 ? 'defend' : rand < 0.80 ? 'mg_defend' : 'counter';
    }
  };

  const selectAiAttackerMove = (): AttackerMove => {
    const rand = Math.random();
    // Class-specific AI attack bias
    if (!isOpponentPlayer) {
      // Monster
      return rand < 0.50 ? 'attack' : rand < 0.75 ? 'strike' : rand < 0.95 ? 'magic' : 'skill';
    }
    const aiOpp = opponent as Player;
    if (aiOpp.classType === 'warrior') {
      return rand < 0.45 ? 'attack' : rand < 0.80 ? 'strike' : 'skill';
    } else if (aiOpp.classType === 'mage') {
      return rand < 0.65 ? 'magic' : 'attack';
    } else if (aiOpp.classType === 'thief') {
      return rand < 0.45 ? 'attack' : rand < 0.75 ? 'skill' : 'strike';
    } else {
      // cleric
      return rand < 0.40 ? 'skill' : rand < 0.75 ? 'attack' : 'magic';
    }
  };

  // Trigger Combat Phase: Player selects Attack Action
  const handleAttackerChoice = (move: AttackerMove) => {
    setAttackerMove(move);
    setCombatPhase('defender_choice');

    // If opponent is AI or Monster, auto-choose its defense immediately
    if (!isOpponentPlayer || (opponent as Player).isAi) {
      const defMove = selectAiDefenderMove(move);
      executeRound(move, defMove);
    }
  };

  // Trigger Combat Phase: PvP defender selects Defense Action
  const handleDefenderChoice = (move: DefenderMove) => {
    if (attackerMove) {
      executeRound(attackerMove, move);
    }
  };

  // Execute Combat Calculations
  const executeRound = (att: AttackerMove, def: DefenderMove) => {
    setDefenderMove(def);
    setCombatPhase('result');

    const logs: string[] = [];
    let damageToDefender = 0;
    let damageToAttacker = 0;
    let healingToAttacker = 0;
    let goldStolen = 0;

    const activeAttStats = attackerIsPlayer ? playerStats : opponentStats;
    const activeDefStats = attackerIsPlayer ? opponentStats : playerStats;

    const attackerName = attackerIsPlayer ? getPlayerName() : getOpponentName();
    const defenderName = attackerIsPlayer ? getOpponentName() : getPlayerName();

    logs.push(`🛡️ Раунд ${roundNumber}: ${attackerName} использует [${att.toUpperCase()}], а ${defenderName} выбирает [${def.toUpperCase()}]!`);

    if (def === 'give_up') {
      logs.push(`🏳️ ${defenderName} сдался в страхе перед гибелью! Позор и бегство!`);
      damageToDefender = Math.floor(activeDefStats.hp * 0.4) + 1; // Heavy penalty, but lives
    } else {
      // Core Rock-Paper-Scissors rules
      switch (att) {
        case 'attack':
          if (def === 'defend') {
            // Perfect block
            damageToDefender = Math.max(1, Math.floor((activeAttStats.atk - activeDefStats.def * 1.2) * 0.2));
            logs.push(`🛡️ Идеальный блок! ${defenderName} поглотил практически весь урон.`);
          } else if (def === 'counter') {
            // Counter failed! Take extra damage
            damageToDefender = Math.max(5, Math.floor((activeAttStats.atk - activeDefStats.def * 0.5) * 1.5));
            logs.push(`💥 Ошибка контратаки! ${defenderName} не угадал выпад и получил сокрушительный удар.`);
          } else if (def === 'mg_defend') {
            // Magic defense fails to physical attack
            damageToDefender = Math.max(5, Math.floor(activeAttStats.atk - activeDefStats.def * 0.8));
            logs.push(`🎯 Магический барьер бесполезен против стали! ${defenderName} получает полный урон.`);
          }
          break;

        case 'strike':
          if (def === 'defend') {
            // Defend fails to Strike
            damageToDefender = Math.max(8, Math.floor((activeAttStats.atk * 1.5) - activeDefStats.def * 0.4));
            logs.push(`🔨 Пробитие защиты! Сверх-удар полностью расколол щит ${defenderName}.`);
          } else if (def === 'counter') {
            // Counter SUCCEEDED! Deals massive counter back!
            damageToAttacker = Math.max(15, Math.floor((activeDefStats.atk * 2.2) - activeAttStats.def * 0.5));
            setAnimationEffect('counter');
            logs.push(`⚡️ КОНТРАТАКА! ${defenderName} перехватил медленный замах и нанес невероятный ответный удар!`);
          } else if (def === 'mg_defend') {
            damageToDefender = Math.max(10, Math.floor((activeAttStats.atk * 1.4) - activeDefStats.def * 0.5));
            logs.push(`🎯 Сверх-удар разрывает магическую ауру ${defenderName}.`);
          }
          break;

        case 'magic':
          // Use Mage spells or default flame power
          const spellPower = attackerIsPlayer 
            ? (player.spells[0]?.power || 15) 
            : (isOpponentPlayer ? ((opponent as Player).spells[0]?.power || 15) : 12);
          
          if (def === 'mg_defend') {
            damageToDefender = Math.max(2, Math.floor(((activeAttStats.mg * spellPower / 10) - activeDefStats.mg * 1.3) * 0.2));
            logs.push(`🔮 Магическое сопротивление! ${defenderName} рассеял заклинание заклинанием оберега.`);
          } else if (def === 'defend' || def === 'counter') {
            damageToDefender = Math.max(6, Math.floor((activeAttStats.mg * spellPower / 10) - activeDefStats.mg * 0.6));
            logs.push(`🔥 Магическое пламя испепеляет физический щит! ${defenderName} горит.`);
          }
          break;

        case 'skill':
          // Class Specific Skills
          const activeClass = attackerIsPlayer ? player.classType : (isOpponentPlayer ? (opponent as Player).classType : 'warrior');
          
          if (activeClass === 'warrior') {
            // Decimate: 1.7x ATK. Recoil 15% of damage dealt.
            const fullDmg = Math.max(12, Math.floor((activeAttStats.atk * 1.7) - activeDefStats.def * 0.8));
            if (def === 'counter') {
              damageToAttacker = Math.max(15, Math.floor((activeDefStats.atk * 2.0)));
              logs.push(`⚡️ Контратака на умение! ${defenderName} поймал ярость воина!`);
            } else {
              damageToDefender = def === 'defend' ? Math.floor(fullDmg * 0.3) : fullDmg;
              damageToAttacker = Math.floor(damageToDefender * 0.15);
              logs.push(`🪓 [Сокрушение] Воин наносит ${damageToDefender} ед. урона, но страдает от отдачи в ${damageToAttacker} ОЗ!`);
            }
          } else if (activeClass === 'mage') {
            // Void Sparks: ignores normal shields.
            const baseMgDmg = Math.max(10, Math.floor(activeAttStats.mg * 1.4));
            damageToDefender = def === 'mg_defend' ? Math.floor(baseMgDmg * 0.4) : baseMgDmg;
            logs.push(`✨ [Искры Бездны] Обходит физическую защиту! ${defenderName} поражен искрами.`);
          } else if (activeClass === 'thief') {
            // Pickpocket: moderate dmg + steal gold
            damageToDefender = Math.max(4, Math.floor(activeAttStats.atk * 1.1 - activeDefStats.def * 0.6));
            if (attackerIsPlayer) {
              goldStolen = Math.floor(Math.random() * 80) + 40;
            } else if (isOpponentPlayer) {
              goldStolen = Math.floor(Math.random() * 80) + 40;
            }
            logs.push(`💰 [Карманная кража] Воришка ранит цель и ловко вытягивает ${goldStolen} золотых!`);
          } else {
            // Cleric: Divine Heal
            healingToAttacker = 35;
            logs.push(`😇 [Святое Исцеление] Клирик возносит молитву к небесам и исцеляет себя на +${healingToAttacker} ОЗ!`);
          }
          break;
      }
    }

    // Apply Health changes in state
    if (attackerIsPlayer) {
      const finalOppHp = Math.max(0, opponentHp - damageToDefender);
      const finalPlayHp = Math.max(0, Math.min(player.stats.maxHp, playerHp - damageToAttacker + healingToAttacker));
      setOpponentHp(finalOppHp);
      setPlayerHp(finalPlayHp);
      
      if (damageToDefender > 0) setAnimationEffect('damage-o');
      if (damageToAttacker > 0) setAnimationEffect('damage-p');
      if (healingToAttacker > 0) setAnimationEffect('heal-p');
    } else {
      const finalPlayHp = Math.max(0, playerHp - damageToDefender);
      const finalOppHp = Math.max(0, Math.min(opponent.stats.maxHp, opponentHp - damageToAttacker + healingToAttacker));
      setPlayerHp(finalPlayHp);
      setOpponentHp(finalOppHp);

      if (damageToDefender > 0) setAnimationEffect('damage-p');
      if (damageToAttacker > 0) setAnimationEffect('damage-o');
      if (healingToAttacker > 0) setAnimationEffect('heal-o');
    }

    // Apply gold stolen (if PvP and valid)
    if (goldStolen > 0) {
      if (attackerIsPlayer && isOpponentPlayer) {
        // Human player stole from opponent
        (opponent as Player).gold = Math.max(0, (opponent as Player).gold - goldStolen);
        player.gold += goldStolen;
      } else if (!attackerIsPlayer && isOpponentPlayer) {
        // AI stole from human
        player.gold = Math.max(0, player.gold - goldStolen);
        (opponent as Player).gold += goldStolen;
      }
    }

    setBattleLog(prev => [...prev, ...logs]);

    // Check if Battle Ends
    setTimeout(() => {
      setAnimationEffect(null);

      // Check deaths
      const isPlayerDead = attackerIsPlayer ? (playerHp - damageToAttacker + healingToAttacker <= 0) : (playerHp - damageToDefender <= 0);
      const isOpponentDead = attackerIsPlayer ? (opponentHp - damageToDefender <= 0) : (opponentHp - damageToAttacker + healingToAttacker <= 0);

      if (isPlayerDead || isOpponentDead || def === 'give_up') {
        // Set phase to ended
        setCombatPhase('ended');
      } else {
        // Switch turn owner and increase round
        setAttackerIsPlayer(prev => !prev);
        setRoundNumber(prev => prev + 1);
        setAttackerMove(null);
        setDefenderMove(null);
        setCombatPhase('round_start');
      }
    }, 2500);
  };

  // Trigger Combat End & Reward Handout
  const finalizeCombat = () => {
    const isPlayerWin = opponentHp <= 0 || defenderMove === 'give_up' && !attackerIsPlayer;
    const isOpponentWin = playerHp <= 0 || defenderMove === 'give_up' && attackerIsPlayer;

    let winnerId = '';
    let loserId = '';
    let goldChange = 0;
    let expChange = 0;
    let townLiberated = false;

    if (isPlayerWin) {
      winnerId = player.id;
      loserId = isOpponentPlayer ? (opponent as Player).id : 'monster';
      
      if (!isOpponentPlayer) {
        // Monster loot
        const m = opponent as Monster;
        goldChange = m.rewardGold;
        expChange = m.rewardExp;
        if (townNodeId) {
          townLiberated = true;
        }
      } else {
        // PvP looting basic
        const p = opponent as Player;
        goldChange = Math.floor(p.gold * 0.3); // steal 30% gold
      }
    } else {
      winnerId = isOpponentPlayer ? (opponent as Player).id : 'monster';
      loserId = player.id;
      
      // Lost to monster: penalty
      if (!isOpponentPlayer) {
        goldChange = -Math.floor(player.gold * 0.2); // lose 20% gold
      } else {
        // Lost to player: penalty basic
        goldChange = -Math.floor(player.gold * 0.3);
      }
    }

    // Check if PvP and winner is human player, prompt Toxic Choice!
    if (isPlayerWin && isOpponentPlayer) {
      setShowShameModal(true);
    } else {
      // AI winning PvP choice is automated
      let pvpShameAction: any = null;
      let pvpShameName: any = null;
      if (isOpponentWin && isOpponentPlayer) {
        // AI opponent won PvP
        const choices: ('steal_gold' | 'shame_name')[] = ['steal_gold', 'shame_name'];
        pvpShameAction = choices[Math.floor(Math.random() * choices.length)];
        pvpShameName = pvpShameAction === 'shame_name' ? 'Докапонский Неудачник 💩' : null;
      }

      onCombatEnd({
        winnerId,
        loserId,
        goldChange,
        expChange,
        townLiberated,
        shameAction: pvpShameAction,
        shameNewName: pvpShameName
      });
    }
  };

  const handleShameSelection = () => {
    const isPlayerWin = opponentHp <= 0 || defenderMove === 'give_up' && !attackerIsPlayer;
    const winnerId = player.id;
    const loserId = (opponent as Player).id;
    const goldChange = shameAction === 'steal_gold' ? Math.floor((opponent as Player).gold * 0.6) : Math.floor((opponent as Player).gold * 0.2);

    onCombatEnd({
      winnerId,
      loserId,
      goldChange,
      expChange: 150, // bonus exp for PvP triumph
      townLiberated: false,
      shameAction,
      shameNewName: shameAction === 'shame_name' ? newShameName : null
    });
  };

  return (
    <div id="combat-overlay" className="fixed inset-0 z-50 bg-slate-950/90 flex items-center justify-center p-4 overflow-y-auto backdrop-blur-md">
      <div className="bg-slate-900 border-4 border-amber-600 rounded-3xl w-full max-w-4xl p-6 shadow-2xl relative flex flex-col md:h-[650px]">
        
        {/* Shaming / Toxicity Selection Modal */}
        {showShameModal && (
          <div className="absolute inset-0 bg-slate-950/95 z-50 rounded-2xl p-8 flex flex-col justify-center items-center text-center animate-fade-in">
            <Award className="w-16 h-16 text-yellow-400 mb-4 animate-bounce" />
            <h3 className="font-display text-3xl font-bold text-yellow-400 tracking-tight">ТРИУМФ НАД ИГРОКОМ! ⚔️🔥</h3>
            <p className="text-sm text-slate-300 mt-2 max-w-md">
              Вы одолели игрока <span className="text-red-400 font-bold">{getOpponentName()}</span> в честной дуэли! Выберите меру наказания для проигравшего соперника в духе Dokapon:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-2xl mt-8">
              <button
                onClick={() => setShameAction('steal_gold')}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                  shameAction === 'steal_gold' ? 'bg-amber-500/20 border-amber-400' : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-lg text-amber-400">💰 Ограбление</div>
                <p className="text-xs text-slate-400 mt-1">Украсть 60% накопленного золота соперника.</p>
              </button>

              <button
                onClick={() => setShameAction('steal_town')}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                  shameAction === 'steal_town' ? 'bg-amber-500/20 border-amber-400' : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-lg text-emerald-400">🏡 Конфискация</div>
                <p className="text-xs text-slate-400 mt-1">Забрать одну из освобожденных деревень соперника себе.</p>
              </button>

              <button
                onClick={() => setShameAction('shame_name')}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                  shameAction === 'shame_name' ? 'bg-amber-500/20 border-amber-400' : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-lg text-rose-400">🤡 Клеймо позора</div>
                <p className="text-xs text-slate-400 mt-1">Переименовать соперника в унизительное имя на 3 хода.</p>
              </button>
            </div>

            {shameAction === 'shame_name' && (
              <div className="mt-6 w-full max-w-md animate-fade-in">
                <label className="block text-xs font-mono uppercase text-rose-400 mb-1.5">Какое имя дать этому неудачнику?</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newShameName}
                    onChange={(e) => setNewShameName(e.target.value)}
                    className="flex-1 bg-slate-900 border-2 border-rose-500/30 rounded-xl px-4 py-2 text-slate-200 focus:outline-none focus:border-rose-500 text-sm"
                    placeholder="Новое имя"
                  />
                  <button
                    onClick={() => {
                      const funnyNames = ['Слюнявый Слайм 💧', 'Мусорный Гоблин 🗑️', 'Трус Дьявольский 🐔', 'Позор Докапона 💩', 'Пул Слёз 😢'];
                      setNewShameName(funnyNames[Math.floor(Math.random() * funnyNames.length)]);
                    }}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 text-xs cursor-pointer font-bold font-mono"
                  >
                    🎲 Рандом
                  </button>
                </div>
              </div>
            )}

            <button
              onClick={handleShameSelection}
              disabled={!shameAction}
              className="mt-8 py-3 px-8 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-extrabold text-sm rounded-xl disabled:opacity-40 shadow-lg shadow-amber-500/20 cursor-pointer uppercase transition-all"
            >
              Исполнить Приговор! ⚖️💥
            </button>
          </div>
        )}

        {/* 1. Initiative selection phase */}
        {combatPhase === 'first_strike_choice' && (
          <div className="flex-1 flex flex-col justify-center items-center text-center p-6">
            <Swords className="w-16 h-16 text-amber-500 mb-4 animate-pulse" />
            <h3 className="font-display text-2xl font-bold text-amber-400">Выбор Инициативы Битвы</h3>
            <p className="text-sm text-slate-300 mt-2 max-w-md">
              В Dokapon Kingdom очередность хода в бою решает судьбу! Выберите одну из карт инициативы, чтобы определить, кто бьет первым:
            </p>

            <div className="flex gap-6 mt-8">
              <button
                onClick={() => handleInitiativeSelection(0)}
                disabled={initiativeSelected}
                className="w-36 h-52 bg-gradient-to-b from-amber-600 to-amber-900 border-4 border-amber-400/80 rounded-2xl flex flex-col justify-center items-center hover:-translate-y-2 hover:shadow-2xl transition-all cursor-pointer group disabled:opacity-50"
              >
                <div className="text-4xl group-hover:scale-110 transition-transform">⚔️</div>
                <div className="text-xs uppercase font-mono tracking-wider font-bold text-amber-200 mt-3">КАРТА А</div>
              </button>

              <button
                onClick={() => handleInitiativeSelection(1)}
                disabled={initiativeSelected}
                className="w-36 h-52 bg-gradient-to-b from-slate-600 to-slate-900 border-4 border-slate-400/80 rounded-2xl flex flex-col justify-center items-center hover:-translate-y-2 hover:shadow-2xl transition-all cursor-pointer group disabled:opacity-50"
              >
                <div className="text-4xl group-hover:scale-110 transition-transform">🛡️</div>
                <div className="text-xs uppercase font-mono tracking-wider font-bold text-slate-200 mt-3">КАРТА Б</div>
              </button>
            </div>

            {initiativeLog && (
              <p className="mt-8 text-md font-bold text-amber-300 bg-slate-950/60 border border-amber-500/20 py-2.5 px-6 rounded-2xl animate-fade-in font-mono">
                {initiativeLog}
              </p>
            )}
          </div>
        )}

        {/* 2. Main combat arena phase */}
        {combatPhase !== 'first_strike_choice' && (
          <div className="flex-1 flex flex-col md:grid md:grid-rows-1 md:grid-cols-12 gap-4 h-full overflow-hidden">
            
            {/* Arena / Avatars - 7 Columns */}
            <div className="md:col-span-7 flex flex-col justify-between p-4 bg-slate-950/40 rounded-2xl border border-slate-800/80 relative">
              
              {/* Versus Display */}
              <div className="flex justify-between items-stretch gap-2">
                {/* Attacker (Red) */}
                <div className={`flex-1 p-3 rounded-xl border transition-all ${
                  attackerIsPlayer ? 'bg-red-500/10 border-red-500/40' : 'bg-slate-900 border-slate-800'
                } ${animationEffect === 'damage-p' ? 'animate-bounce border-red-500' : ''}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase text-red-400 font-mono font-bold">АТАКУЮЩИЙ</span>
                    {attackerIsPlayer && <span className="bg-red-500 text-slate-950 text-[9px] px-1 rounded font-bold font-mono">ХОД</span>}
                  </div>
                  <h4 className="font-display font-extrabold text-lg text-slate-100 mt-1 truncate">{getPlayerName()}</h4>
                  <p className="text-[10px] text-slate-400">{player.classType.toUpperCase()} • УР. {player.level}</p>

                  {/* HP Bar */}
                  <div className="mt-3">
                    <div className="flex justify-between text-xs font-mono mb-1 text-slate-300">
                      <span>ОЗ: {playerHp}/{player.stats.maxHp}</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-red-500 to-rose-600 h-full transition-all duration-300"
                        style={{ width: `${(playerHp / player.stats.maxHp) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-center font-display font-extrabold text-slate-500 text-xl px-2">
                  VS
                </div>

                {/* Defender (Blue) */}
                <div className={`flex-1 p-3 rounded-xl border transition-all ${
                  !attackerIsPlayer ? 'bg-blue-500/10 border-blue-500/40' : 'bg-slate-900 border-slate-800'
                } ${animationEffect === 'damage-o' ? 'animate-bounce border-blue-500' : ''}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-xs uppercase text-blue-400 font-mono font-bold">ЗАЩИЩАЮЩИЙСЯ</span>
                    {!attackerIsPlayer && <span className="bg-blue-500 text-slate-950 text-[9px] px-1 rounded font-bold font-mono">ХОД</span>}
                  </div>
                  <h4 className="font-display font-extrabold text-lg text-slate-100 mt-1 truncate">{getOpponentName()}</h4>
                  <p className="text-[10px] text-slate-400">
                    {isOpponentPlayer ? `${(opponent as Player).classType.toUpperCase()} • УР. ${(opponent as Player).level}` : 'ДИКИЙ МОНСТР'}
                  </p>

                  {/* HP Bar */}
                  <div className="mt-3">
                    <div className="flex justify-between text-xs font-mono mb-1 text-slate-300">
                      <span>ОЗ: {opponentHp}/{opponent.stats.maxHp}</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full transition-all duration-300"
                        style={{ width: `${(opponentHp / opponent.stats.maxHp) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Combat graphics scene simulation */}
              <div className="flex-1 flex items-center justify-center my-4 border border-slate-800/40 rounded-2xl relative overflow-hidden bg-slate-950/60 h-40">
                {/* Floating combat effects */}
                {animationEffect === 'counter' && (
                  <div className="absolute inset-0 bg-yellow-500/10 flex items-center justify-center animate-pulse z-10">
                    <span className="font-display font-black text-3xl text-yellow-400 tracking-wider uppercase animate-bounce">⚡️ КОНТРАТАКА ⚡️</span>
                  </div>
                )}
                {animationEffect === 'damage-o' && (
                  <div className="absolute right-1/4 top-1/3 animate-ping z-10">
                    <span className="font-display font-black text-3xl text-red-500 tracking-wider">💥 БУМ!</span>
                  </div>
                )}
                {animationEffect === 'damage-p' && (
                  <div className="absolute left-1/4 top-1/3 animate-ping z-10">
                    <span className="font-display font-black text-3xl text-red-500 tracking-wider">💥 БУМ!</span>
                  </div>
                )}
                {animationEffect === 'heal-p' && (
                  <div className="absolute left-1/4 top-1/3 animate-bounce z-10">
                    <span className="font-display font-black text-2xl text-emerald-400 tracking-wider">+ ОЗ</span>
                  </div>
                )}

                {/* Two simple fighting cards */}
                <div className="flex justify-around items-center w-full max-w-md px-4">
                  {/* Player Fighter Card */}
                  <div className={`p-4 rounded-2xl border-2 w-28 h-28 flex flex-col justify-between items-center shadow-lg transition-transform ${
                    attackerIsPlayer ? 'bg-red-950/60 border-red-500 scale-110' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div className="h-12 flex items-center justify-center select-none">
                      <CharacterSkin skinIndex={player.skinIndex || 1} size="lg" animate={true} />
                    </div>
                    <span className="text-xs font-semibold font-mono mt-1 truncate max-w-full">{getPlayerName()}</span>
                  </div>

                  <span className="font-mono text-slate-500 text-sm">раунд {roundNumber}</span>

                  {/* Opponent Fighter Card */}
                  <div className={`p-4 rounded-2xl border-2 w-28 h-28 flex flex-col justify-between items-center shadow-lg transition-transform ${
                    !attackerIsPlayer ? 'bg-blue-950/60 border-blue-500 scale-110' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div className="h-12 flex items-center justify-center select-none">
                      {isOpponentPlayer ? (
                        <CharacterSkin skinIndex={(opponent as Player).skinIndex || 2} size="lg" animate={true} />
                      ) : (
                        <span className="text-3xl">👹</span>
                      )}
                    </div>
                    <span className="text-xs font-semibold font-mono mt-1 truncate max-w-full">{getOpponentName()}</span>
                  </div>
                </div>
              </div>

              {/* ACTION CHOICE DRAWER */}
              <div className="mt-2">
                {/* Active Player Attack Phase Choices */}
                {combatPhase === 'round_start' && attackerIsPlayer && (
                  <div>
                    <span className="block text-xs text-red-400 font-mono font-bold uppercase mb-2 text-center">⚔️ ВАШ ХОД: ВЫБЕРИТЕ ПРИЕМ АТАКИ</span>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleAttackerChoice('attack')}
                        className="py-2.5 px-3 bg-red-950/80 hover:bg-red-900/80 border-2 border-red-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between group"
                      >
                        <div>
                          <div className="font-bold text-sm text-red-200">Attack (Обычный)</div>
                          <span className="text-[10px] text-slate-400">Блокируется Defend, бьет Counter</span>
                        </div>
                        <span className="text-lg opacity-40 group-hover:opacity-100">👊</span>
                      </button>

                      <button
                        onClick={() => handleAttackerChoice('strike')}
                        className="py-2.5 px-3 bg-orange-950/80 hover:bg-orange-900/80 border-2 border-orange-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between group"
                      >
                        <div>
                          <div className="font-bold text-sm text-orange-200">Strike (Сверх-удар)</div>
                          <span className="text-[10px] text-slate-400">Игнорит Defend, контрится Counter!</span>
                        </div>
                        <span className="text-lg opacity-40 group-hover:opacity-100">🔨</span>
                      </button>

                      <button
                        onClick={() => handleAttackerChoice('magic')}
                        className="py-2.5 px-3 bg-purple-950/80 hover:bg-purple-900/80 border-2 border-purple-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between group"
                      >
                        <div>
                          <div className="font-bold text-sm text-purple-200">Magic (Заклинание)</div>
                          <span className="text-[10px] text-slate-400">Урон от МАГ. Оберегается MG Defend</span>
                        </div>
                        <span className="text-lg opacity-40 group-hover:opacity-100">🔥</span>
                      </button>

                      <button
                        onClick={() => handleAttackerChoice('skill')}
                        className="py-2.5 px-3 bg-amber-950/80 hover:bg-amber-900/80 border-2 border-amber-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between group"
                      >
                        <div>
                          <div className="font-bold text-sm text-amber-200">Skill: {CLASS_DEFINITIONS[player.classType].skillNameRu}</div>
                          <span className="text-[10px] text-slate-400">{CLASS_DEFINITIONS[player.classType].skillDescriptionRu.substring(0, 36)}...</span>
                        </div>
                        <span className="text-lg opacity-40 group-hover:opacity-100">✨</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Active Player Defense Phase Choices (when opponent is attacker) */}
                {combatPhase === 'round_start' && !attackerIsPlayer && isOpponentPlayer && !(opponent as Player).isAi && (
                  <div>
                    <span className="block text-xs text-blue-400 font-mono font-bold uppercase mb-2 text-center">🛡️ ХОД ВТОРОГО ИГРОКА: ВЫБЕРИТЕ МЕРУ ЗАЩИТЫ</span>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleDefenderChoice('defend')}
                        className="py-2.5 px-3 bg-blue-950/80 hover:bg-blue-900/80 border-2 border-blue-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-sm text-blue-200">Defend (Защита)</div>
                          <span className="text-[10px] text-slate-400">Блокирует Attack, терпит Strike</span>
                        </div>
                        <span>🛡️</span>
                      </button>

                      <button
                        onClick={() => handleDefenderChoice('counter')}
                        className="py-2.5 px-3 bg-emerald-950/80 hover:bg-emerald-900/80 border-2 border-emerald-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-sm text-emerald-200">Counter (Контратака)</div>
                          <span className="text-[10px] text-slate-400">Шанс уничтожить Strike! Смерть от Attack</span>
                        </div>
                        <span>⚡️</span>
                      </button>

                      <button
                        onClick={() => handleDefenderChoice('mg_defend')}
                        className="py-2.5 px-3 bg-indigo-950/80 hover:bg-indigo-900/80 border-2 border-indigo-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-sm text-indigo-200">MG Defend (Маг-блок)</div>
                          <span className="text-[10px] text-slate-400">Поглощает урон от магии Magic</span>
                        </div>
                        <span>🔮</span>
                      </button>

                      <button
                        onClick={() => handleDefenderChoice('give_up')}
                        className="py-2.5 px-3 bg-slate-900 hover:bg-slate-800 border-2 border-slate-700/60 rounded-xl text-left hover:scale-102 cursor-pointer transition-all flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-sm text-slate-200">Give Up (Сдаться)</div>
                          <span className="text-[10px] text-slate-400">Сбежать, потеряв золото</span>
                        </div>
                        <span>🏳️</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* AI / Auto defense selection indicator */}
                {combatPhase === 'round_start' && !attackerIsPlayer && (!isOpponentPlayer || (opponent as Player).isAi) && (
                  <div className="bg-slate-900 p-4 border border-slate-800 rounded-xl text-center flex flex-col justify-center items-center">
                    <RefreshCw className="w-6 h-6 text-blue-400 animate-spin mb-2" />
                    <p className="text-sm font-semibold text-slate-300">Соперник готовится к отражению удара...</p>
                    <button
                      onClick={() => {
                        // Trigger AI action automatically
                        const aiAtt = selectAiAttackerMove();
                        handleAttackerChoice(aiAtt);
                      }}
                      className="mt-3 px-4 py-1.5 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs font-bold text-slate-100 transition-colors cursor-pointer"
                    >
                      Нажмите, чтобы запустить ход ИИ 🤖
                    </button>
                  </div>
                )}

                {/* Action Choice Pending for Opponent */}
                {combatPhase === 'defender_choice' && isOpponentPlayer && !(opponent as Player).isAi && (
                  <div className="bg-slate-900/90 p-4 border-2 border-dashed border-blue-500/50 rounded-xl text-center">
                    <p className="text-sm font-semibold text-blue-300">Игрок {getOpponentName()} выбирает действие защиты на клавиатуре или кликом...</p>
                    <div className="grid grid-cols-2 gap-2 mt-3">
                      <button onClick={() => handleDefenderChoice('defend')} className="py-2 px-3 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs font-bold text-white cursor-pointer">Defend (Обычный блок)</button>
                      <button onClick={() => handleDefenderChoice('counter')} className="py-2 px-3 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-xs font-bold text-white cursor-pointer">Counter (Контратака)</button>
                      <button onClick={() => handleDefenderChoice('mg_defend')} className="py-2 px-3 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-xs font-bold text-white cursor-pointer">MG Defend (Маг-блок)</button>
                      <button onClick={() => handleDefenderChoice('give_up')} className="py-2 px-3 bg-slate-700 hover:bg-slate-600 rounded-lg text-xs font-bold text-white cursor-pointer">Give Up (Сбежать)</button>
                    </div>
                  </div>
                )}

                {/* Turn results processing */}
                {combatPhase === 'result' && (
                  <div className="bg-slate-950 p-4 rounded-xl border border-amber-500/30 text-center animate-pulse">
                    <p className="text-amber-400 font-bold text-sm tracking-wide">⚔️ РЕЗУЛЬТАТ СТОЛКНОВЕНИЯ...</p>
                  </div>
                )}

                {/* Battle ended action to finalize */}
                {combatPhase === 'ended' && (
                  <div className="bg-slate-950 p-4 rounded-xl border-2 border-emerald-500/50 text-center">
                    <p className="text-emerald-400 font-extrabold text-lg">БИТВА ЗАВЕРШЕНА!</p>
                    <button
                      onClick={finalizeCombat}
                      className="mt-3 px-8 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-sm rounded-xl cursor-pointer shadow-lg shadow-emerald-500/10 uppercase"
                    >
                      Получить Результаты 🏆✨
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Battle Log Drawer - 5 Columns */}
            <div className="md:col-span-5 flex flex-col justify-between bg-slate-950/70 rounded-2xl border border-slate-800 p-4 h-60 md:h-full overflow-hidden">
              <span className="block text-xs text-slate-400 font-mono font-bold uppercase mb-2">📜 ЛЕТОПИСЬ СТОЛКНОВЕНИЯ (LOGS)</span>
              <div className="flex-1 overflow-y-auto space-y-2 pr-1 text-xs font-mono text-slate-300">
                {battleLog.length === 0 ? (
                  <p className="text-slate-500 italic">Сражение еще не началось. Ждем бросок карт инициативы...</p>
                ) : (
                  battleLog.map((log, i) => (
                    <div key={i} className="bg-slate-900/60 p-2 rounded-lg border border-slate-800/50">
                      {log}
                    </div>
                  ))
                )}
              </div>
              <div className="mt-4 bg-slate-900/80 p-2.5 border border-slate-800 rounded-xl text-center text-[10px] text-slate-400">
                <span>⚔️ Система Dokapon: Strike бьет Defend, Counter сокрушает Strike, а обычный Attack наказывает Counter!</span>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
