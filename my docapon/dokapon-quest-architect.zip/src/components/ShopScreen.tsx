import React, { useState } from 'react';
import { Player, Equipment, MagicSpell, UsableItem } from '../types';
import { WEAPONS_DB, SHIELDS_DB, SPELLS_DB, ITEMS_DB } from '../data/gameData';
import { ShoppingBag, Coins, Shield, Swords, Sparkles, Box, Check } from 'lucide-react';

interface ShopScreenProps {
  player: Player;
  onBuyEquipment: (eq: Equipment) => void;
  onBuySpell: (spell: MagicSpell) => void;
  onBuyItem: (item: UsableItem) => void;
  onClose: () => void;
}

type ShopTab = 'weapons' | 'shields' | 'spells' | 'items';

export default function ShopScreen({
  player,
  onBuyEquipment,
  onBuySpell,
  onBuyItem,
  onClose
}: ShopScreenProps) {
  const [activeTab, setActiveTab] = useState<ShopTab>('weapons');
  const [purchaseLog, setPurchaseLog] = useState<string | null>(null);

  const showNotification = (text: string) => {
    setPurchaseLog(text);
    setTimeout(() => setPurchaseLog(null), 3000);
  };

  const tryBuyEquipment = (eq: Equipment) => {
    if (player.gold < eq.cost) {
      showNotification('❌ Недостаточно золота для покупки!');
      return;
    }
    onBuyEquipment(eq);
    showNotification(`✅ Успешно куплено: ${eq.name}!`);
  };

  const tryBuySpell = (spell: MagicSpell) => {
    if (player.gold < spell.cost) {
      showNotification('❌ Недостаточно золота для покупки!');
      return;
    }
    if (player.spells.some(s => s.id === spell.id)) {
      showNotification('❌ Вы уже знаете это заклинание!');
      return;
    }
    onBuySpell(spell);
    showNotification(`✅ Успешно изучено: ${spell.name}!`);
  };

  const tryBuyItem = (item: UsableItem) => {
    if (player.gold < item.cost) {
      showNotification('❌ Недостаточно золота для покупки!');
      return;
    }
    if (player.items.length >= 6) {
      showNotification('❌ Сумка переполнена (макс. 6 предметов)!');
      return;
    }
    onBuyItem(item);
    showNotification(`✅ Куплено в инвентарь: ${item.name}!`);
  };

  return (
    <div id="shop-screen" className="bg-slate-950/95 border-2 border-emerald-500/40 rounded-2xl p-6 w-full max-w-2xl mx-auto shadow-2xl text-slate-100 flex flex-col h-[550px]">
      {/* Header */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/20 rounded-xl text-emerald-400">
            <ShoppingBag className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="font-display text-2xl font-bold text-emerald-400 tracking-tight">Лавка Чудес Dokapon</h3>
            <p className="text-xs text-slate-400">Снаряжение, магия боевые книги и походные свитки</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 py-1.5 px-3 rounded-xl">
          <Coins className="w-4 h-4 text-amber-400" />
          <span className="font-mono font-bold text-amber-300 text-lg">{player.gold}</span>
        </div>
      </div>

      {/* Purchase Log toast inside screen */}
      {purchaseLog && (
        <div className="bg-slate-800 border-l-4 border-emerald-500 py-2 px-4 rounded mb-4 text-sm font-semibold text-emerald-300 animate-bounce">
          {purchaseLog}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setActiveTab('weapons')}
          className={`flex-1 py-2 px-3 rounded-xl font-display font-semibold text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
            activeTab === 'weapons'
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-lg shadow-emerald-500/5'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
          }`}
        >
          <Swords className="w-4 h-4" />
          Оружие
        </button>
        <button
          onClick={() => setActiveTab('shields')}
          className={`flex-1 py-2 px-3 rounded-xl font-display font-semibold text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
            activeTab === 'shields'
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-lg shadow-emerald-500/5'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
          }`}
        >
          <Shield className="w-4 h-4" />
          Щиты
        </button>
        <button
          onClick={() => setActiveTab('spells')}
          className={`flex-1 py-2 px-3 rounded-xl font-display font-semibold text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
            activeTab === 'spells'
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-lg shadow-emerald-500/5'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Книги Заклинаний
        </button>
        <button
          onClick={() => setActiveTab('items')}
          className={`flex-1 py-2 px-3 rounded-xl font-display font-semibold text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
            activeTab === 'items'
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-lg shadow-emerald-500/5'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
          }`}
        >
          <Box className="w-4 h-4" />
          Спиннеры & Зелья
        </button>
      </div>

      {/* Inventory Info Panel */}
      <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 mb-4 text-xs flex items-center justify-between text-slate-400 font-mono">
        <div>Оружие: <span className="text-orange-400">{player.weapon?.name || 'Кулаки ✊'}</span></div>
        <div>Щит: <span className="text-blue-400">{player.shield?.name || 'Нет защитного щита'}</span></div>
        <div>Сумка: <span className="text-emerald-400">{player.items.length}/6</span></div>
      </div>

      {/* Items Container */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-3">
        {activeTab === 'weapons' && WEAPONS_DB.map(eq => {
          const isEquipped = player.weapon?.id === eq.id;
          return (
            <div key={eq.id} className="flex justify-between items-center bg-slate-900/80 border border-slate-800/80 p-3 rounded-xl hover:border-slate-700/80 transition-all">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-display font-bold text-slate-200">{eq.name}</span>
                  {isEquipped && <span className="bg-orange-500/20 text-orange-400 text-[9px] uppercase px-1.5 py-0.5 rounded font-mono font-bold">Экипировано</span>}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{eq.description}</p>
                <div className="flex gap-2 text-[10px] text-orange-400 mt-1 font-mono">
                  {eq.bonusAtk > 0 && <span>+ {eq.bonusAtk} Атака</span>}
                  {eq.bonusDef > 0 && <span>+ {eq.bonusDef} Защита</span>}
                  {eq.bonusMg > 0 && <span>+ {eq.bonusMg} Магия</span>}
                  {eq.bonusSpd !== 0 && <span>{eq.bonusSpd > 0 ? '+' : ''}{eq.bonusSpd} Скорость</span>}
                </div>
              </div>
              <button
                onClick={() => tryBuyEquipment(eq)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 font-semibold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
              >
                <Coins className="w-3.5 h-3.5" />
                {eq.cost} Зол.
              </button>
            </div>
          );
        })}

        {activeTab === 'shields' && SHIELDS_DB.map(eq => {
          const isEquipped = player.shield?.id === eq.id;
          return (
            <div key={eq.id} className="flex justify-between items-center bg-slate-900/80 border border-slate-800/80 p-3 rounded-xl hover:border-slate-700/80 transition-all">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-display font-bold text-slate-200">{eq.name}</span>
                  {isEquipped && <span className="bg-blue-500/20 text-blue-400 text-[9px] uppercase px-1.5 py-0.5 rounded font-mono font-bold">Надето</span>}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{eq.description}</p>
                <div className="flex gap-2 text-[10px] text-blue-400 mt-1 font-mono">
                  {eq.bonusDef > 0 && <span>+ {eq.bonusDef} Защита</span>}
                  {eq.bonusAtk !== 0 && <span>{eq.bonusAtk > 0 ? '+' : ''}{eq.bonusAtk} Атака</span>}
                  {eq.bonusMg > 0 && <span>+ {eq.bonusMg} Магия</span>}
                  {eq.bonusSpd !== 0 && <span>{eq.bonusSpd > 0 ? '+' : ''}{eq.bonusSpd} Скорость</span>}
                </div>
              </div>
              <button
                onClick={() => tryBuyEquipment(eq)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 font-semibold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
              >
                <Coins className="w-3.5 h-3.5" />
                {eq.cost} Зол.
              </button>
            </div>
          );
        })}

        {activeTab === 'spells' && SPELLS_DB.map(spell => {
          const knowsSpell = player.spells.some(s => s.id === spell.id);
          return (
            <div key={spell.id} className="flex justify-between items-center bg-slate-900/80 border border-slate-800/80 p-3 rounded-xl hover:border-slate-700/80 transition-all">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-display font-bold text-slate-200">{spell.name}</span>
                  {knowsSpell && <span className="bg-purple-500/20 text-purple-400 text-[9px] uppercase px-1.5 py-0.5 rounded font-mono font-bold">Изучено</span>}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{spell.description}</p>
                <div className="flex gap-2 text-[10px] text-purple-400 mt-1 font-mono">
                  <span>Сила заклинания: {spell.power} ({spell.type === 'attack' ? 'Атакующее' : 'Защитное'})</span>
                </div>
              </div>
              <button
                onClick={() => tryBuySpell(spell)}
                disabled={knowsSpell}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 font-semibold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
              >
                {knowsSpell ? (
                  <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5" /> Знаете</span>
                ) : (
                  <>
                    <Coins className="w-3.5 h-3.5" />
                    {spell.cost} Зол.
                  </>
                )}
              </button>
            </div>
          );
        })}

        {activeTab === 'items' && ITEMS_DB.map(item => {
          return (
            <div key={item.id} className="flex justify-between items-center bg-slate-900/80 border border-slate-800/80 p-3 rounded-xl hover:border-slate-700/80 transition-all">
              <div>
                <span className="font-display font-bold text-slate-200">{item.name}</span>
                <p className="text-xs text-slate-400 mt-0.5">{item.description}</p>
                <span className="bg-slate-800 text-slate-400 text-[9px] uppercase px-1.5 py-0.5 rounded font-mono font-bold mt-1 inline-block">
                  Тип: {item.type.toUpperCase()}
                </span>
              </div>
              <button
                onClick={() => tryBuyItem(item)}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 font-semibold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
              >
                <Coins className="w-3.5 h-3.5" />
                {item.cost} Зол.
              </button>
            </div>
          );
        })}
      </div>

      {/* Actions */}
      <div className="border-t border-slate-800 pt-4 mt-4 text-right">
        <button
          onClick={onClose}
          className="px-6 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer font-bold font-display text-sm"
        >
          Выйти из Лавки
        </button>
      </div>
    </div>
  );
}
