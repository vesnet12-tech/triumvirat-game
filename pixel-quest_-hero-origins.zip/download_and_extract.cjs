const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

async function main() {
  const url = 'https://raw.githubusercontent.com/vesnet12-tech/triumvirat-game/main/rpg%20quest/SuperRetroWorld_CharacterPack_Full.zip';
  console.log('Downloading zip file...');
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download: ${response.status} ${response.statusText}`);
  }
  
  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  
  const zipPath = path.join(__dirname, 'temp_pack.zip');
  fs.writeFileSync(zipPath, buffer);
  console.log('Zip file downloaded successfully.');
  
  const extractDir = path.join(__dirname, 'extracted_characters');
  if (!fs.existsSync(extractDir)) {
    fs.mkdirSync(extractDir);
  }
  
  console.log('Extracting zip...');
  const zip = new AdmZip(zipPath);
  zip.extractAllTo(extractDir, true);
  console.log('Extraction completed successfully to directory:', extractDir);
  
  // Clean up zip
  fs.unlinkSync(zipPath);
}

main().catch(err => {
  console.error('Error during download/extract:', err);
  process.exit(1);
});
