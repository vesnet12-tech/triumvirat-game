// Simple 8-bit Web Audio Synth helper for authentic retro RPG feel
// All audio starts from a user interaction to comply with browser autoplay policies

let audioCtx: AudioContext | null = null;
let themeInterval: any = null;
let isThemePlaying = false;

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playSound(type: 'select' | 'confirm' | 'cancel' | 'coin' | 'levelUp') {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'select') {
      // Short high-pitched retro beep
      osc.type = 'square';
      osc.frequency.setValueAtTime(600, now);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'confirm') {
      // Arpeggio up
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.setValueAtTime(450, now + 0.08);
      osc.frequency.setValueAtTime(600, now + 0.16);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'cancel') {
      // Buzzing down-tone
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.linearRampToValueAtTime(100, now + 0.2);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'coin') {
      // Standard retro coin sound: quick low to high square wave
      osc.type = 'square';
      osc.frequency.setValueAtTime(987.77, now); // B5
      osc.frequency.setValueAtTime(1318.51, now + 0.08); // E6
      gain.gain.setValueAtTime(0.04, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (type === 'levelUp') {
      // Level up melody
      osc.type = 'square';
      const notes = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50]; // C major chord up
      gain.gain.setValueAtTime(0.04, now);
      notes.forEach((freq, index) => {
        osc.frequency.setValueAtTime(freq, now + index * 0.07);
      });
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
      osc.start(now);
      osc.stop(now + 0.6);
    }
  } catch (error) {
    console.warn('Audio synthesis failed:', error);
  }
}

// Simple retro theme loop
export function startRetroTheme(onNoteTriggered?: (noteIndex: number) => void) {
  if (isThemePlaying) return;
  isThemePlaying = true;

  try {
    const ctx = getAudioContext();
    
    // Cute retro RPG baseline and lead chord progression in C/Am
    const melody = [
      440, 494, 523, 587, 659, 523, 440, 392,
      440, 440, 523, 440, 392, 349, 392, 440,
    ]; // frequencies
    
    let step = 0;

    themeInterval = setInterval(() => {
      if (ctx.state === 'suspended') return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      // Classic triangle wave for a cozy retro flute sound
      osc.type = 'triangle';
      
      const freq = melody[step % melody.length];
      osc.frequency.setValueAtTime(freq, now);
      
      // Light volume
      gain.gain.setValueAtTime(0.02, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      
      osc.start(now);
      osc.stop(now + 0.25);
      
      if (onNoteTriggered) {
        onNoteTriggered(step % melody.length);
      }
      
      step++;
    }, 250); // 120 bpm eighth notes
  } catch (err) {
    console.warn('Theme music failed to start:', err);
  }
}

export function stopRetroTheme() {
  isThemePlaying = false;
  if (themeInterval) {
    clearInterval(themeInterval);
    themeInterval = null;
  }
}

export function toggleTheme(onNoteTriggered?: (noteIndex: number) => void): boolean {
  if (isThemePlaying) {
    stopRetroTheme();
    return false;
  } else {
    startRetroTheme(onNoteTriggered);
    return true;
  }
}
