import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Coins, MessageSquare, ShieldAlert, Award, Compass, Sparkles, Swords, Plus, RefreshCw } from 'lucide-react';
import { Character, CLASSES, RACES, TRAITS, RarityType } from '../types';
import PixelSprite from './PixelSprite';
import { playSound } from '../utils/audio';

interface GameWorldProps {
  character: Character;
  onExit: (updatedCharacter?: Character) => void;
}

// 12x12 grid map definition
// G = Grass (walkable)
// T = Tree (wall)
// W = Water (wall)
// S = Signpost (walkable/interactable)
// C = Treasure Chest (interactable)
// N = Wise Wizard NPC (interactable)
// P = Player starting position
const MAP_WIDTH = 12;
const MAP_HEIGHT = 12;

const WORLD_MAP = [
  ['T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T'],
  ['T', 'G', 'G', 'G', 'T', 'G', 'G', 'G', 'G', 'G', 'C', 'T'],
  ['T', 'G', 'G', 'G', 'T', 'G', 'G', 'G', 'G', 'G', 'G', 'T'],
  ['T', 'G', 'G', 'G', 'T', 'T', 'T', 'G', 'G', 'G', 'G', 'T'],
  ['T', 'G', 'N', 'G', 'G', 'G', 'T', 'G', 'G', 'G', 'G', 'T'],
  ['T', 'G', 'G', 'G', 'G', 'G', 'T', 'G', 'W', 'W', 'W', 'T'],
  ['T', 'T', 'T', 'G', 'G', 'G', 'T', 'G', 'W', 'W', 'W', 'T'],
  ['T', 'G', 'G', 'G', 'S', 'G', 'G', 'G', 'W', 'W', 'W', 'T'],
  ['T', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'T'],
  ['T', 'G', 'G', 'T', 'T', 'G', 'T', 'T', 'G', 'G', 'G', 'T'],
  ['T', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'T'],
  ['T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T', 'T'],
];

export default function GameWorld({ character, onExit }: GameWorldProps) {
  const [playerPos, setPlayerPos] = useState({ x: 5, y: 7 }); // starting coordinates (walkable grass)
  const [direction, setDirection] = useState<'down' | 'up' | 'left' | 'right'>('down');
  const [isMoving, setIsMoving] = useState(false);
  const [tick, setTick] = useState(0);
  
  // Game state
  const [gold, setGold] = useState(character.gold);
  const [exp, setExp] = useState(character.exp);
  const [level, setLevel] = useState(character.level);
  const [chestOpened, setChestOpened] = useState(false);
  const [spins, setSpins] = useState(() => character.spins !== undefined ? character.spins : 5);
  const [raceId, setRaceId] = useState(() => character.race || 'human');
  const [traitId, setTraitId] = useState(() => character.trait || '');

  // Spinning / rolling animations state
  const [isSpinningRace, setIsSpinningRace] = useState(false);
  const [isSpinningTrait, setIsSpinningTrait] = useState(false);
  const [rollDisplay, setRollDisplay] = useState<string | null>(null);

  const [dialog, setDialog] = useState<string | null>(
    `Welcome, ${character.name}! Use WASD/Arrows to move or click the D-Pad buttons. Explore the valley!`
  );

  // References for handling animation ticks
  const animationTimer = useRef<any>(null);

  // Character animation pulse
  useEffect(() => {
    animationTimer.current = setInterval(() => {
      setTick(prev => prev + 1);
    }, 200);
    return () => {
      if (animationTimer.current) clearInterval(animationTimer.current);
    };
  }, []);

  // Check if target tile is walkable
  const isWalkable = useCallback((x: number, y: number) => {
    if (x < 0 || x >= MAP_WIDTH || y < 0 || y >= MAP_HEIGHT) return false;
    const tile = WORLD_MAP[y][x];
    // Obstacles are Trees (T) and Water (W)
    return tile !== 'T' && tile !== 'W';
  }, []);

  // Interacts with objects at a certain position
  const checkInteraction = useCallback((x: number, y: number) => {
    const tile = WORLD_MAP[y][x];
    
    if (tile === 'C') {
      if (!chestOpened) {
        playSound('coin');
        setChestOpened(true);
        setGold(prev => prev + 120);
        setExp(prev => {
          const nextExp = prev + 50;
          if (nextExp >= 100) {
            playSound('levelUp');
            setLevel(l => l + 1);
            setDialog(`[CHEST OPENED] Found +120 Gold & +50 EXP! LEVEL UP! You are now Level ${level + 1}!`);
            return nextExp - 100;
          }
          setDialog('[CHEST OPENED] You opened a mossy old chest and found +120 Gold & +50 EXP!');
          return nextExp;
        });
      } else {
        playSound('select');
        setDialog('The ancient treasure chest lies empty.');
      }
    } else if (tile === 'N') {
      playSound('confirm');
      setDialog(
        `[GALDOR THE ARCHMAGE] "Aha! A local ${character.class}! Greetings, ${character.name}. I see you distributed your attributes well. Keep practicing in this valley!"`
      );
    } else if (tile === 'S') {
      playSound('select');
      setDialog(
        `[SIGNPOST] "NORTH: Wizard Galdor's Hermitage. EAST: Whispering Waters. SOUTH: Exit Gateway."`
      );
    }
  }, [chestOpened, character, level]);

  // Player move action
  const movePlayer = useCallback((dx: number, dy: number, dir: 'down' | 'up' | 'left' | 'right') => {
    setDirection(dir);
    setIsMoving(true);

    const nextX = playerPos.x + dx;
    const nextY = playerPos.y + dy;

    if (isWalkable(nextX, nextY)) {
      playSound('select');
      setPlayerPos({ x: nextX, y: nextY });
      // Clear generic welcome dialogues on walk, but keep interesting ones
      setDialog(null);
      
      // Auto interact if player is on/adjacent to interactables
      checkInteraction(nextX, nextY);
    } else {
      playSound('cancel');
      // Set collision block hint dialogue
      const blockedTile = WORLD_MAP[nextY]?.[nextX];
      if (blockedTile === 'T') {
        setDialog('The thick ancient forest blocks your pathway.');
      } else if (blockedTile === 'W') {
        setDialog('The crystal water ripples gently. You need a raft to cross.');
      }
    }

    // Stop walking frame shortly after key release simulation
    setTimeout(() => {
      setIsMoving(false);
    }, 150);
  }, [playerPos, isWalkable, checkInteraction]);

  // Listen to keyboard inputs
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent scrolling when arrow keys are pressed
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        movePlayer(0, -1, 'up');
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        movePlayer(0, 1, 'down');
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        movePlayer(-1, 0, 'left');
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        movePlayer(1, 0, 'right');
      } else if (e.key === ' ') {
        // Trigger interaction at adjacent tiles
        playSound('select');
        checkInteraction(playerPos.x, playerPos.y);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [movePlayer, playerPos, checkInteraction]);

  // Resolve active race and trait
  const activeRace = RACES.find(r => r.id === raceId) || RACES[0];
  const activeTrait = TRAITS.find(t => t.id === traitId) || null;

  const handleSpinRace = () => {
    if (spins <= 0) {
      playSound('cancel');
      setDialog('❌ YOU HAVE 0 SPINS LEFT! Buy more spins below for 100 Gold! / У вас осталось 0 круток! Купите крутки за 100 золота ниже!');
      return;
    }
    if (isSpinningRace || isSpinningTrait) return;
    
    setIsSpinningRace(true);
    setSpins(prev => prev - 1);
    playSound('select');

    let currentTicks = 0;
    const maxTicks = 12;
    let speed = 70; // ms

    const runTick = () => {
      // Pick a random race
      const randomRace = RACES[Math.floor(Math.random() * RACES.length)];
      setRollDisplay(`RACE: ${randomRace.name} [${randomRace.rarity.toUpperCase()}]`);
      playSound('select');

      currentTicks++;
      if (currentTicks < maxTicks) {
        speed += 25;
        setTimeout(runTick, speed);
      } else {
        // Final roll using official weights
        const rng = Math.random();
        let rarity: RarityType = 'Common';
        if (rng < 0.005) {
          rarity = 'Divine';
        } else if (rng < 0.03) {
          rarity = 'Mythic';
        } else if (rng < 0.07) {
          rarity = 'Legendary';
        } else if (rng < 0.15) {
          rarity = 'Epic';
        } else if (rng < 0.30) {
          rarity = 'Rare';
        } else if (rng < 0.55) {
          rarity = 'Uncommon';
        } else {
          rarity = 'Common';
        }

        const matchingRaces = RACES.filter(r => r.rarity === rarity);
        const finalRace = matchingRaces[Math.floor(Math.random() * matchingRaces.length)] || RACES[0];

        setRaceId(finalRace.id);
        setIsSpinningRace(false);
        setRollDisplay(null);
        playSound('levelUp');
        setDialog(`🎉 CONGRATULATIONS! You rolled the ${finalRace.rarity.toUpperCase()} Race: "${finalRace.name}" (${finalRace.russianName})! Origin: ${finalRace.animeSource}.`);
      }
    };

    runTick();
  };

  const handleSpinTrait = () => {
    if (spins <= 0) {
      playSound('cancel');
      setDialog('❌ YOU HAVE 0 SPINS LEFT! Buy more spins below for 100 Gold! / У вас осталось 0 круток! Купите крутки за 100 золота ниже!');
      return;
    }
    if (isSpinningRace || isSpinningTrait) return;
    
    setIsSpinningTrait(true);
    setSpins(prev => prev - 1);
    playSound('select');

    let currentTicks = 0;
    const maxTicks = 12;
    let speed = 70; // ms

    const runTick = () => {
      const randomTrait = TRAITS[Math.floor(Math.random() * TRAITS.length)];
      setRollDisplay(`TRAIT: ${randomTrait.name} [${randomTrait.rarity.toUpperCase()}]`);
      playSound('select');

      currentTicks++;
      if (currentTicks < maxTicks) {
        speed += 25;
        setTimeout(runTick, speed);
      } else {
        // Final roll using weights
        const rng = Math.random();
        let rarity: RarityType = 'Common';
        if (rng < 0.005) {
          rarity = 'Divine';
        } else if (rng < 0.03) {
          rarity = 'Mythic';
        } else if (rng < 0.07) {
          rarity = 'Legendary';
        } else if (rng < 0.15) {
          rarity = 'Epic';
        } else if (rng < 0.30) {
          rarity = 'Rare';
        } else if (rng < 0.55) {
          rarity = 'Uncommon';
        } else {
          rarity = 'Common';
        }

        const matchingTraits = TRAITS.filter(t => t.rarity === rarity);
        const finalTrait = matchingTraits[Math.floor(Math.random() * matchingTraits.length)] || TRAITS[0];

        setTraitId(finalTrait.id);
        setIsSpinningTrait(false);
        setRollDisplay(null);
        playSound('levelUp');
        setDialog(`🎉 CONGRATULATIONS! You obtained the ${finalTrait.rarity.toUpperCase()} Trait: "${finalTrait.name}" (${finalTrait.russianName}) from ${finalTrait.animeSource}!`);
      }
    };

    runTick();
  };

  const handleBuySpin = () => {
    if (gold < 100) {
      playSound('cancel');
      setDialog('❌ NOT ENOUGH GOLD! You need 100 Gold to purchase 1 Gacha Spin! / Недостаточно золота! Нужно 100 золота за 1 крутку!');
      return;
    }
    playSound('coin');
    setGold(prev => prev - 100);
    setSpins(prev => prev + 1);
    setDialog('💸 PURCHASE SUCCESSFUL! Spent 100 Gold to acquire +1 Gacha Spin! Good luck on your next roll! / Успешно куплено +1 крутка за 100 золота!');
  };

  const handleVenture = () => {
    playSound('confirm');
    const goldEarned = Math.floor(Math.random() * 50) + 50; // 50-100 gold
    const expEarned = Math.floor(Math.random() * 30) + 20;   // 20-50 exp
    setGold(prev => prev + goldEarned);
    setExp(prev => {
      const nextExp = prev + expEarned;
      if (nextExp >= 100) {
        playSound('levelUp');
        setLevel(l => l + 1);
        setDialog(`⚔️ [COMBAT ADVENTURE] You marched into the Dungeon of Destiny and slayed an Elite Boss! Earned +${goldEarned} Gold and +${expEarned} EXP. LEVEL UP! You are now Level ${level + 1}!`);
        return nextExp - 100;
      }
      setDialog(`⚔️ [COMBAT ADVENTURE] You entered the wild grasslands and cleared a camp of Goblins! Found +${goldEarned} Gold and +${expEarned} EXP!`);
      return nextExp;
    });
  };

  const handleExit = () => {
    playSound('cancel');
    const updatedCharacter: Character = {
      ...character,
      gold,
      exp,
      level,
      race: raceId,
      trait: traitId,
      spins,
    };
    onExit(updatedCharacter);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-6 crt-effect flex flex-col justify-between select-none">
      <div className="max-w-4xl mx-auto w-full flex flex-col h-full gap-4">
        
        {/* Top Hub Bar */}
        <div className="flex items-center justify-between border-b border-slate-900 pb-3">
          <button
            onClick={handleExit}
            className="flex items-center gap-2 px-3 py-2 bg-slate-900 border-2 border-slate-800 hover:border-red-500 rounded text-slate-400 hover:text-red-400 font-press-start text-[10px] cursor-pointer transition-all active:scale-95"
            id="exit-game-btn"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>SAVE & EXIT</span>
          </button>

          <div className="flex gap-4 font-press-start text-[9px]">
            <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-full text-yellow-400">
              <Coins className="w-4 h-4" />
              <span>GOLD: {gold}g</span>
            </div>
            <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-full text-cyan-400">
              <Award className="w-4 h-4" />
              <span>LVL: {level}</span>
            </div>
          </div>
        </div>

        {/* Workspace: Map (Left) + Controllers/Details (Right) */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start my-auto">
          
          {/* MAP CANVAS GRID CONTAINER (7 Columns) */}
          <div className="md:col-span-7 flex justify-center">
            <div className="border-4 border-slate-800 bg-slate-900 p-2.5 rounded-xl shadow-2xl relative">
              {/* Map Layout */}
              <div
                className="grid gap-0"
                style={{
                  gridTemplateColumns: `repeat(${MAP_WIDTH}, minmax(0, 1fr))`,
                  width: '320px',
                  height: '320px',
                  maxWidth: '100%',
                }}
                id="rpg-tilemap"
              >
                {WORLD_MAP.map((row, rIdx) =>
                  row.map((tile, cIdx) => {
                    const isPlayerHere = playerPos.x === cIdx && playerPos.y === rIdx;
                    
                    // Determine tile visual style
                    let tileBg = 'bg-emerald-800'; // Default Grass
                    let tileIcon = null;

                    if (tile === 'T') {
                      // Thick Pine Trees
                      tileBg = 'bg-green-950 border border-green-900/40';
                      tileIcon = (
                        <div className="w-full h-full flex flex-col justify-center items-center">
                          {/* Mini styled pine-tree SVG */}
                          <div className="w-4 h-4 bg-green-700 rounded-full flex items-center justify-center relative">
                            <div className="absolute w-2 h-2 bg-green-500 rounded-full top-0" />
                            <div className="w-1.5 h-3 bg-amber-900 absolute -bottom-1" />
                          </div>
                        </div>
                      );
                    } else if (tile === 'W') {
                      // Ripple Water
                      tileBg = 'bg-blue-800/80 animate-pulse';
                      tileIcon = (
                        <div className="w-full h-full flex items-center justify-center opacity-45">
                          <Compass className="w-3 h-3 text-cyan-200 animate-spin" style={{ animationDuration: '8s' }} />
                        </div>
                      );
                    } else if (tile === 'S') {
                      // Signpost
                      tileBg = 'bg-amber-900/60';
                      tileIcon = (
                        <div className="w-full h-full flex flex-col items-center justify-center">
                          <div className="w-4 h-2.5 bg-amber-700 border border-amber-900 rounded" />
                          <div className="w-1 h-2 bg-amber-950" />
                        </div>
                      );
                    } else if (tile === 'C') {
                      // Chest
                      tileBg = 'bg-amber-950/20';
                      tileIcon = (
                        <div className="w-full h-full flex items-center justify-center">
                          <div
                            className={`w-5 h-4 border border-amber-500 rounded relative shadow-md transition-all ${
                              chestOpened
                                ? 'bg-slate-700 border-slate-500'
                                : 'bg-yellow-600 border-yellow-400 animate-bounce'
                            }`}
                          >
                            <div className="absolute top-0.5 left-1 right-1 h-1 bg-amber-950/40" />
                            {/* Golden dot lock */}
                            <div className="absolute top-1.5 left-2 w-1.5 h-1.5 rounded-full bg-yellow-300" />
                          </div>
                        </div>
                      );
                    } else if (tile === 'N') {
                      // Wizard Archmage
                      tileBg = 'bg-violet-950/40';
                      tileIcon = (
                        <div className="w-full h-full flex flex-col items-center justify-center relative">
                          {/* Animated Wizard sprite cap */}
                          <div className="w-3.5 h-3.5 bg-violet-600 border border-violet-400 rotate-45 flex items-center justify-center relative">
                            <Sparkles className="w-1.5 h-1.5 text-yellow-300 absolute" />
                          </div>
                          <div className="w-4 h-2.5 bg-slate-300 rounded-full mt-0.5" />
                        </div>
                      );
                    }

                    return (
                      <div
                        key={`${rIdx}-${cIdx}`}
                        className={`relative aspect-square flex items-center justify-center ${tileBg} transition-colors duration-100`}
                        style={{
                          // Grid cells with thin borders to make it feel like tiled pixel map
                          border: '0.5px solid rgba(15, 23, 42, 0.15)',
                        }}
                      >
                        {/* Shimmer grass blades decor */}
                        {tile === 'G' && (rIdx + cIdx) % 5 === 0 && (
                          <div className="absolute w-1 h-1.5 bg-emerald-500 rounded-full bottom-1 left-2 opacity-40" />
                        )}
                        {tile === 'G' && (rIdx * cIdx) % 7 === 1 && (
                          <div className="absolute w-1 h-1 bg-emerald-600 rounded-full top-2 right-2 opacity-30" />
                        )}

                        {tileIcon}

                        {/* Player Rendering on Tile */}
                        {isPlayerHere && (
                          <div className="absolute z-20 transform -translate-y-1.5 transition-all duration-150">
                            <PixelSprite
                              customization={character.customization}
                              size={44}
                              animation={isMoving ? 'walk' : 'idle'}
                              direction={direction}
                              tick={tick}
                              race={character.race || 'human'}
                            />
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* D-PAD CONTROLLER & PROFILE STATS PANEL (5 Columns) */}
          <div className="md:col-span-5 space-y-4">
            
            {/* MINI PROFILE */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row gap-4 items-center">
              <div className="bg-slate-950 p-2 border-2 border-slate-800 rounded-md shrink-0">
                <PixelSprite
                  customization={character.customization}
                  size={64}
                  animation="idle"
                  tick={tick}
                  race={character.race || 'human'}
                />
              </div>
              <div className="space-y-1.5 font-mono flex-1 w-full text-center sm:text-left">
                <div className="flex flex-col sm:flex-row sm:items-center justify-center sm:justify-start gap-1.5">
                  <h4 className="font-press-start text-[11px] text-amber-300 truncate max-w-[155px]">{character.name}</h4>
                  <span className="px-2 py-0.5 rounded text-[7px] font-press-start border uppercase bg-slate-950 text-cyan-400 border-cyan-800">
                    LVL {level}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px] text-slate-300 pt-0.5 border-t border-slate-800/60">
                  <div>Class: <span className="font-bold text-blue-400">{character.class}</span></div>
                  <div className="text-right text-slate-400">EXP: {exp}/100</div>
                  
                  <div className="col-span-2 text-left truncate flex items-center gap-1.5">
                    <span className="text-slate-500">Race:</span> 
                    <span className="font-bold uppercase text-[9px]" style={{ color: activeRace.color }}>
                      {activeRace.name}
                    </span>
                  </div>

                  <div className="col-span-2 text-left truncate flex items-center gap-1.5">
                    <span className="text-slate-500">Trait:</span> 
                    {activeTrait ? (
                      <span className="font-bold uppercase text-[9px]" style={{ color: activeTrait.color }}>
                        {activeTrait.name}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic text-[9px]">None / Обычный</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* COMMAND CENTER / ЦЕНТР КОМАНД */}
            <div className="bg-slate-900/50 border-2 border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <h4 className="font-press-start text-[9px] text-amber-400 tracking-wider">COMMAND CENTER</h4>
                <div className="px-2 py-0.5 bg-blue-950 border border-blue-500/40 rounded text-blue-400 font-press-start text-[8px] animate-pulse">
                  🌀 SPINS: {spins}
                </div>
              </div>

              {/* Rolling Animation Overlay if active */}
              {rollDisplay && (
                <div className="py-2 px-3 bg-slate-950 border border-dashed border-yellow-500 rounded text-center font-press-start text-[9px] text-yellow-400 animate-pulse">
                  🎰 ROLLING: {rollDisplay}
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                {/* Roll Race */}
                <button
                  type="button"
                  disabled={isSpinningRace || isSpinningTrait}
                  onClick={handleSpinRace}
                  className="px-2 py-2.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-100 font-press-start text-[8px] tracking-wider rounded border border-slate-700 hover:border-slate-500 active:scale-95 transition-all cursor-pointer flex flex-col items-center justify-center gap-1 text-center"
                >
                  <RefreshCw className="w-4 h-4 text-emerald-400 animate-spin-slow" />
                  <span>ROLL RACE<br/>(1 SPIN)</span>
                </button>

                {/* Roll Trait */}
                <button
                  type="button"
                  disabled={isSpinningRace || isSpinningTrait}
                  onClick={handleSpinTrait}
                  className="px-2 py-2.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-100 font-press-start text-[8px] tracking-wider rounded border border-slate-700 hover:border-slate-500 active:scale-95 transition-all cursor-pointer flex flex-col items-center justify-center gap-1 text-center"
                >
                  <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
                  <span>ROLL TRAIT<br/>(1 SPIN)</span>
                </button>

                {/* Adventure / Combat */}
                <button
                  type="button"
                  disabled={isSpinningRace || isSpinningTrait}
                  onClick={handleVenture}
                  className="px-2 py-2.5 bg-gradient-to-b from-blue-900 to-indigo-950 hover:from-blue-800 hover:to-indigo-900 disabled:opacity-50 text-white font-press-start text-[8px] tracking-wider rounded border border-blue-700 hover:border-blue-500 active:scale-95 transition-all cursor-pointer flex flex-col items-center justify-center gap-1 text-center col-span-1"
                >
                  <Swords className="w-4 h-4 text-rose-500 animate-bounce" />
                  <span>ADVENTURE<br/>(FREE EXP/GOLD)</span>
                </button>

                {/* Buy Spin */}
                <button
                  type="button"
                  disabled={isSpinningRace || isSpinningTrait}
                  onClick={handleBuySpin}
                  className="px-2 py-2.5 bg-gradient-to-b from-amber-600/20 to-amber-900/30 hover:from-amber-600/30 hover:to-amber-900/40 disabled:opacity-50 text-amber-300 font-press-start text-[8px] tracking-wider rounded border border-amber-800 hover:border-amber-600 active:scale-95 transition-all cursor-pointer flex flex-col items-center justify-center gap-1 text-center col-span-1"
                >
                  <Coins className="w-4 h-4 text-yellow-400" />
                  <span>BUY SPIN<br/>(100 GOLD)</span>
                </button>
              </div>
            </div>

            {/* D-PAD SCREEN TOUCH CONTROLS */}
            <div className="bg-slate-900/50 border-2 border-slate-800 rounded-xl p-4 flex flex-col items-center gap-3">
              <span className="font-press-start text-[8px] text-slate-500 tracking-wider">ON-SCREEN D-PAD CONTROLLER</span>
              
              <div className="relative w-28 h-28">
                {/* UP */}
                <button
                  onClick={() => movePlayer(0, -1, 'up')}
                  className="absolute top-0 left-9 w-10 h-9 bg-slate-800 hover:bg-slate-700 active:bg-blue-600 active:scale-95 border-2 border-slate-700 hover:border-slate-500 flex items-center justify-center font-bold text-white rounded cursor-pointer"
                  id="dpad-up"
                >
                  ▲
                </button>
                {/* LEFT */}
                <button
                  onClick={() => movePlayer(-1, 0, 'left')}
                  className="absolute top-9 left-0 w-9 h-10 bg-slate-800 hover:bg-slate-700 active:bg-blue-600 active:scale-95 border-2 border-slate-700 hover:border-slate-500 flex items-center justify-center font-bold text-white rounded cursor-pointer"
                  id="dpad-left"
                >
                  ◀
                </button>
                {/* CENTER HUB */}
                <div className="absolute top-9 left-9 w-10 h-10 bg-slate-950 border-2 border-slate-800 flex items-center justify-center text-[10px] text-slate-500 font-mono">
                  RPG
                </div>
                {/* RIGHT */}
                <button
                  onClick={() => movePlayer(1, 0, 'right')}
                  className="absolute top-9 right-0 w-9 h-10 bg-slate-800 hover:bg-slate-700 active:bg-blue-600 active:scale-95 border-2 border-slate-700 hover:border-slate-500 flex items-center justify-center font-bold text-white rounded cursor-pointer"
                  id="dpad-right"
                >
                  ▶
                </button>
                {/* DOWN */}
                <button
                  onClick={() => movePlayer(0, 1, 'down')}
                  className="absolute bottom-0 left-9 w-10 h-9 bg-slate-800 hover:bg-slate-700 active:bg-blue-600 active:scale-95 border-2 border-slate-700 hover:border-slate-500 flex items-center justify-center font-bold text-white rounded cursor-pointer"
                  id="dpad-down"
                >
                  ▼
                </button>
              </div>

              <span className="text-[8px] font-mono text-slate-500">
                W / A / S / D  OR ARROW KEYS WORK TOO!
              </span>
            </div>

          </div>

        </div>

        {/* DIALOG BOX OVERLAY / STATUS */}
        <AnimatePresence mode="wait">
          {dialog && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 10, opacity: 0 }}
              className="bg-slate-900 border-4 border-double border-blue-500 rounded-xl p-4 font-mono text-xs text-slate-300 flex gap-3 items-start shadow-2xl relative"
              id="game-dialogue-box"
            >
              <MessageSquare className="w-5 h-5 text-blue-400 shrink-0 mt-0.5 animate-pulse" />
              <div className="space-y-1">
                <span className="font-press-start text-[8px] text-blue-400 block tracking-wider">SYSTEM CHAT LOG</span>
                <p className="leading-relaxed text-[11px] text-slate-200">{dialog}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
