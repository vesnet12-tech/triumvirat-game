import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Dice5, ShieldCheck, Heart, Zap, Sparkles, Sword } from 'lucide-react';
import { RPGClass, CLASSES, COLOR_PALETTES, Customization, Character, RACES, RaceData, RarityType } from '../types';
import PixelSprite from './PixelSprite';
import { playSound } from '../utils/audio';

interface CharacterCreatorProps {
  onSave: (character: Character) => void;
  onCancel: () => void;
  characterToEdit?: Character | null;
}

const RANDOM_NAMES = [
  'Eldrin', 'Thorin', 'Vesper', 'Aethel', 'Sera', 'Garrick', 'Lyra', 'Kaelen', 'Sylas', 'Bront',
  'Orion', 'Valerie', 'Zephyr', 'Drakon', 'Isolde', 'Ignis', 'Rhea', 'Loxley', 'Freya', 'Kael'
];

export default function CharacterCreator({ onSave, onCancel, characterToEdit }: CharacterCreatorProps) {
  // 1. Core Info
  const [name, setName] = useState(() => characterToEdit ? characterToEdit.name : '');
  const [selectedClass, setSelectedClass] = useState<RPGClass>(() => {
    if (characterToEdit) {
      return characterToEdit.class;
    }
    // Randomly select a class upon creation since they cannot change it!
    const classes = Object.keys(CLASSES) as RPGClass[];
    const randomClass = classes[Math.floor(Math.random() * classes.length)];
    return randomClass;
  });

  // Race / Gacha states
  const [selectedRaceId, setSelectedRaceId] = useState<string>(() => characterToEdit ? (characterToEdit.race || 'human') : 'human');
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [spinDisplayRace, setSpinDisplayRace] = useState<RaceData | null>(null);
  const [showRaceListModal, setShowRaceListModal] = useState<boolean>(false);

  const rollRandomRace = () => {
    const rng = Math.random();
    let rarity: RarityType = 'Common';
    if (rng < 0.005) {
      rarity = 'Divine';
    } else if (rng < 0.03) { // 0.5% Divine + 2.5% Mythic
      rarity = 'Mythic';
    } else if (rng < 0.07) { // 3% + 4% Legendary
      rarity = 'Legendary';
    } else if (rng < 0.15) { // 7% + 8% Epic
      rarity = 'Epic';
    } else if (rng < 0.30) { // 15% + 15% Rare
      rarity = 'Rare';
    } else if (rng < 0.55) { // 30% + 25% Uncommon
      rarity = 'Uncommon';
    } else {
      rarity = 'Common';
    }

    const matchingRaces = RACES.filter(r => r.rarity === rarity);
    const randomRace = matchingRaces[Math.floor(Math.random() * matchingRaces.length)];
    return randomRace || RACES[0];
  };

  const handleSpinRace = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    playSound('select');

    let currentTicks = 0;
    const maxTicks = 12;
    let speed = 70; // ms

    const runTick = () => {
      // Pick any random race for the animation cycle
      const randomDisplay = RACES[Math.floor(Math.random() * RACES.length)];
      setSpinDisplayRace(randomDisplay);
      playSound('coin');

      currentTicks++;
      if (currentTicks < maxTicks) {
        speed += currentTicks * 22; // slow down exponentially
        setTimeout(runTick, speed);
      } else {
        // Final weighted selection
        const finalRace = rollRandomRace();
        setSelectedRaceId(finalRace.id);
        setSpinDisplayRace(null);
        setIsSpinning(false);
        
        if (['Epic', 'Legendary', 'Mythic', 'Divine'].includes(finalRace.rarity)) {
          playSound('levelUp');
        } else {
          playSound('select');
        }
      }
    };

    runTick();
  };

  // 2. Customization Options
  const [customization, setCustomization] = useState<Customization>(() => {
    if (characterToEdit) {
      return {
        useRetroSprite: true,
        retroSpriteId: 1,
        ...characterToEdit.customization,
      };
    }
    return {
      skinColor: COLOR_PALETTES.skin[0].value,
      hairStyle: 'spiky',
      hairColor: COLOR_PALETTES.hair[0].value,
      accessory: 'none',
      accessoryColor: COLOR_PALETTES.hair[1].value, // Default Ruby Red
      eyeStyle: 'classic',
      eyeColor: COLOR_PALETTES.eye[0].value,
      outfitStyle: 't_shirt',
      outfitColor: COLOR_PALETTES.outfit[0].value,
      innerColor: '#f8fafc', // Default white inner shirt
      weaponStyle: 'none',
      weaponColor: COLOR_PALETTES.weapon[0].value,
      blush: false,
      useRetroSprite: true,
      retroSpriteId: 1,
    };
  });

  // 3. Stat Pool Allocation
  const [bonusPoints, setBonusPoints] = useState(() => characterToEdit ? 0 : 10);
  const [stats, setStats] = useState(() => {
    if (characterToEdit) {
      // In edit mode, we can just track original allocated stats or keep zeroed to prevent editing
      return { str: 0, agi: 0, int: 0, vit: 0 };
    }
    return { str: 0, agi: 0, int: 0, vit: 0 };
  });

  // Animation tick for idle sprite animation
  const [animTick, setAnimTick] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setAnimTick(prev => prev + 1);
    }, 280);
    return () => clearInterval(timer);
  }, []);

  // Set default starting stats and weapons whenever the Class changes
  useEffect(() => {
    if (characterToEdit) return;
    const classData = CLASSES[selectedClass];
    // Reset bonus points
    setBonusPoints(10);
    setStats({ str: 0, agi: 0, int: 0, vit: 0 });

    // Auto update outfit to fit casual modern style, weapons are strictly unequipped
    let autoOutfit: Customization['outfitStyle'] = 't_shirt';
    let autoWeapon: Customization['weaponStyle'] = 'none';

    if (selectedClass === 'Mage') {
      autoOutfit = 'hoodie';
    } else if (selectedClass === 'Rogue') {
      autoOutfit = 'jacket';
    } else if (selectedClass === 'Cleric') {
      autoOutfit = 'sweater';
    }

    setCustomization(prev => ({
      ...prev,
      outfitStyle: autoOutfit,
      weaponStyle: autoWeapon,
      // Pick matching starter colors if applicable
      outfitColor: selectedClass === 'Warrior' ? COLOR_PALETTES.outfit[0].value // crimson
                 : selectedClass === 'Mage' ? COLOR_PALETTES.outfit[1].value // violet
                 : selectedClass === 'Rogue' ? COLOR_PALETTES.outfit[2].value // forest
                 : COLOR_PALETTES.outfit[6].value // teal
    }));
  }, [selectedClass]);

  // Set a random name on load
  useEffect(() => {
    if (characterToEdit) return;
    handleRandomizeName();
  }, []);

  const handleRandomizeName = () => {
    playSound('select');
    const randomName = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
    setName(randomName);
  };

  const handleStatChange = (stat: 'str' | 'agi' | 'int' | 'vit', change: number) => {
    if (change > 0 && bonusPoints > 0) {
      playSound('select');
      setStats(prev => ({ ...prev, [stat]: prev[stat] + 1 }));
      setBonusPoints(prev => prev - 1);
    } else if (change < 0 && stats[stat] > 0) {
      playSound('select');
      setStats(prev => ({ ...prev, [stat]: prev[stat] - 1 }));
      setBonusPoints(prev => prev + 1);
    } else {
      playSound('cancel');
    }
  };

  const handleCustomizationChange = <K extends keyof Customization>(key: K, value: Customization[K]) => {
    playSound('select');
    setCustomization(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    if (!name.trim()) {
      playSound('cancel');
      alert('Please enter a name for your adventurer!');
      return;
    }

    if (characterToEdit) {
      // In edit mode, retain all level, gold, exp, race, spins, stats, etc., and only update name and customization
      const updatedCharacter: Character = {
        ...characterToEdit,
        name: name.trim(),
        customization: { ...customization },
      };
      playSound('levelUp');
      onSave(updatedCharacter);
      return;
    }

    // Prepare complete stats combining Base + allocated bonus stats + Race bonuses
    const classData = CLASSES[selectedClass];
    const currentRace = RACES.find(r => r.id === selectedRaceId) || RACES[0];
    const finalStats = {
      str: classData.baseStats.str + stats.str + (currentRace.statBonus.str || 0),
      agi: classData.baseStats.agi + stats.agi + (currentRace.statBonus.agi || 0),
      int: classData.baseStats.int + stats.int + (currentRace.statBonus.int || 0),
      vit: classData.baseStats.vit + stats.vit + (currentRace.statBonus.vit || 0),
    };

    const newCharacter: Character = {
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
      name: name.trim(),
      class: selectedClass,
      stats: finalStats,
      customization: customization,
      level: 1,
      gold: 150, // starter gold
      exp: 0,
      createdAt: new Date().toISOString(),
      race: selectedRaceId,
      spins: 5, // Players start with 5 spins!
    };

    playSound('levelUp');
    onSave(newCharacter);
  };

  // Get total current stats including Race bonuses
  const classData = CLASSES[selectedClass];
  const activeRace = RACES.find(r => r.id === selectedRaceId) || RACES[0];
  const totalStr = classData.baseStats.str + stats.str + (activeRace.statBonus.str || 0);
  const totalAgi = classData.baseStats.agi + stats.agi + (activeRace.statBonus.agi || 0);
  const totalInt = classData.baseStats.int + stats.int + (activeRace.statBonus.int || 0);
  const totalVit = classData.baseStats.vit + stats.vit + (activeRace.statBonus.vit || 0);

  // Maximum HP and Mana estimates based on Stats
  const maxHp = totalVit * 12 + totalStr * 3;
  const maxMp = totalInt * 15;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-6 crt-effect select-none">
      <div className="max-w-5xl mx-auto flex flex-col justify-between h-full gap-6">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-900 pb-4 z-10">
          <button
            onClick={() => { playSound('cancel'); onCancel(); }}
            className="flex items-center gap-2 px-3 py-2 bg-slate-900 border-2 border-slate-800 hover:border-slate-500 rounded text-slate-400 hover:text-white font-press-start text-[10px] cursor-pointer transition-all active:scale-95"
            id="cancel-creator-btn"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>BACK</span>
          </button>

          <h2 className="font-press-start text-xs md:text-md text-amber-400 tracking-wider">
            CHARACTER CREATOR
          </h2>

          <div className="w-[80px]" /> {/* Spacer */}
        </div>

        {/* Workspace Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start z-10">
          
          {/* LEFT COLUMN: Customizer Config (7 Cols) */}
          <div className="lg:col-span-7 bg-slate-900/50 border-2 border-slate-800 rounded-xl p-4 md:p-6 space-y-6" id="customizer-options-panel">
            
            {/* NAME INPUT */}
            <div className="space-y-2">
              <label className="font-press-start text-[10px] text-blue-400 block">ADVENTURER NAME</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  maxLength={14}
                  value={name}
                  onChange={(e) => setName(e.target.value.replace(/[^a-zA-Z0-9 ]/g, ''))}
                  className="flex-1 bg-slate-950 border-2 border-slate-800 focus:border-blue-500 rounded px-4 py-2 text-sm font-mono tracking-wide text-white outline-none focus:shadow-[0_0_10px_rgba(59,130,246,0.2)]"
                  placeholder="Enter custom name..."
                  id="character-name-input"
                />
                <button
                  onClick={handleRandomizeName}
                  className="px-3 bg-slate-800 border-2 border-slate-700 hover:border-blue-500 rounded flex items-center justify-center cursor-pointer text-slate-300 transition-all hover:text-white active:scale-95"
                  title="Random Name"
                  id="randomize-name-btn"
                >
                  <Dice5 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* CLASS SELECTOR */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="font-press-start text-[10px] text-blue-400 block">
                  CHOOSE RPG CLASS / ВЫБЕРИТЕ КЛАСС ПЕРСОНАЖА
                </label>
                <span className="text-emerald-500 font-press-start text-[8px] animate-pulse">● SELECTABLE</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(Object.keys(CLASSES) as RPGClass[]).map((cls) => {
                  const isActive = selectedClass === cls;
                  return (
                    <button
                      type="button"
                      key={cls}
                      onClick={() => {
                        playSound('select');
                        setSelectedClass(cls);
                      }}
                      className={`py-2 px-3 rounded font-press-start text-[10px] text-center border-2 transition-all cursor-pointer ${
                        isActive
                          ? 'bg-blue-950 border-blue-500 text-blue-300 shadow-[0_0_12px_rgba(59,130,246,0.3)] scale-105'
                          : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-600'
                      }`}
                      id={`class-select-${cls}`}
                    >
                      {cls}
                    </button>
                  );
                })}
              </div>
              <p className="font-mono text-xs text-slate-400 leading-relaxed bg-slate-950 p-3 rounded border border-slate-800">
                {CLASSES[selectedClass].description}
              </p>
            </div>

            {/* SPRITE STYLING CONTROLS */}
            <div className="space-y-4 border-t border-slate-800 pt-5">
              <h3 className="font-press-start text-[10px] text-yellow-400 tracking-wider">
                APPEARANCE CUSTOMIZATION / ВНЕШНОСТЬ ГЕРОЯ
              </h3>
              
              <div className="space-y-4">
                <span className="font-press-start text-[8px] text-slate-400 block mb-1">
                  SELECT RETRO HERO / ВЫБЕРИТЕ ГЕРОЯ (1-32)
                </span>
                
                {/* Grid of 30 characters (excluding #8 and #24) with Live PixelSprite preview */}
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 bg-slate-950 p-3 rounded-lg border-2 border-slate-800 max-h-72 overflow-y-auto">
                  {Array.from({ length: 32 }, (_, i) => i + 1)
                    .filter((id) => id !== 8 && id !== 24)
                    .map((id) => (
                      <button
                        key={id}
                        type="button"
                        onClick={() => {
                          playSound('select');
                          handleCustomizationChange('retroSpriteId', id);
                        }}
                        className={`p-1.5 flex flex-col items-center justify-center rounded-md border-2 cursor-pointer transition-all hover:bg-slate-900 active:scale-95 ${
                          (customization.retroSpriteId || 1) === id
                            ? 'border-yellow-400 bg-yellow-950/20'
                            : 'border-slate-800 bg-slate-900/30 hover:border-slate-700'
                        }`}
                      >
                        <PixelSprite
                          customization={{
                            ...customization,
                            useRetroSprite: true,
                            retroSpriteId: id
                          }}
                          size={48}
                          animation="idle"
                          tick={animTick}
                        />
                        <span className="font-press-start text-[6px] mt-1.5 text-slate-400">#{id}</span>
                      </button>
                    ))}
                </div>

                <div className="bg-slate-900/50 border border-slate-800 rounded p-3 text-center">
                  <p className="font-mono text-xs text-slate-300">
                    Selected Retro Character <span className="text-yellow-400 font-bold">#{customization.retroSpriteId || 1}</span>
                  </p>
                  <p className="font-mono text-[10px] text-slate-400 mt-1">
                    Authentic retro design! Classic characters are rendered in their original arcade color palettes.
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: Realtime Live Sprite & Attribute points distribution (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6" id="stats-preview-panel">
            
            {/* SPRITE AVATAR PREVIEW CARD */}
            <div className="bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-blue-900/60 rounded-xl p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
              
              {/* Backglow element */}
              <div
                className="absolute w-40 h-40 blur-[80px] opacity-25 rounded-full"
                style={{ backgroundColor: CLASSES[selectedClass].color }}
              />

              {/* Title info */}
              <div className="flex items-center gap-2 mb-4 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-full z-10 font-press-start text-[9px] text-amber-300">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>REALTIME SPRITE PREVIEW</span>
              </div>

              {/* Character sprite renderer */}
              <div className="w-48 h-48 border-4 border-double border-slate-800 bg-slate-950/40 rounded-lg flex items-center justify-center relative p-4 mb-2 z-10 shadow-inner group">
                <PixelSprite
                  customization={customization}
                  size={144}
                  animation="idle"
                  tick={animTick}
                />
              </div>

              {/* Floor platform visual */}
              <div className="w-36 h-3 bg-slate-900 border border-slate-800 rounded-full mb-3 shadow-[0_4px_12px_rgba(0,0,0,0.8)]" />

              {/* Estimated RPG derived specs */}
              <div className="w-full flex justify-around gap-2 font-press-start text-[8px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-900 z-10">
                <div className="flex items-center gap-1">
                  <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" />
                  <span>HP: <strong className="text-red-400 font-bold">{maxHp}</strong></span>
                </div>
                <div className="flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-blue-500 fill-blue-500" />
                  <span>MP: <strong className="text-blue-400 font-bold">{maxMp}</strong></span>
                </div>
              </div>
            </div>

            {/* ATTRIBUTES ALLOCATION PANEL */}
            {!characterToEdit && (
              <div className="bg-slate-900/50 border-2 border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-press-start text-[10px] text-blue-400 tracking-wider">STATS ALLOCATION</h3>
                  <div className="px-2 py-1 bg-amber-950 border border-amber-500/40 rounded text-amber-400 font-press-start text-[9px] animate-pulse">
                    POINTS LEFT: {bonusPoints}
                  </div>
                </div>

                <div className="space-y-3.5 font-mono text-xs">
                  
                  {/* STRENGTH */}
                  <div className="flex items-center justify-between p-2.5 bg-slate-950/60 rounded border border-slate-900">
                    <div className="space-y-0.5">
                      <span className="font-press-start text-[9px] text-slate-200 block">STR (STRENGTH)</span>
                      <span className="text-[10px] text-slate-500 block">Increases physical power</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-slate-500 text-sm">
                        {CLASSES[selectedClass].baseStats.str}
                        {stats.str > 0 && <span className="text-emerald-400"> +{stats.str}</span>}
                      </span>
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleStatChange('str', -1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          -
                        </button>
                        <button
                          onClick={() => handleStatChange('str', 1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* AGILITY */}
                  <div className="flex items-center justify-between p-2.5 bg-slate-950/60 rounded border border-slate-900">
                    <div className="space-y-0.5">
                      <span className="font-press-start text-[9px] text-slate-200 block">AGI (AGILITY)</span>
                      <span className="text-[10px] text-slate-500 block">Increases swiftness & bows</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-slate-500 text-sm">
                        {CLASSES[selectedClass].baseStats.agi}
                        {stats.agi > 0 && <span className="text-emerald-400"> +{stats.agi}</span>}
                      </span>
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleStatChange('agi', -1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          -
                        </button>
                        <button
                          onClick={() => handleStatChange('agi', 1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* INTELLIGENCE */}
                  <div className="flex items-center justify-between p-2.5 bg-slate-950/60 rounded border border-slate-900">
                    <div className="space-y-0.5">
                      <span className="font-press-start text-[9px] text-slate-200 block">INT (INTELLIGENCE)</span>
                      <span className="text-[10px] text-slate-500 block">Increases arcane magic power</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-slate-500 text-sm">
                        {CLASSES[selectedClass].baseStats.int}
                        {stats.int > 0 && <span className="text-emerald-400"> +{stats.int}</span>}
                      </span>
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleStatChange('int', -1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          -
                        </button>
                        <button
                          onClick={() => handleStatChange('int', 1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* VITALITY */}
                  <div className="flex items-center justify-between p-2.5 bg-slate-950/60 rounded border border-slate-900">
                    <div className="space-y-0.5">
                      <span className="font-press-start text-[9px] text-slate-200 block">VIT (VITALITY)</span>
                      <span className="text-[10px] text-slate-500 block">Increases health points</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-slate-500 text-sm">
                        {CLASSES[selectedClass].baseStats.vit}
                        {stats.vit > 0 && <span className="text-emerald-400"> +{stats.vit}</span>}
                      </span>
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleStatChange('vit', -1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          -
                        </button>
                        <button
                          onClick={() => handleStatChange('vit', 1)}
                          className="w-7 h-7 bg-slate-800 hover:bg-slate-700 active:scale-90 flex items-center justify-center font-bold text-white rounded cursor-pointer border border-slate-700"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* CONFIRM BUTTON */}
            <button
              onClick={handleSave}
              disabled={!name.trim()}
              className={`w-full flex items-center justify-center gap-2 py-3.5 rounded text-white font-press-start text-[11px] cursor-pointer shadow-xl transition-all duration-300 ${
                name.trim()
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 border-2 border-blue-400 hover:border-blue-300 hover:from-blue-500 hover:to-indigo-500 active:scale-95'
                  : 'bg-slate-900 border-2 border-slate-800 text-slate-600 cursor-not-allowed'
              }`}
              id="confirm-create-character-btn"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>SAVE CHARACTER</span>
            </button>

          </div>

        </div>

        {/* Footer info */}
        <div className="w-full text-center text-[9px] text-slate-600 font-press-start py-4 border-t border-slate-900 z-10">
          DESIGN YOUR SPRITE, DISTRIBUTE POINTS, AND PRESS SAVE TO PRESERVE YOUR SLATE.
        </div>

      </div>

      {/* VIEW ALL RACES MODAL */}
      {showRaceListModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-slate-900 border-4 border-blue-900/60 rounded-xl p-5 md:p-6 max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl relative">
            
            {/* Header */}
            <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
              <div>
                <h3 className="font-press-start text-xs md:text-sm text-yellow-400 tracking-wider">
                  ALL ANIME RACES (20)
                </h3>
                <h4 className="font-press-start text-[8px] text-slate-500 tracking-wider mt-1 uppercase">
                  СПИСОК ВСЕХ РАС И ШАНСЫ КРУТКИ
                </h4>
              </div>
              <button
                onClick={() => {
                  playSound('cancel');
                  setShowRaceListModal(false);
                }}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border-2 border-slate-700 rounded text-slate-300 font-press-start text-[9px] cursor-pointer"
              >
                CLOSE / Х
              </button>
            </div>

            {/* Odds Quick Reference Bar */}
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-1 bg-slate-950 p-2 rounded border border-slate-800/80 mb-4 font-press-start text-[7px] text-center">
              <div>
                <div className="text-[#94a3b8]">COMMON</div>
                <div className="text-white mt-0.5">45%</div>
              </div>
              <div>
                <div className="text-[#10b981]">UNCOMMON</div>
                <div className="text-white mt-0.5">25%</div>
              </div>
              <div>
                <div className="text-[#3b82f6]">RARE</div>
                <div className="text-white mt-0.5">15%</div>
              </div>
              <div>
                <div className="text-[#a855f7]">EPIC</div>
                <div className="text-white mt-0.5">8%</div>
              </div>
              <div>
                <div className="text-[#f97316]">LEGEND</div>
                <div className="text-white mt-0.5">4%</div>
              </div>
              <div>
                <div className="text-[#ef4444]">MYTHIC</div>
                <div className="text-white mt-0.5">2.5%</div>
              </div>
              <div>
                <div className="text-[#eab308]">DIVINE</div>
                <div className="text-white mt-0.5">0.5%</div>
              </div>
            </div>

            {/* List with Scroll */}
            <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 custom-scrollbar">
              {RACES.map((race) => {
                const statBonuses = Object.entries(race.statBonus)
                  .filter(([_, val]) => val > 0)
                  .map(([stat, val]) => `${stat.toUpperCase()}: +${val}`)
                  .join(', ');

                return (
                  <div 
                    key={race.id}
                    className="p-3 bg-slate-950/60 rounded border-2 flex flex-col sm:flex-row justify-between gap-2 hover:bg-slate-950 transition-colors"
                    style={{ borderColor: `${race.color}25` }}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-press-start text-[10px] text-white">
                          {race.name} / {race.russianName}
                        </span>
                        <span 
                          className="px-1.5 py-0.5 rounded text-[7px] font-press-start border font-semibold uppercase"
                          style={{ borderColor: race.color, color: race.color }}
                        >
                          {race.rarity}
                        </span>
                        <span className="text-[9px] text-amber-500 font-press-start">
                          [{race.animeSource}]
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 font-mono leading-relaxed">{race.description}</p>
                      <p className="text-xs text-slate-500 font-mono italic leading-relaxed">{race.descriptionRu}</p>
                    </div>

                    <div className="shrink-0 self-start sm:self-center font-mono text-[10px] bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-emerald-400 font-bold">
                      {statBonuses || 'NO BONUSES'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
