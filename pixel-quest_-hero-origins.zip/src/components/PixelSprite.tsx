import { useMemo, useState, useEffect } from 'react';
import { Customization } from '../types';

interface PixelSpriteProps {
  customization: Customization;
  className?: string;
  size?: number; // Size in pixels
  animation?: 'idle' | 'walk' | 'cast';
  direction?: 'down' | 'up' | 'left' | 'right';
  tick?: number; // Animation frame counter
  race?: string; // Character's active race
}

// Global caching system for recolored retro sprite sheets
const recoloredCache: Record<string, string> = {};
const pendingPromises: Record<string, Promise<string>> = {};
const activeListeners: Record<string, (() => void)[]> = {};

// Asynchronously loads a sprite sheet, classifies its pixel colors, and swaps them to fit the custom palette.
async function processRecolor(key: {
  retroId: number;
  hairColor: string;
  eyeColor: string;
}): Promise<string> {
  const originalUrl = `/characters/character_${key.retroId}/character_${key.retroId}_frame32x32.png`;
  
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = originalUrl;
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(originalUrl);
          return;
        }
        ctx.drawImage(img, 0, 0);
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imgData.data;

        const width = canvas.width;
        const height = canvas.height;

        const rgbToKey = (r: number, g: number, b: number) => `${r},${g},${b}`;
        const parseKey = (keyStr: string) => {
          const [r, g, b] = keyStr.split(',').map(Number);
          return { r, g, b };
        };

        // Simple helper to check if a color is outline/neutral black or pure white
        const isOutline = (r: number, g: number, b: number) => r < 20 && g < 20 && b < 20;
        const isWhite = (r: number, g: number, b: number) => r > 240 && g > 240 && b > 240;

        // Group pixels by unique color and gather positioning metrics
        const colorCounts: Record<string, {
          r: number;
          g: number;
          b: number;
          topCount: number;      // ly <= 10 (top of the head)
          centerFaceCount: number; // ly in [10, 15] && lx in [11, 21] (face skin + eyes)
          eyeZoneCount: number;   // ly in [11, 13] && lx in [12, 20]
          bodyCount: number;      // ly in [16, 26] (outfit)
          total: number;
        }> = {};

        for (let y = 0; y < height; y++) {
          for (let x = 0; x < width; x++) {
            const idx = (y * width + x) * 4;
            const r = data[idx];
            const g = data[idx + 1];
            const b = data[idx + 2];
            const a = data[idx + 3];

            if (a === 0) continue;
            if (isOutline(r, g, b) || isWhite(r, g, b)) continue;

            const colorKey = rgbToKey(r, g, b);
            if (!colorCounts[colorKey]) {
              colorCounts[colorKey] = {
                r, g, b,
                topCount: 0,
                centerFaceCount: 0,
                eyeZoneCount: 0,
                bodyCount: 0,
                total: 0
              };
            }

            const stats = colorCounts[colorKey];
            stats.total++;

            const lx = x % 32;
            const ly = y % 32;

            if (ly >= 2 && ly <= 9) {
              if (ly >= 8 && lx >= 11 && lx <= 21) {
                stats.centerFaceCount++;
              } else {
                stats.topCount++;
              }
            } else if (ly >= 10 && ly <= 15) {
              if (lx >= 11 && lx <= 21) {
                stats.centerFaceCount++;
                if (ly >= 11 && ly <= 13 && lx >= 12 && lx <= 20) {
                  stats.eyeZoneCount++;
                }
              } else {
                stats.topCount++;
              }
            } else if (ly >= 16 && ly <= 26) {
              stats.bodyCount++;
            }
          }
        }

        const originalHairKeys: string[] = [];
        const originalEyeKeys: string[] = [];

        Object.entries(colorCounts).forEach(([colorKey, stats]) => {
          const maxVal = Math.max(stats.topCount, stats.centerFaceCount, stats.bodyCount);
          if (maxVal === 0) return;

          if (maxVal === stats.topCount) {
            originalHairKeys.push(colorKey);
          } else if (maxVal === stats.centerFaceCount) {
            if (stats.eyeZoneCount > 0 && stats.total < 120) {
              originalEyeKeys.push(colorKey);
            }
          }
        });

        // 4. Generate user color shades
        const getCustomShades = (baseHex: string, count: number) => {
          if (!baseHex || baseHex[0] !== '#') return Array(count).fill({ r: 128, g: 128, b: 128 });
          const r = parseInt(baseHex.slice(1, 3), 16);
          const g = parseInt(baseHex.slice(3, 5), 16);
          const b = parseInt(baseHex.slice(5, 7), 16);

          if (count <= 1) {
            return [{ r, g, b }];
          }

          const shades = [];
          for (let i = 0; i < count; i++) {
            const factor = 0.55 + (i / (count - 1)) * 0.85;
            shades.push({
              r: Math.max(0, Math.min(255, Math.round(r * factor))),
              g: Math.max(0, Math.min(255, Math.round(g * factor))),
              b: Math.max(0, Math.min(255, Math.round(b * factor))),
            });
          }
          return shades;
        };

        // Sort keys by brightness for smooth gradient generation
        const getBrightness = (keyStr: string) => {
          const { r, g, b } = parseKey(keyStr);
          return (r + g + b) / 3;
        };

        originalHairKeys.sort((a, b) => getBrightness(a) - getBrightness(b));
        originalEyeKeys.sort((a, b) => getBrightness(a) - getBrightness(b));

        const hairShades = getCustomShades(key.hairColor, Math.max(1, originalHairKeys.length));
        const eyeShades = getCustomShades(key.eyeColor, Math.max(1, originalEyeKeys.length));

        // Create mappings
        const hairReplacement: Record<string, { r: number; g: number; b: number }> = {};
        originalHairKeys.forEach((k, idx) => {
          hairReplacement[k] = hairShades[Math.min(idx, hairShades.length - 1)];
        });

        const eyeReplacement: Record<string, { r: number; g: number; b: number }> = {};
        originalEyeKeys.forEach((k, idx) => {
          eyeReplacement[k] = eyeShades[Math.min(idx, eyeShades.length - 1)];
        });

        const fallbackEyeColor = eyeShades[Math.floor(eyeShades.length / 2)];

        // 5. Replace pixels
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const a = data[i + 3];

          if (a === 0) continue;

          const colorKey = rgbToKey(r, g, b);

          const pixelIndex = i / 4;
          const x = pixelIndex % width;
          const y = Math.floor(pixelIndex / width);
          const lx = x % 32;
          const ly = y % 32;
          const frameRow = Math.floor(y / 32) % 4;

          const isEyeRegion = ly >= 11 && ly <= 13 && lx >= 11 && lx <= 21 && frameRow < 3;

          if (isEyeRegion) {
            if (originalEyeKeys.includes(colorKey)) {
              const target = eyeReplacement[colorKey];
              data[i] = target.r;
              data[i + 1] = target.g;
              data[i + 2] = target.b;
            } else if (originalHairKeys.includes(colorKey)) {
              const target = eyeShades[Math.floor(eyeShades.length / 2)] || fallbackEyeColor;
              data[i] = target.r;
              data[i + 1] = target.g;
              data[i + 2] = target.b;
            }
          } else {
            // Check if it's hair and located in the head region (ly <= 16)
            if (originalHairKeys.includes(colorKey) && ly <= 16) {
              const target = hairReplacement[colorKey];
              data[i] = target.r;
              data[i + 1] = target.g;
              data[i + 2] = target.b;
            }
          }
        }

        ctx.putImageData(imgData, 0, 0);
        resolve(canvas.toDataURL());
      } catch (e) {
        console.error('Error during recoloring:', e);
        resolve(originalUrl);
      }
    };

    img.onerror = () => {
      resolve(originalUrl);
    };
  });
}

// React custom hook to get recolored sprite sheet URL
export function useRecoloredSprite(key: {
  retroId: number;
  hairColor: string;
  eyeColor: string;
}) {
  const cacheKey = `${key.retroId}-${key.hairColor}-${key.eyeColor}`;
  const [spriteUrl, setSpriteUrl] = useState<string | null>(recoloredCache[cacheKey] || null);

  useEffect(() => {
    // If already in cache, update state and do nothing else
    if (recoloredCache[cacheKey]) {
      setSpriteUrl(recoloredCache[cacheKey]);
      return;
    }

    // Set up a listener for when this cacheKey becomes available
    if (!activeListeners[cacheKey]) {
      activeListeners[cacheKey] = [];
    }
    const listener = () => {
      setSpriteUrl(recoloredCache[cacheKey]);
    };
    activeListeners[cacheKey].push(listener);

    // If there's no promise running for this key, start one!
    if (!pendingPromises[cacheKey]) {
      pendingPromises[cacheKey] = (async () => {
        const url = await processRecolor(key);
        recoloredCache[cacheKey] = url;
        // Notify all listeners
        const listeners = activeListeners[cacheKey] || [];
        delete activeListeners[cacheKey];
        delete pendingPromises[cacheKey];
        listeners.forEach(l => l());
        return url;
      })();
    }

    return () => {
      // Clean up listener
      if (activeListeners[cacheKey]) {
        activeListeners[cacheKey] = activeListeners[cacheKey].filter(l => l !== listener);
      }
    };
  }, [cacheKey, key.retroId, key.hairColor, key.eyeColor]);

  return spriteUrl;
}

// Helper to darken a color (for pixel shadows)
export function adjustColorBrightness(hex: string, percent: number): string {
  // Simple hex darkener
  if (!hex || hex[0] !== '#') return hex;
  let r = parseInt(hex.slice(1, 3), 16);
  let g = parseInt(hex.slice(3, 5), 16);
  let b = parseInt(hex.slice(5, 7), 16);

  r = Math.max(0, Math.min(255, Math.round(r * (1 + percent))));
  g = Math.max(0, Math.min(255, Math.round(g * (1 + percent))));
  b = Math.max(0, Math.min(255, Math.round(b * (1 + percent))));

  const rStr = r.toString(16).padStart(2, '0');
  const gStr = g.toString(16).padStart(2, '0');
  const bStr = b.toString(16).padStart(2, '0');

  return `#${rStr}${gStr}${bStr}`;
}

export default function PixelSprite({
  customization,
  className = '',
  size = 128,
  animation = 'idle',
  direction = 'down',
  tick = 0,
  race = 'human',
}: PixelSpriteProps) {
  // Render pre-drawn retro character sheets if toggled
  const retroId = customization.retroSpriteId || 1;
  
  if (customization.useRetroSprite) {
    const spriteUrl = `/characters/character_${retroId}/character_${retroId}_frame32x32.png`;
    
    const directionRows: Record<string, number> = {
      down: 0,
      left: 1,
      right: 2,
      up: 3,
    };
    const rowIndex = directionRows[direction] !== undefined ? directionRows[direction] : 0;
    
    // Cycle columns: 0, 1, 2, 1 (4-step classic RPG walk cycle)
    const colIndex = [0, 1, 2, 1][tick % 4];
    
    const scale = size / 32;
    const sheetWidth = scale * 96;
    const sheetHeight = scale * 128;
    const posX = -colIndex * size;
    const posY = -rowIndex * size;

    return (
      <div
        className={`relative select-none flex items-center justify-center ${className}`}
        style={{
          width: size,
          height: size,
          backgroundImage: `url(${spriteUrl})`,
          backgroundSize: `${sheetWidth}px ${sheetHeight}px`,
          backgroundPosition: `${posX}px ${posY}px`,
          backgroundRepeat: 'no-repeat',
          imageRendering: 'pixelated',
        }}
        id={`pixel-sprite-retro-${retroId}`}
      >
        {/* Soft shadow circle below character */}
        <div 
          className="absolute bottom-[2%] left-1/2 -translate-x-1/2 w-[65%] h-[12%] bg-black/30 rounded-full"
          style={{ filter: 'blur(1px)', zIndex: -1 }}
        />
      </div>
    );
  }

  // Destructure customization
  const {
    skinColor,
    hairStyle,
    hairColor,
    accessory,
    accessoryColor,
    eyeStyle,
    eyeColor,
    outfitStyle,
    outfitColor,
    innerColor,
    weaponStyle,
    weaponColor,
    blush,
  } = customization;

  // Generate shadow colors for layers
  const skinShadow = useMemo(() => adjustColorBrightness(skinColor, -0.2), [skinColor]);
  const hairShadow = useMemo(() => adjustColorBrightness(hairColor, -0.25), [hairColor]);
  const outfitShadow = useMemo(() => adjustColorBrightness(outfitColor, -0.2), [outfitColor]);
  const weaponShadow = useMemo(() => adjustColorBrightness(weaponColor, -0.25), [weaponColor]);
  const accessoryShadow = useMemo(() => adjustColorBrightness(accessoryColor, -0.25), [accessoryColor]);

  // Color map
  const colorMap: Record<string, string> = {
    // Skin
    'S': skinColor,
    'D': skinShadow,
    // Hair
    'H': hairColor,
    'h': hairShadow,
    // Eyes
    'E': eyeColor,
    'e': '#ffffff', // White glint
    'K': '#1e293b', // Dark eye border
    // Outfit
    'O': outfitColor,
    'o': outfitShadow,
    'I': innerColor || '#f8fafc', // Inner shirt / accent
    'X': '#ffd700', // Gold accents
    // Accessory
    'A': accessoryColor,
    'a': accessoryShadow,
    'P': '#ff85a2', // Cute pink blush / bunny ear inner
    // Weapon
    'W': weaponColor,
    'w': weaponShadow,
    'M': '#b45309', // Wood brown
    // Miscellaneous
    'B': '#000000', // Black outlines
  };

  // Grid is 16x16
  const GRID_SIZE = 16;

  // Let's design 16x16 grids for each layer
  // S = Skin, D = Skin Shadow, O = Outfit, o = Outfit Shadow, H = Hair, h = Hair Shadow...
  // . = Transparent

  // Base Body (symmetrical chibi template matching the photo)
  const bodyGrid = [
    '................',
    '................',
    '................',
    '.....BBBBBB.....', // Row 3: head top outline
    '....BSSSSSSB....', // Row 4: forehead
    '...BSSSSSSSSB...', // Row 5: temples
    '..BSSSSSSSSSSB..', // Row 6: eye level skin
    '..BSSSSSSSSSSB..', // Row 7: cheek level skin
    '...BSSSSSSSSB...', // Row 8: jawline
    '....BBSSSSBB....', // Row 9: neck (skin with dark outlines)
    '.....BSSSSB.....', // Row 10: shoulders (skin base)
    '....BSSSSSSB....', // Row 11: chest / arms
    '....BSSSSSSB....', // Row 12: hips
    '.....BSSSSB.....', // Row 13: legs top
    '.....B.SS.B.....', // Row 14: legs bottom (separated)
    '....BB....BB....', // Row 15: feet with outlines
  ];

  // Eyes Styles (placed beautifully at Row 6)
  const eyesGrids: Record<string, string[]> = {
    classic: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '......K..K......', // Cute standard black eyes spaced 2 pixels apart
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    hero: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '.....eK..Ke.....', // White glints next to black pupils
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ]
  };

  // Hair Styles (rounded outlines and nice volume wrapping the head)
  const hairGrids: Record<string, string[]> = {
    spiky: [
      '......H..H......',
      '.....HHHHHH.....',
      '....BHHHHHHB....',
      '...BHHHHHHHHB...',
      '..BHHhSSSSshHB..',
      '..BHhSSSSSSshB..',
      '..BH........HB..',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    long: [
      '.....HHHHHH.....',
      '....BHHHHHHB....',
      '...BHHHHHHHHB...',
      '..BHHHHHHHHHHB..',
      '..BHhSSSSSSshB..',
      '..BHhSSSSSSshB..',
      '..BHhSSSSSSshB..',
      '..BHh......shB..',
      '..BHh......shB..',
      '..B..........B..',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    twintails: [
      '.....HHHHHH.....',
      '....BHHHHHHB....',
      '...BHHHHHHHHB...',
      '..BHHHHHHHHHHB..',
      '..BHhSSSSSSshB..',
      '..BHhSSSSSSshB..',
      '..BHhSSSSSSshB..',
      '..BHH......HHB..',
      '.BHH........HHB.',
      '.BH..........HB.',
      '..B..........B..',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    messy: [
      '....H.H..H.H....',
      '....HHHHHHHH....',
      '...BHHHHHHHHB...',
      '..BHHHHHHHHHHB..',
      '..BHhSSSSSSshB..',
      '..BHhSSSSSSshB..',
      '..BH........HB..',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    bob: [
      '.....HHHHHH.....',
      '....BHHHHHHB....',
      '...BHHHHHHHHB...',
      '..BHHHHHHHHHHB..',
      '..BHhSSSSSSshB..',
      '..BHhSSSSSSshB..',
      '..BHH......HHB..',
      '...B........B...',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    none: []
  };

  // Head Accessories (Added Knight Helmet, Ranger Hood, Mage Hood)
  const accessoryGrids: Record<string, string[]> = {
    bunny: [
      '....A......A....',
      '...AaPa..aPaA...',
      '...A.P.A..A.P.A.',
      '....A......A....',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    witch: [
      '.......AA.......',
      '......AaAA......',
      '.....AaaAAA.....',
      '....AaaaAAAA....',
      '..AAAAAAAAAAAA..',
      '.AAAAAAAAAAAAAA.',
      '..aaaa....aaaa..',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    cap: [
      '.....AAAAAA.....',
      '....AaAAAAaA....',
      '...AaaaaaaaaA...',
      '..AAAAAAAAAAAA..',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    helmet: [
      '.......P........', // Red feather/crest tip
      '......PP........', // Red feather/crest body
      '.....BBBBBB.....', // Outline of steel helmet
      '....BWWWWWWBB...', // Silver steel helmet top
      '...BWWWWWWWWBB..', // Helmet sides
      '..BWW......WWB..', // Visor opening (shows eyes)
      '..BWW......WWB..',
      '...BWWWWWWWWB...', // Chin protection
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    hood_green: [
      '................',
      '.....BBBBBB.....', // Outline of green hood
      '....BAAAAAAB....', // Green hood top (using accessoryColor)
      '...BAAAAAAAAAB..',
      '..BAAAAAAAAAAAB.',
      '..BAA......AAB..', // Hood face cutout
      '..BAA......AAB..',
      '...BAAAAAAAB....', // Wrap around neck
      '....BAAAAAB.....', // Hood collar flap
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    hood_purple: [
      '................',
      '.....BBBBBB.....', // Outline of purple hood
      '....BAAAAAAB....', // Purple hood top (using accessoryColor)
      '...BAAAAAAAAAB..',
      '..BAAAAAAAAAAAB.',
      '..BAA......AAB..', // Hood face cutout
      '..BAA......AAB..',
      '...BAAAAAAAB....', // Wrap around neck
      '....BAAAAAB.....', // Hood collar flap
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
    ],
    none: []
  };

  // Outfit Styles (Symmetrical chibi narrow-shoulders clothing matching the photo)
  const outfitGrids: Record<string, string[]> = {
    jacket: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '.....oooooo.....', // Collar outline
      '....BOOOOOOB....', // Shoulders
      '...BBOOOOOOBB...', // Chest
      '...BBOOIIOOBB...', // Open jacket showing inner shirt
      '....BOOIIOOB....', // Lower torso
      '....BooooooB....', // Jacket hem
      '................',
    ],
    apron: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '.....oooooo.....',
      '....BIIIIIIB....', // Straps + inner shirt
      '...BBIIIIIIBB...',
      '...BBOOOOOOBB...', // Apron front
      '....BOOOOOOB....',
      '....BooooooB....',
      '................',
    ],
    sweater: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '.....oooooo.....',
      '....BOOOOOOB....',
      '...BBOOOOOOBB...',
      '...BBOOIIOOBB...', // Sweater stripe pattern
      '....BOOOOOOB....',
      '....BooooooB....',
      '................',
    ],
    t_shirt: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '.....oooooo.....', // Neck line
      '....BOOOOOOB....', // Shoulders
      '...BBOOOOOOBB...', // Short sleeves
      '....BOOOOOOB....', // Waist
      '....BOOOOOOB....', // Torso bottom
      '....BooooooB....', // T-shirt hem
      '................',
    ],
    hoodie: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '....OOOOOOOO....', // Cozy hood collar
      '....BOOOOOOB....',
      '...BBOOOOOOBB...', // Long sleeves
      '...BBOOIIOOBB...', // Front pouch pocket logo
      '....BOOOOOOB....',
      '....BOOOOOOB....',
      '....BooooooB....', // Ribbed hem
      '................',
    ]
  };

  // Weapon / Shield Styles
  const weaponGrids: Record<string, string[]> = {
    sword: [
      '...............I',
      '..............II',
      '.............II.',
      '............II..',
      '...........II...',
      '..........II....',
      '.........II.....',
      '........II......',
      '.......II.......',
      '......II........',
      '......I.........',
      '..........XWX...', // Row 11: Crossguard
      '...........M....', // Row 12: Handle
      '...........M....', // Row 13: Pommel
      '................',
      '................',
    ],
    staff: [
      '................',
      '................',
      '...........W....', // Top tip
      '..........WWW...', // Crystal head
      '..........WMW...',
      '...........M....', // Staff shaft starts
      '...........M....',
      '...........M....',
      '...........M....',
      '...........M....',
      '...........M....',
      '...........M....', // Hand grip at index 11
      '...........M....',
      '...........M....',
      '...........M....',
      '................',
    ],
    bow: [
      '................',
      '............M...',
      '...........M.I..',
      '..........M..I..',
      '.........M...I..',
      '........M....I..',
      '.......M.....I..',
      '......M......I..',
      '......M......I..',
      '......M......I..',
      '......M......I..',
      '..WWWWWWWWWWWI..', // Row 11: Arrow in hand!
      '......M......I..',
      '.......M.....I..',
      '........M....I..',
      '.........MM..I..',
    ],
    shield: [
      '................',
      '................',
      '................',
      '................',
      '................',
      '................',
      '..WWWWWWW.......',
      '.WwwwwwwwW......',
      'WwwwwwwwwwW.....',
      'WwwwWwWwwwW.....',
      'WwWwwWwwWwW.....',
      'WwwwwwwwwwW.....', // Centered on Left Hand (Col 4)
      '.WwwwwwwwW......',
      '..WwwwwwW.......',
      '...WwwW.........',
      '....W...........',
    ],
    none: []
  };

  // We layer them together into a single 16x16 grid
  // Order: 1. Body, 2. Eyes, 3. Blush Cheeks, 4. Outfit, 5. Hair, 6. Accessory, 7. Weapon
  const finalGrid = useMemo(() => {
    const grid = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill('.'));

    // 1. Draw Body
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        const char = bodyGrid[r]?.[c];
        if (char && char !== '.') {
          grid[r][c] = char;
        }
      }
    }

    // 2. Draw Outfit
    const outfitGrid = outfitGrids[outfitStyle];
    if (outfitGrid) {
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const char = outfitGrid[r]?.[c];
          if (char && char !== '.') {
            grid[r][c] = char;
          }
        }
      }
    }

    // 3. Draw Eyes
    const eyeGrid = eyesGrids[eyeStyle];
    if (eyeGrid) {
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const char = eyeGrid[r]?.[c];
          if (char && char !== '.') {
            grid[r][c] = char;
          }
        }
      }
    }

    // 4. Draw Blush Cheeks
    if (blush) {
      // Blush rosy pixels below eyes
      grid[6][4] = 'P';
      grid[6][11] = 'P';
    }

    // 5. Draw Hair
    const hairGrid = hairGrids[hairStyle];
    if (hairGrid) {
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const char = hairGrid[r]?.[c];
          if (char && char !== '.') {
            grid[r][c] = char;
          }
        }
      }
    }

    // 6. Draw Accessory (e.g. bunny ears, witch hat, cap)
    const accessoryGrid = accessoryGrids[accessory];
    if (accessoryGrid) {
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const char = accessoryGrid[r]?.[c];
          if (char && char !== '.') {
            grid[r][c] = char;
          }
        }
      }
    }

    // 7. Draw Weapon
    const weaponGrid = weaponGrids[weaponStyle];
    if (weaponGrid) {
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const char = weaponGrid[r]?.[c];
          if (char && char !== '.') {
            grid[r][c] = char;
          }
        }
      }
    }

    // --- RACE-SPECIFIC APPEARANCE MODIFICATIONS (Ears, Horns, Tattoos) ---
    if (race === 'neko') {
      // Pointy cat ears on top of head
      grid[2][4] = 'H';
      grid[3][4] = 'P'; // Pink inner
      grid[2][11] = 'H';
      grid[3][11] = 'P';
      // Whiskers tattoo/makeup on cheeks
      grid[6][3] = '#475569';
      grid[6][12] = '#475569';
    } else if (race === 'demon') {
      // Curved red horns on forehead
      grid[2][5] = '#ef4444';
      grid[1][4] = '#ef4444';
      grid[2][10] = '#ef4444';
      grid[1][11] = '#ef4444';
      // Demonic red forehead seal / tattoo
      grid[4][7] = '#b91c1c';
      grid[4][8] = '#b91c1c';
    } else if (race === 'goblin') {
      // Long green pointed goblin ears on the sides
      grid[5][3] = '#76a060';
      grid[5][2] = '#5e804c';
      grid[5][12] = '#76a060';
      grid[5][13] = '#5e804c';
    } else if (race === 'cyborg') {
      // Metal bionic eyepatch plate and neon red cybernetic lines
      grid[5][4] = '#f43f5e'; // Glowing red sensor
      grid[5][5] = '#475569'; // Steel frame
      grid[6][4] = '#475569';
      grid[4][4] = '#475569';
      grid[4][5] = '#f43f5e'; // Circuit trace
    } else if (race === 'vampire') {
      // Crimson eye/cheek teardrop tattoos & vampire fangs
      grid[6][4] = '#991b1b';
      grid[6][11] = '#991b1b';
      grid[7][7] = '#ffffff'; // Fang L
      grid[7][8] = '#ffffff'; // Fang R
    } else if (race === 'uchiha') {
      // Sharingan cheek seal markings (curse-mark lines)
      grid[5][4] = '#ef4444';
      grid[5][11] = '#ef4444';
      grid[6][5] = '#1e1b4b';
      grid[6][10] = '#1e1b4b';
    } else if (race === 'ghoul') {
      // Red Kakugan veins and dark tear trails
      grid[5][4] = '#7f1d1d';
      grid[5][11] = '#7f1d1d';
      grid[6][4] = '#000000';
      grid[6][11] = '#000000';
    } else if (race === 'otsutsuki') {
      // White Otsutsuki rabbit-ear horns and forehead Golden Rinnegan marking
      grid[2][7] = '#f1f5f9';
      grid[2][8] = '#f1f5f9';
      grid[3][7] = '#cbd5e1';
      grid[3][8] = '#cbd5e1';
      grid[4][7] = '#fbbf24'; // Karma marking
      grid[4][8] = '#fbbf24';
    } else if (race === 'hollow' || race === 'arrancar') {
      // White bone jaw hollow mask armor on cheeks
      grid[6][4] = '#f8fafc';
      grid[6][5] = '#f8fafc';
      grid[6][10] = '#f8fafc';
      grid[6][11] = '#f8fafc';
      grid[7][4] = '#f1f5f9';
      grid[7][11] = '#f1f5f9';
    } else if (race === 'sun_god') {
      // Fiery forehead markings (Nika swirls)
      grid[3][7] = '#f97316';
      grid[3][8] = '#f97316';
      grid[4][6] = '#f97316';
      grid[4][9] = '#f97316';
    }

    // Apply animation adjustments
    // Idle breathing: scale up/down or shift head slightly
    const outputGrid = grid.map(row => [...row]);
    if (animation === 'idle') {
      const isUp = (tick % 4) < 2;
      if (isUp) {
        for (let r = 0; r < 14; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (c >= 3 && c <= 12 && r < 9) {
              outputGrid[r][c] = grid[r + 1]?.[c] || '.';
            }
          }
        }
      }
    } else if (animation === 'walk') {
      const isStep = (tick % 2) === 1;
      if (isStep) {
        for (let r = 15; r > 0; r--) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (r < 13) {
              outputGrid[r][c] = grid[r - 1]?.[c] || '.';
            }
          }
        }
        outputGrid[14][5] = outputGrid[14][5] === '.' ? 'D' : '.';
        outputGrid[14][10] = outputGrid[14][10] === '.' ? 'D' : '.';
      }
    } else if (animation === 'cast') {
      const isFlash = (tick % 2) === 1;
      if (isFlash) {
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (outputGrid[r][c] === 'W') {
              outputGrid[r][c] = '#ffffff';
            }
          }
        }
      }
    }

    return outputGrid;
  }, [
    customization,
    hairStyle,
    eyeStyle,
    outfitStyle,
    accessory,
    blush,
    weaponStyle,
    animation,
    tick,
    bodyGrid,
    eyesGrids,
    hairGrids,
    accessoryGrids,
    outfitGrids,
    weaponGrids,
    race,
  ]);

  // Determine pixel sizes
  const pixelSize = size / GRID_SIZE;

  return (
    <div
      className={`relative select-none flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
      id="pixel-sprite-container"
    >
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="w-full h-full"
        style={{ shapeRendering: 'crispEdges' }}
      >
        <style>{`
          @keyframes auraPulse {
            0%, 100% { transform: scale(0.96) translateY(0px); opacity: 0.7; }
            50% { transform: scale(1.06) translateY(-2px); opacity: 0.95; }
          }
          @keyframes emberFloat {
            0% { transform: translateY(10px) scale(0.8); opacity: 0; }
            20% { opacity: 0.8; }
            100% { transform: translateY(-30px) scale(0.3); opacity: 0; }
          }
          @keyframes sunRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          @keyframes ripple {
            0% { transform: scale(0.5); opacity: 0.9; stroke-width: 3; }
            100% { transform: scale(1.2); opacity: 0; stroke-width: 1; }
          }
          @keyframes wingPulse {
            0%, 100% { transform: rotate(-8deg) scale(0.95); }
            50% { transform: rotate(8deg) scale(1.05); }
          }
          @keyframes sparkRun {
            0% { stroke-dashoffset: 100; }
            100% { stroke-dashoffset: 0; }
          }
          .aura-pulse {
            animation: auraPulse 3s infinite ease-in-out;
          }
          .ember-particle {
            animation: emberFloat 1.8s infinite linear;
            transform-origin: bottom center;
          }
          .sun-rotate {
            animation: sunRotate 12s infinite linear;
          }
          .ripple-ring {
            animation: ripple 2.2s infinite ease-out;
          }
          .wing-pulse {
            animation: wingPulse 3.5s infinite ease-in-out;
          }
          .spark-animate {
            animation: sparkRun 1.2s infinite linear;
          }
        `}</style>

        <defs>
          <radialGradient id="saiyanAura" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#eab308" stopOpacity="0.85" />
            <stop offset="60%" stopColor="#ca8a04" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#ca8a04" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="demonAura" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#c084fc" stopOpacity="0.85" />
            <stop offset="65%" stopColor="#7e22ce" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#7e22ce" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="vampireAura" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.85" />
            <stop offset="60%" stopColor="#be123c" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#be123c" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="sunGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
            <stop offset="45%" stopColor="#fef08a" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="shinigamiAura" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#475569" stopOpacity="0.9" />
            <stop offset="55%" stopColor="#1e293b" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#0f172a" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="esperAura" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.8" />
            <stop offset="60%" stopColor="#0891b2" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#0891b2" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* --- DYNAMIC SVG BACKGROUND AURAS --- */}
        {race === 'saiyan' && (
          <g>
            {/* Pulsing golden saiyan aura */}
            <circle
              cx={size / 2}
              cy={size * 0.55}
              r={size * 0.42}
              fill="url(#saiyanAura)"
              className="aura-pulse"
              style={{ transformOrigin: `${size / 2}px ${size * 0.55}px` }}
            />
            {/* Electrical sparkles */}
            <path
              d={`M ${size * 0.28} ${size * 0.72} L ${size * 0.38} ${size * 0.42} L ${size * 0.44} ${size * 0.5} L ${size * 0.54} ${size * 0.22}`}
              stroke="#60a5fa"
              strokeWidth="2.5"
              fill="none"
              className="spark-animate"
              strokeDasharray="100"
              strokeDashoffset="100"
            />
            <path
              d={`M ${size * 0.72} ${size * 0.72} L ${size * 0.62} ${size * 0.47} L ${size * 0.56} ${size * 0.52} L ${size * 0.46} ${size * 0.28}`}
              stroke="#60a5fa"
              strokeWidth="2"
              fill="none"
              className="spark-animate"
              strokeDasharray="100"
              strokeDashoffset="100"
              style={{ animationDelay: '0.4s' }}
            />
          </g>
        )}

        {race === 'demon' && (
          <g>
            <circle
              cx={size / 2}
              cy={size * 0.55}
              r={size * 0.42}
              fill="url(#demonAura)"
              className="aura-pulse"
              style={{ transformOrigin: `${size / 2}px ${size * 0.55}px` }}
            />
            {/* Rising magical purple fire embers */}
            <circle cx={size * 0.3} cy={size * 0.6} r="3" fill="#e9d5ff" className="ember-particle" style={{ animationDelay: '0s' }} />
            <circle cx={size * 0.7} cy={size * 0.5} r="2.5" fill="#c084fc" className="ember-particle" style={{ animationDelay: '0.5s' }} />
            <circle cx={size * 0.42} cy={size * 0.4} r="2" fill="#d8b4fe" className="ember-particle" style={{ animationDelay: '0.9s' }} />
            <circle cx={size * 0.58} cy={size * 0.7} r="3.5" fill="#faf5ff" className="ember-particle" style={{ animationDelay: '1.3s' }} />
          </g>
        )}

        {race === 'vampire' && (
          <g>
            <circle
              cx={size / 2}
              cy={size * 0.55}
              r={size * 0.4}
              fill="url(#vampireAura)"
              className="aura-pulse"
              style={{ transformOrigin: `${size / 2}px ${size * 0.55}px` }}
            />
            {/* Floating blood particles */}
            <circle cx={size * 0.32} cy={size * 0.55} r="2.5" fill="#f43f5e" className="ember-particle" style={{ animationDelay: '0.1s' }} />
            <circle cx={size * 0.68} cy={size * 0.65} r="2.2" fill="#be123c" className="ember-particle" style={{ animationDelay: '0.6s' }} />
            <circle cx={size * 0.45} cy={size * 0.45} r="3" fill="#fda4af" className="ember-particle" style={{ animationDelay: '1.1s' }} />
          </g>
        )}

        {race === 'sun_god' && (
          <g className="sun-rotate" style={{ transformOrigin: `${size / 2}px ${size * 0.45}px` }}>
            {/* Giant spinning sun gear halo behind character */}
            <circle
              cx={size / 2}
              cy={size * 0.45}
              r={size * 0.3}
              stroke="#fbbf24"
              strokeWidth="4"
              strokeDasharray="6 6"
              fill="none"
              opacity="0.8"
            />
            <circle
              cx={size / 2}
              cy={size * 0.45}
              r={size * 0.36}
              stroke="#ffffff"
              strokeWidth="2.5"
              strokeDasharray="16 16"
              fill="none"
              opacity="0.6"
            />
            <circle
              cx={size / 2}
              cy={size * 0.45}
              r={size * 0.24}
              fill="url(#sunGlow)"
            />
          </g>
        )}

        {race === 'esper' && (
          <g>
            <circle
              cx={size / 2}
              cy={size * 0.55}
              r={size * 0.4}
              fill="url(#esperAura)"
              className="aura-pulse"
              style={{ transformOrigin: `${size / 2}px ${size * 0.55}px` }}
            />
            {/* Rippling telekinetic rings */}
            <circle
              cx={size / 2}
              cy={size * 0.55}
              r={size * 0.36}
              stroke="#22d3ee"
              strokeWidth="2.5"
              fill="none"
              className="ripple-ring"
              style={{ animationDelay: '0s', transformOrigin: `${size / 2}px ${size * 0.55}px` }}
            />
            <circle
              cx={size / 2}
              cy={size * 0.55}
              r={size * 0.36}
              stroke="#06b6d4"
              strokeWidth="1.5"
              fill="none"
              className="ripple-ring"
              style={{ animationDelay: '1.1s', transformOrigin: `${size / 2}px ${size * 0.55}px` }}
            />
          </g>
        )}

        {race === 'ghoul' && (
          <g>
            {/* Moving black/red kagune wings */}
            <path
              d={`M ${size * 0.4} ${size * 0.6} C ${size * 0.05} ${size * 0.42}, ${size * 0.15} ${size * 0.05}, ${size * 0.28} ${size * 0.48} Z`}
              fill="#be123c"
              stroke="#000"
              strokeWidth="1.5"
              opacity="0.85"
              className="wing-pulse"
              style={{ transformOrigin: `${size * 0.4}px ${size * 0.6}px` }}
            />
            <path
              d={`M ${size * 0.6} ${size * 0.6} C ${size * 0.95} ${size * 0.42}, ${size * 0.85} ${size * 0.05}, ${size * 0.72} ${size * 0.48} Z`}
              fill="#be123c"
              stroke="#000"
              strokeWidth="1.5"
              opacity="0.85"
              className="wing-pulse"
              style={{ transformOrigin: `${size * 0.6}px ${size * 0.6}px`, animationDelay: '0.4s' }}
            />
          </g>
        )}

        {race === 'shinigami' && (
          <g>
            {/* Rising black soul-reaper pressure spiritual smoke */}
            <circle
              cx={size / 2}
              cy={size * 0.55}
              r={size * 0.42}
              fill="url(#shinigamiAura)"
              className="aura-pulse"
              style={{ transformOrigin: `${size / 2}px ${size * 0.55}px` }}
            />
            <circle cx={size * 0.35} cy={size * 0.65} r="3" fill="#64748b" className="ember-particle" style={{ animationDelay: '0s' }} />
            <circle cx={size * 0.65} cy={size * 0.62} r="2.5" fill="#334155" className="ember-particle" style={{ animationDelay: '0.6s' }} />
          </g>
        )}

        {/* Render shadow circle below character */}
        <ellipse
          cx={size / 2}
          cy={size * 0.9}
          rx={size * 0.28}
          ry={size * 0.08}
          fill="rgba(0, 0, 0, 0.25)"
        />

        {/* Render 16x16 grid */}
        {finalGrid.map((row, rIdx) =>
          row.map((cell, cIdx) => {
            if (cell === '.') return null;
            // Lookup hex color
            const fill = colorMap[cell] || cell;
            return (
              <rect
                key={`${rIdx}-${cIdx}`}
                x={cIdx * pixelSize}
                y={rIdx * pixelSize}
                width={pixelSize}
                height={pixelSize}
                fill={fill}
              />
            );
          })
        )}
      </svg>
    </div>
  );
}
