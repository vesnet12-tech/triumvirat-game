import { useState, MouseEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  ArrowLeft, 
  Swords, 
  ShieldAlert, 
  AlertTriangle, 
  Edit2, 
  Sparkles, 
  RefreshCw, 
  Coins, 
  Gift, 
  Key, 
  CheckCircle, 
  Flame, 
  Dice5,
  Gamepad2,
  Info
} from 'lucide-react';
import { Character, CLASSES, RACES, TRAITS, RarityType } from '../types';
import PixelSprite from './PixelSprite';
import { playSound } from '../utils/audio';

interface SlotSelectionProps {
  character: Character | null;
  onSelectCreate: () => void;
  onSelectPlay: () => void;
  onDeleteCharacter: () => void;
  onBack: () => void;
  onSelectEdit: (character: Character) => void;
  onUpdateCharacter?: (character: Character) => void;
}

// Stats recalculator based on old/new Race and Trait
function calculateNewStats(
  currentStats: Character['stats'],
  oldRaceId: string,
  newRaceId: string,
  oldTraitId: string,
  newTraitId: string
) {
  const oldRace = RACES.find(r => r.id === oldRaceId) || RACES[0];
  const newRace = RACES.find(r => r.id === newRaceId) || RACES[0];
  const oldTrait = TRAITS.find(t => t.id === oldTraitId) || null;
  const newTrait = TRAITS.find(t => t.id === newTraitId) || null;

  const stats = { ...currentStats };

  // Remove old race bonuses
  stats.str -= (oldRace.statBonus.str || 0);
  stats.agi -= (oldRace.statBonus.agi || 0);
  stats.int -= (oldRace.statBonus.int || 0);
  stats.vit -= (oldRace.statBonus.vit || 0);

  // Add new race bonuses
  stats.str += (newRace.statBonus.str || 0);
  stats.agi += (newRace.statBonus.agi || 0);
  stats.int += (newRace.statBonus.int || 0);
  stats.vit += (newRace.statBonus.vit || 0);

  // Remove old trait bonuses
  if (oldTrait) {
    stats.str -= (oldTrait.statBonus.str || 0);
    stats.agi -= (oldTrait.statBonus.agi || 0);
    stats.int -= (oldTrait.statBonus.int || 0);
    stats.vit -= (oldTrait.statBonus.vit || 0);
  }

  // Add new trait bonuses
  if (newTrait) {
    stats.str += (newTrait.statBonus.str || 0);
    stats.agi += (newTrait.statBonus.agi || 0);
    stats.int += (newTrait.statBonus.int || 0);
    stats.vit += (newTrait.statBonus.vit || 0);
  }

  // Ensure stats don't drop below 1
  stats.str = Math.max(1, stats.str);
  stats.agi = Math.max(1, stats.agi);
  stats.int = Math.max(1, stats.int);
  stats.vit = Math.max(1, stats.vit);

  return stats;
}

export default function SlotSelection({
  character,
  onSelectCreate,
  onSelectPlay,
  onDeleteCharacter,
  onBack,
  onSelectEdit,
  onUpdateCharacter,
}: SlotSelectionProps) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isSelected, setIsSelected] = useState(false);
  const [dashboardTab, setDashboardTab] = useState<'MAIN' | 'ROLLS' | 'CODES'>('MAIN');
  const [playAlertActive, setPlayAlertActive] = useState(false);
  
  // Code Input States
  const [codeInputValue, setCodeInputValue] = useState('');
  const [codeFeedback, setCodeFeedback] = useState<{ success: boolean; message: string; messageRu: string } | null>(null);
  const [usedCodes, setUsedCodes] = useState<string[]>([]);

  // Gacha Ticker States
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinType, setSpinType] = useState<'RACE' | 'TRAIT' | null>(null);
  const [spinDisplay, setSpinDisplay] = useState<string>('');
  const [spinColor, setSpinColor] = useState<string>('#3b82f6');

  // Gacha rolling mechanics
  const rollRandomRarity = (): RarityType => {
    const rng = Math.random();
    if (rng < 0.005) return 'Divine';
    if (rng < 0.03) return 'Mythic';
    if (rng < 0.07) return 'Legendary';
    if (rng < 0.15) return 'Epic';
    if (rng < 0.30) return 'Rare';
    if (rng < 0.55) return 'Uncommon';
    return 'Common';
  };

  const triggerGachaRoll = (type: 'RACE' | 'TRAIT') => {
    if (!character || !onUpdateCharacter) return;
    const currentSpins = character.spins !== undefined ? character.spins : 5;

    if (currentSpins <= 0) {
      playSound('cancel');
      alert('❌ NO SPINS LEFT! Buy more with gold! / У вас нет круток! Купите крутки за золото!');
      return;
    }

    setIsSpinning(true);
    setSpinType(type);
    playSound('select');

    let currentTicks = 0;
    const maxTicks = 12;
    let speed = 70; // millisecond ticking

    const runTicker = () => {
      // Pick random display
      if (type === 'RACE') {
        const randRace = RACES[Math.floor(Math.random() * RACES.length)];
        setSpinDisplay(`${randRace.name.toUpperCase()} [${randRace.rarity.toUpperCase()}]`);
        setSpinColor(randRace.color);
      } else {
        const randTrait = TRAITS[Math.floor(Math.random() * TRAITS.length)];
        setSpinDisplay(`${randTrait.name.toUpperCase()} [${randTrait.rarity.toUpperCase()}]`);
        setSpinColor(randTrait.color);
      }
      playSound('coin');

      currentTicks++;
      if (currentTicks < maxTicks) {
        speed += currentTicks * 18;
        setTimeout(runTicker, speed);
      } else {
        // Compute final outcome
        const finalRarity = rollRandomRarity();
        
        if (type === 'RACE') {
          const matching = RACES.filter(r => r.rarity === finalRarity);
          const finalRace = matching[Math.floor(Math.random() * matching.length)] || RACES[0];
          
          // Recompute stats
          const oldRaceId = character.race || 'human';
          const newRaceId = finalRace.id;
          const oldTraitId = character.trait || '';
          const newStats = calculateNewStats(character.stats, oldRaceId, newRaceId, oldTraitId, oldTraitId);

          const updated: Character = {
            ...character,
            race: newRaceId,
            spins: currentSpins - 1,
            stats: newStats
          };
          onUpdateCharacter(updated);
          playSound('levelUp');
          setSpinDisplay(`RACE: ${finalRace.name}`);
          setSpinColor(finalRace.color);
        } else {
          const matching = TRAITS.filter(t => t.rarity === finalRarity);
          const finalTrait = matching[Math.floor(Math.random() * matching.length)] || TRAITS[0];

          // Recompute stats
          const oldRaceId = character.race || 'human';
          const oldTraitId = character.trait || '';
          const newTraitId = finalTrait.id;
          const newStats = calculateNewStats(character.stats, oldRaceId, oldRaceId, oldTraitId, newTraitId);

          const updated: Character = {
            ...character,
            trait: newTraitId,
            spins: currentSpins - 1,
            stats: newStats
          };
          onUpdateCharacter(updated);
          playSound('levelUp');
          setSpinDisplay(`TRAIT: ${finalTrait.name}`);
          setSpinColor(finalTrait.color);
        }

        setTimeout(() => {
          setIsSpinning(false);
          setSpinType(null);
        }, 1800);
      }
    };

    runTicker();
  };

  const handleBuySpin = () => {
    if (!character || !onUpdateCharacter) return;
    if (character.gold < 100) {
      playSound('cancel');
      alert('❌ NOT ENOUGH GOLD! Need 100 Gold for 1 Gacha Spin. / Недостаточно золота! Нужно 100 золота.');
      return;
    }

    const updated: Character = {
      ...character,
      gold: character.gold - 100,
      spins: (character.spins !== undefined ? character.spins : 5) + 1
    };
    onUpdateCharacter(updated);
    playSound('coin');
  };

  const handleRedeemCode = (e: MouseEvent) => {
    e.preventDefault();
    if (!character || !onUpdateCharacter) return;
    
    const code = codeInputValue.trim().toUpperCase();
    if (!code) return;

    if (usedCodes.includes(code)) {
      playSound('cancel');
      setCodeFeedback({
        success: false,
        message: 'Code already redeemed in this session!',
        messageRu: 'Код уже был активирован в этой сессии!'
      });
      return;
    }

    let spinsAwarded = 0;
    let goldAwarded = 0;
    let valid = false;

    if (code === 'START') {
      spinsAwarded = 5;
      goldAwarded = 200;
      valid = true;
    } else if (code === 'GIFT') {
      spinsAwarded = 3;
      goldAwarded = 100;
      valid = true;
    } else if (code === 'ANIME') {
      spinsAwarded = 10;
      goldAwarded = 1000;
      valid = true;
    } else if (code === 'GODMODE') {
      spinsAwarded = 99;
      goldAwarded = 0;
      valid = true;
    } else if (code === 'IRUNA') {
      spinsAwarded = 15;
      goldAwarded = 500;
      valid = true;
    }

    if (valid) {
      const updated: Character = {
        ...character,
        spins: (character.spins !== undefined ? character.spins : 5) + spinsAwarded,
        gold: character.gold + goldAwarded
      };
      onUpdateCharacter(updated);
      setUsedCodes(prev => [...prev, code]);
      playSound('levelUp');
      setCodeFeedback({
        success: true,
        message: `SUCCESS! Granted +${spinsAwarded} Spins & +${goldAwarded} Gold!`,
        messageRu: `УСПЕШНО! Начислено +${spinsAwarded} круток и +${goldAwarded} золота!`
      });
      setCodeInputValue('');
    } else {
      playSound('cancel');
      setCodeFeedback({
        success: false,
        message: 'INVALID CODE! Check spelling and try again.',
        messageRu: 'НЕВЕРНЫЙ КОД! Попробуйте другой промокод.'
      });
    }
  };

  const handleDelete = (e: MouseEvent) => {
    e.stopPropagation();
    playSound('cancel');
    setShowDeleteConfirm(true);
  };

  const handleConfirmDelete = () => {
    playSound('cancel');
    onDeleteCharacter();
    setShowDeleteConfirm(false);
    setIsSelected(false);
  };

  const handleCancelDelete = () => {
    playSound('select');
    setShowDeleteConfirm(false);
  };

  const handleEdit = (e: MouseEvent) => {
    e.stopPropagation();
    if (character) {
      playSound('confirm');
      onSelectEdit(character);
    }
  };

  // Resolve active race/trait
  const activeRace = character ? (RACES.find(r => r.id === character.race) || RACES[0]) : RACES[0];
  const activeTrait = character ? (TRAITS.find(t => t.id === character.trait) || null) : null;
  const currentSpins = character ? (character.spins !== undefined ? character.spins : 5) : 5;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-6 crt-effect select-none">
      
      {/* Header */}
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between z-10 py-4 border-b border-slate-900">
        <button
          onClick={() => { 
            playSound('select'); 
            if (isSelected) {
              setIsSelected(false);
              setDashboardTab('MAIN');
            } else {
              onBack(); 
            }
          }}
          className="flex items-center gap-2 px-3 py-2 bg-slate-900 border-2 border-slate-800 hover:border-slate-500 rounded text-slate-400 hover:text-white font-press-start text-[10px] cursor-pointer transition-all active:scale-95"
          id="back-to-menu-btn"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isSelected ? 'BACK TO SLOTS / НАЗАД' : 'MAIN MENU / МЕНЮ'}</span>
        </button>

        <h2 className="font-press-start text-xs md:text-sm text-blue-400 tracking-wider">
          {isSelected ? 'CHARACTER HUB / ПАНЕЛЬ ПЕРСОНАЖА' : 'SELECT CHARACTER / ВЫБОР ПЕРСОНАЖА'}
        </h2>

        <div className="w-[100px] md:w-[130px] hidden sm:block" />
      </div>

      {/* Main Area: Conditionally render slots list OR selected character hub */}
      {!isSelected ? (
        /* STANDARD 3 SLOTS LIST */
        <div className="w-full max-w-5xl mx-auto my-auto grid grid-cols-1 md:grid-cols-3 gap-6 z-10 py-8">
          
          {/* SLOT 1 (ACTIVE SLOT) */}
          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center px-1 font-press-start text-[10px]">
              <span className="text-blue-400">SLOT 01</span>
              <span className="text-emerald-400">ACTIVE</span>
            </div>

            {!character ? (
              <motion.div
                whileHover={{ scale: 1.02 }}
                onClick={() => {
                  playSound('confirm');
                  onSelectCreate();
                }}
                className="h-[430px] flex flex-col items-center justify-center border-4 border-dashed border-slate-800 hover:border-blue-500 bg-slate-900/40 hover:bg-slate-900/80 rounded-xl cursor-pointer transition-all duration-300 relative group p-6 text-center"
                id="empty-slot-1"
              >
                <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg" />
                
                <div className="w-16 h-16 rounded-full border-4 border-slate-700 group-hover:border-blue-400 flex items-center justify-center mb-4 transition-all bg-slate-950 group-hover:shadow-[0_0_15px_rgba(59,130,246,0.3)] animate-pulse">
                  <Plus className="w-8 h-8 text-slate-500 group-hover:text-blue-400 transition-colors" />
                </div>

                <h3 className="font-press-start text-xs text-slate-400 group-hover:text-blue-400 mb-2">
                  NEW CHARACTER
                </h3>
                <h4 className="font-press-start text-[8px] text-slate-600 mb-3 uppercase">
                  Создать Персонажа
                </h4>
                <p className="font-mono text-xs text-slate-500 group-hover:text-slate-400 max-w-[190px]">
                  Create, customize and roleplay your anime hero
                </p>
              </motion.div>
            ) : (
              <motion.div
                whileHover={{ scale: 1.02 }}
                onClick={() => {
                  playSound('confirm');
                  setIsSelected(true);
                }}
                className="h-[430px] flex flex-col justify-between border-4 border-double bg-slate-900/80 rounded-xl p-6 relative shadow-2xl overflow-hidden cursor-pointer hover:border-blue-500 transition-all duration-300 group"
                id="active-character-card"
                style={{ borderColor: activeRace.color }}
              >
                <div
                  className="absolute -top-16 -right-16 w-32 h-32 blur-3xl opacity-20 rounded-full pointer-events-none"
                  style={{ backgroundColor: activeRace.color }}
                />

                {/* Header info */}
                <div className="flex flex-col items-center">
                  <div className="flex items-center gap-1 px-2 py-0.5 bg-slate-950/90 border border-slate-800 rounded-full mb-3 flex-wrap justify-center">
                    <span 
                      className="font-press-start text-[6px] uppercase font-bold"
                      style={{ color: activeRace.color }}
                    >
                      {activeRace.name}
                    </span>
                    <span className="text-slate-600 font-press-start text-[6px]">•</span>
                    <span className="font-press-start text-[6px] text-blue-400">
                      {character.class.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="font-press-start text-sm text-amber-300 tracking-wide text-center">
                    {character.name}
                  </h3>
                  
                  <div className="font-press-start text-[8px] text-slate-500 mt-1">
                    LVL {character.level} • EXP {character.exp}/100
                  </div>
                </div>

                {/* Animated Sprite */}
                <div className="flex justify-center items-center py-4 relative">
                  <div className="absolute w-24 h-2 bg-black/40 blur-sm rounded-full bottom-2" />
                  <PixelSprite
                    customization={character.customization}
                    size={110}
                    animation="idle"
                    tick={Math.floor(Date.now() / 250)}
                    race={character.race || 'human'}
                  />
                </div>

                {/* Quick Info Block */}
                <div className="bg-slate-950/80 border border-slate-800 rounded p-2.5 font-mono text-[11px] space-y-1 text-slate-400 text-center">
                  <div className="flex justify-between border-b border-slate-900 pb-1 text-[10px]">
                    <span>RACE / РАСА:</span>
                    <span className="font-bold text-white uppercase text-[9px]" style={{ color: activeRace.color }}>
                      {activeRace.name}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1 text-[10px]">
                    <span>TRAIT / ЧЕРТА:</span>
                    {activeTrait ? (
                      <span className="font-bold uppercase text-[9px]" style={{ color: activeTrait.color }}>
                        {activeTrait.name}
                      </span>
                    ) : (
                      <span className="text-slate-600 italic">None / Нет</span>
                    )}
                  </div>
                </div>

                {/* Click to manage indicator */}
                <div className="w-full text-center py-2.5 bg-slate-950 rounded-lg border border-slate-800 font-press-start text-[8px] text-blue-400 animate-pulse group-hover:bg-blue-950 group-hover:text-blue-200 transition-all">
                  CLICK TO SELECT / ВЫБРАТЬ
                </div>
              </motion.div>
            )}
          </div>

          {/* SLOT 2 (LOCKED) */}
          <div className="flex flex-col gap-2 opacity-40">
            <div className="flex justify-between items-center px-1 font-press-start text-[10px] text-slate-600">
              <span>SLOT 02</span>
              <span>LOCKED</span>
            </div>
            <div className="h-[430px] flex flex-col items-center justify-center border-4 border-dashed border-slate-900 bg-slate-950/40 rounded-xl p-6 text-center">
              <ShieldAlert className="w-8 h-8 text-slate-700 mb-3" />
              <h3 className="font-press-start text-[9px] text-slate-600 mb-1">
                PREVIEW ONLY
              </h3>
              <p className="font-mono text-[10px] text-slate-700 max-w-[170px]">
                Unlock additional slots in full version
              </p>
            </div>
          </div>

          {/* SLOT 3 (LOCKED) */}
          <div className="flex flex-col gap-2 opacity-40">
            <div className="flex justify-between items-center px-1 font-press-start text-[10px] text-slate-600">
              <span>SLOT 03</span>
              <span>LOCKED</span>
            </div>
            <div className="h-[430px] flex flex-col items-center justify-center border-4 border-dashed border-slate-900 bg-slate-950/40 rounded-xl p-6 text-center">
              <ShieldAlert className="w-8 h-8 text-slate-700 mb-3" />
              <h3 className="font-press-start text-[9px] text-slate-600 mb-1">
                PREVIEW ONLY
              </h3>
              <p className="font-mono text-[10px] text-slate-700 max-w-[170px]">
                Only 1 active custom sandbox allowed
              </p>
            </div>
          </div>

        </div>
      ) : (
        /* IMMERSIVE CHARACTER DASHBOARD HUB */
        character && (
          <div className="w-full max-w-5xl mx-auto my-auto grid grid-cols-1 lg:grid-cols-12 gap-6 z-10 py-6">
            
            {/* LEFT PROFILE & STATE PANEL (4 COLS) */}
            <div className="lg:col-span-4 space-y-4">
              
              {/* Profile Card */}
              <div 
                className="bg-slate-900/90 border-4 rounded-2xl p-5 relative overflow-hidden flex flex-col items-center shadow-2xl"
                style={{ borderColor: activeRace.color }}
              >
                <div
                  className="absolute -top-16 -right-16 w-36 h-36 blur-3xl opacity-20 rounded-full"
                  style={{ backgroundColor: activeRace.color }}
                />

                <div className="w-full flex justify-between items-center border-b border-slate-800 pb-3 mb-4 font-press-start text-[9px]">
                  <span className="text-blue-400">LVL {character.level}</span>
                  <span className="text-yellow-400 font-bold flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5 text-yellow-500" />
                    {character.gold}G
                  </span>
                </div>

                {/* Sprite view */}
                <div className="flex justify-center items-center relative py-3">
                  <div className="absolute w-24 h-2 bg-black/45 blur-md rounded-full bottom-0" />
                  <PixelSprite
                    customization={character.customization}
                    size={110}
                    animation="idle"
                    tick={Math.floor(Date.now() / 250)}
                    race={character.race || 'human'}
                  />
                </div>

                <h3 className="font-press-start text-sm text-amber-300 mt-4 tracking-wide text-center">
                  {character.name}
                </h3>

                {/* Class & exp indicators */}
                <div className="text-[10px] font-mono text-slate-400 mt-1.5 flex items-center gap-2">
                  <span>Class: <span className="font-bold text-blue-400">{character.class}</span></span>
                  <span className="text-slate-700">•</span>
                  <span>EXP: {character.exp}/100</span>
                </div>

                {/* EXP bar */}
                <div className="w-full bg-slate-950 h-2 border border-slate-800 rounded-full mt-2.5 overflow-hidden">
                  <div 
                    className="h-full bg-blue-500 transition-all duration-300"
                    style={{ width: `${character.exp}%` }}
                  />
                </div>

                {/* Spins indicator */}
                <div className="mt-4 px-3 py-1 bg-slate-950 border border-slate-800 rounded-full flex items-center gap-2 text-[10px] font-press-start text-cyan-400 animate-pulse">
                  <Sparkles className="w-3 h-3 text-cyan-400 animate-spin" />
                  <span>🌀 SPINS: {currentSpins}</span>
                </div>
              </div>

              {/* Stats Overview */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-2 font-mono text-xs text-slate-300">
                <div className="text-center font-press-start text-[8px] text-slate-500 border-b border-slate-800 pb-1.5 mb-2">
                  CHARACTER PARAMETERS
                </div>
                <div className="flex justify-between px-1">
                  <span className="text-red-400">STR (Strength):</span>
                  <span className="font-bold text-white">{character.stats.str}</span>
                </div>
                <div className="flex justify-between px-1">
                  <span className="text-yellow-400">AGI (Agility):</span>
                  <span className="font-bold text-white">{character.stats.agi}</span>
                </div>
                <div className="flex justify-between px-1 font-mono">
                  <span className="text-blue-400">INT (Intelligence):</span>
                  <span className="font-bold text-white">{character.stats.int}</span>
                </div>
                <div className="flex justify-between px-1">
                  <span className="text-emerald-400">VIT (Vitality):</span>
                  <span className="font-bold text-white">{character.stats.vit}</span>
                </div>
              </div>

            </div>

            {/* RIGHT MAIN CONTROL PANEL (8 COLS) */}
            <div className="lg:col-span-8 flex flex-col gap-4">
              
              {/* Active Tab Screen */}
              <div className="bg-slate-900/80 border-2 border-slate-800 rounded-2xl p-5 md:p-6 min-h-[320px] flex flex-col justify-between relative shadow-2xl">
                
                {/* Visual Glow Header background */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-amber-500 to-emerald-500 rounded-t-xl" />

                {/* GACHA SPIN OVERLAY */}
                {isSpinning && (
                  <div className="absolute inset-0 bg-slate-950/95 rounded-2xl flex flex-col items-center justify-center p-6 text-center z-20">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                      className="w-16 h-16 border-4 border-dashed rounded-full flex items-center justify-center mb-5"
                      style={{ borderColor: spinColor }}
                    >
                      <RefreshCw className="w-8 h-8" style={{ color: spinColor }} />
                    </motion.div>

                    <h3 className="font-press-start text-xs md:text-sm text-yellow-400 tracking-widest animate-bounce mb-3">
                      GACHA SPINNING / КРУТИМ...
                    </h3>

                    <div 
                      className="px-5 py-3.5 bg-slate-900 rounded-xl border-2 font-press-start text-[10px] md:text-xs tracking-wider animate-pulse max-w-sm"
                      style={{ borderColor: spinColor, color: spinColor }}
                    >
                      {spinDisplay}
                    </div>

                    <p className="font-mono text-xs text-slate-500 mt-4 italic">
                      Invoking dimensional pathways / Призываем силы аниме миров...
                    </p>
                  </div>
                )}

                {/* GAME NOT AVAILABLE NOTIFICATION POPUP */}
                {playAlertActive && (
                  <div className="absolute inset-0 bg-slate-950/95 rounded-2xl flex flex-col items-center justify-center p-6 text-center z-20">
                    <div className="w-16 h-16 rounded-full bg-red-950/50 border-2 border-red-500 flex items-center justify-center mb-5 shadow-[0_0_20px_rgba(239,68,68,0.3)] animate-pulse">
                      <ShieldAlert className="w-9 h-9 text-red-500" />
                    </div>

                    <h3 className="font-press-start text-xs md:text-sm text-red-500 tracking-wider mb-2">
                      ⚠️ ADVENTURE OFFLINE
                    </h3>
                    <h4 className="font-press-start text-[9px] text-red-400 uppercase mb-4">
                      ИГРА ЕЩЕ НЕ ДОСТУПНА!
                    </h4>

                    <div className="max-w-md bg-slate-900 p-4 border border-slate-800 rounded-lg text-slate-300 font-mono text-xs leading-relaxed space-y-3">
                      <p>
                        The multiplayer server and 2D adventure world is currently locked in preview. Standard play remains offline while our battle engine is upgraded!
                      </p>
                      <p className="text-[11px] text-slate-400 italic border-t border-slate-800/80 pt-2">
                        Игровой 2D мир и мультиплеерные серверы находятся в процессе разработки и временно закрыты. Боевой движок обновляется!
                      </p>
                    </div>

                    <button
                      onClick={() => { playSound('cancel'); setPlayAlertActive(false); }}
                      className="mt-6 px-6 py-2.5 bg-slate-800 hover:bg-slate-700 border-2 border-slate-700 rounded text-slate-300 font-press-start text-[9px] cursor-pointer active:scale-95 transition-all"
                    >
                      ACKNOWLEDGE / ПОНЯТНО
                    </button>
                  </div>
                )}

                {/* ACTIVE TAB VIEWS */}
                {dashboardTab === 'MAIN' && (
                  <div className="flex-1 flex flex-col justify-between">
                    
                    {/* Character Bio block */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-blue-400">
                        <Flame className="w-4 h-4 text-amber-500" />
                        <h4 className="font-press-start text-[10px] tracking-wider uppercase">HERO PROFILE</h4>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Race Bio */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center">
                              <span className="font-press-start text-[8px] text-slate-500">ANIME RACE</span>
                              <span 
                                className="px-1.5 py-0.5 rounded text-[7px] font-press-start border uppercase tracking-wider"
                                style={{ borderColor: activeRace.color, color: activeRace.color }}
                              >
                                {activeRace.rarity}
                              </span>
                            </div>
                            <h5 className="font-press-start text-[11px] text-white tracking-wide uppercase" style={{ color: activeRace.color }}>
                              {activeRace.name}
                            </h5>
                            <p className="font-mono text-xs text-slate-400 line-clamp-3">
                              {activeRace.description}
                            </p>
                          </div>
                          <div className="text-[9px] text-amber-500 font-press-start mt-2 border-t border-slate-900/60 pt-2">
                            Source: {activeRace.animeSource}
                          </div>
                        </div>

                        {/* Trait Bio */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center">
                              <span className="font-press-start text-[8px] text-slate-500">SPECIAL TRAIT</span>
                              {activeTrait && (
                                <span 
                                  className="px-1.5 py-0.5 rounded text-[7px] font-press-start border uppercase tracking-wider"
                                  style={{ borderColor: activeTrait.color, color: activeTrait.color }}
                                >
                                  {activeTrait.rarity}
                                </span>
                              )}
                            </div>
                            {activeTrait ? (
                              <>
                                <h5 className="font-press-start text-[11px] tracking-wide uppercase" style={{ color: activeTrait.color }}>
                                  {activeTrait.name}
                                </h5>
                                <p className="font-mono text-xs text-slate-400 line-clamp-3">
                                  {activeTrait.description}
                                </p>
                              </>
                            ) : (
                              <>
                                <h5 className="font-press-start text-[11px] text-slate-600 tracking-wide uppercase italic">
                                  NONE / НЕТ ЧЕРТЫ
                                </h5>
                                <p className="font-mono text-xs text-slate-600 leading-relaxed">
                                  No unique trait active. Roll the trait gacha to acquire incredible powers from your favorite anime series!
                                </p>
                              </>
                            )}
                          </div>
                          {activeTrait && (
                            <div className="text-[9px] text-cyan-400 font-press-start mt-2 border-t border-slate-900/60 pt-2">
                              Source: {activeTrait.animeSource}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Quick navigation icons */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
                      
                      {/* PLAY BUTTON */}
                      <button
                        onClick={() => { playSound('confirm'); setPlayAlertActive(true); }}
                        className="flex flex-col items-center justify-center p-3.5 bg-gradient-to-b from-emerald-600 to-green-800 hover:from-emerald-500 hover:to-green-700 border-2 border-emerald-400 hover:border-emerald-300 rounded-xl text-white font-press-start text-[9px] cursor-pointer transition-all active:scale-95 shadow-lg group gap-1"
                      >
                        <Swords className="w-5 h-5 text-emerald-200 animate-bounce" />
                        <span>PLAY / ИГРАТЬ</span>
                      </button>

                      {/* GACHA SPIN MENU */}
                      <button
                        onClick={() => { playSound('select'); setDashboardTab('ROLLS'); }}
                        className="flex flex-col items-center justify-center p-3.5 bg-slate-800 hover:bg-slate-700 border-2 border-slate-700 hover:border-amber-500 rounded-xl text-amber-300 font-press-start text-[9px] cursor-pointer transition-all active:scale-95 group gap-1"
                      >
                        <RefreshCw className="w-5 h-5 text-amber-500 animate-spin-slow group-hover:text-amber-400" />
                        <span>ROLLS / КРУТКИ</span>
                      </button>

                      {/* PROMO CODES */}
                      <button
                        onClick={() => { playSound('select'); setDashboardTab('CODES'); setCodeFeedback(null); }}
                        className="flex flex-col items-center justify-center p-3.5 bg-slate-800 hover:bg-slate-700 border-2 border-slate-700 hover:border-cyan-500 rounded-xl text-cyan-300 font-press-start text-[9px] cursor-pointer transition-all active:scale-95 group gap-1"
                      >
                        <Gift className="w-5 h-5 text-cyan-500 group-hover:text-cyan-400" />
                        <span>CODES / КОДЫ</span>
                      </button>

                      {/* BACK BUTTON */}
                      <button
                        onClick={() => { playSound('select'); setIsSelected(false); }}
                        className="flex flex-col items-center justify-center p-3.5 bg-slate-800 hover:bg-slate-700 border-2 border-slate-700 hover:border-slate-400 rounded-xl text-slate-300 font-press-start text-[9px] cursor-pointer transition-all active:scale-95 group gap-1"
                      >
                        <ArrowLeft className="w-5 h-5 text-slate-500 group-hover:text-slate-400" />
                        <span>SLOTS / НАЗАД</span>
                      </button>

                    </div>
                  </div>
                )}

                {/* GACHA ROLLS SUBPANEL */}
                {dashboardTab === 'ROLLS' && (
                  <div className="flex-1 flex flex-col justify-between">
                    
                    {/* Header */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                        <div className="flex items-center gap-2">
                          <RefreshCw className="w-4 h-4 text-amber-500 animate-spin-slow" />
                          <h4 className="font-press-start text-[10px] text-amber-400 tracking-wider">ANIME GACHA CONSOLE</h4>
                        </div>
                        <span className="font-press-start text-[9px] text-cyan-400">SPINS: {currentSpins}</span>
                      </div>
                      
                      <p className="font-mono text-xs text-slate-400 leading-relaxed">
                        Roll to completely customize your character's innate biological power and visual lineage. All rolls are fully weighted with authentic rarities (up to 0.5% Divine):
                      </p>
                    </div>

                    {/* Spin Options Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-4">
                      
                      {/* Spin Race */}
                      <button
                        onClick={() => triggerGachaRoll('RACE')}
                        className="p-4 bg-slate-950 hover:bg-slate-900 border-2 border-slate-800 hover:border-amber-500 rounded-xl flex flex-col items-center text-center gap-2 group cursor-pointer transition-all active:scale-95"
                      >
                        <RefreshCw className="w-6 h-6 text-emerald-400 animate-spin-slow group-hover:text-emerald-300" />
                        <span className="font-press-start text-[9px] text-slate-200">ROLL ANIME RACE</span>
                        <span className="font-press-start text-[7px] text-emerald-500">COST: 1 SPIN</span>
                      </button>

                      {/* Spin Trait */}
                      <button
                        onClick={() => triggerGachaRoll('TRAIT')}
                        className="p-4 bg-slate-950 hover:bg-slate-900 border-2 border-slate-800 hover:border-cyan-500 rounded-xl flex flex-col items-center text-center gap-2 group cursor-pointer transition-all active:scale-95"
                      >
                        <Sparkles className="w-6 h-6 text-cyan-400 animate-pulse group-hover:text-cyan-300" />
                        <span className="font-press-start text-[9px] text-slate-200">ROLL ANIME TRAIT</span>
                        <span className="font-press-start text-[7px] text-cyan-500">COST: 1 SPIN</span>
                      </button>

                      {/* Buy spins */}
                      <button
                        onClick={handleBuySpin}
                        className="p-4 bg-slate-950 hover:bg-slate-900 border-2 border-slate-800 hover:border-yellow-500 rounded-xl flex flex-col items-center text-center gap-2 group cursor-pointer transition-all active:scale-95"
                      >
                        <Coins className="w-6 h-6 text-yellow-400" />
                        <span className="font-press-start text-[9px] text-slate-200">BUY +1 GACHA SPIN</span>
                        <span className="font-press-start text-[7px] text-yellow-500">COST: 100 GOLD</span>
                      </button>

                    </div>

                    {/* Back to main */}
                    <button
                      onClick={() => { playSound('select'); setDashboardTab('MAIN'); }}
                      className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-slate-300 font-press-start text-[9px] cursor-pointer"
                    >
                      BACK TO PROFILE / НАЗАД В ПРОФИЛЬ
                    </button>
                  </div>
                )}

                {/* CODES SUBPANEL */}
                {dashboardTab === 'CODES' && (
                  <div className="flex-1 flex flex-col justify-between">
                    
                    {/* Header */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                        <Key className="w-4 h-4 text-cyan-400" />
                        <h4 className="font-press-start text-[10px] text-cyan-400 tracking-wider">SECRET PROMO CODES / ПРОМОКОДЫ</h4>
                      </div>
                      <p className="font-mono text-xs text-slate-400">
                        Enter secret promotional codes to claim bonus spins and gold items in this sandbox environment:
                      </p>
                    </div>

                    {/* Form and Input */}
                    <div className="space-y-4 my-4">
                      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); }}>
                        <input
                          type="text"
                          value={codeInputValue}
                          onChange={(e) => setCodeInputValue(e.target.value)}
                          placeholder="ENTER CODE / ВВЕДИТЕ ПРОМОКОД"
                          className="flex-1 bg-slate-950 border-2 border-slate-800 focus:border-cyan-500 rounded-lg px-4 py-2.5 font-mono text-xs outline-none text-white uppercase text-center"
                        />
                        <button
                          type="button"
                          onClick={handleRedeemCode}
                          className="px-6 py-2 bg-cyan-700 hover:bg-cyan-600 border border-cyan-400 rounded-lg text-white font-press-start text-[9px] cursor-pointer"
                        >
                          CLAIM / ОК
                        </button>
                      </form>

                      {/* Code redemption status feedback */}
                      {codeFeedback && (
                        <div className={`p-3 rounded-lg border text-center font-mono text-[11px] ${
                          codeFeedback.success 
                            ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-400' 
                            : 'bg-red-950/40 border-red-500/50 text-red-400'
                        }`}>
                          <div>{codeFeedback.message}</div>
                          <div className="italic text-[10px] opacity-80 mt-0.5">{codeFeedback.messageRu}</div>
                        </div>
                      )}

                      {/* Hints list of codes */}
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
                        <div className="font-press-start text-[7px] text-slate-500 mb-2">AVAILABLE SANDBOX CODES:</div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px] font-mono text-slate-400 text-center">
                          <div><span className="text-cyan-400 font-bold">START</span> (+5 spins)</div>
                          <div><span className="text-cyan-400 font-bold">GIFT</span> (+3 spins)</div>
                          <div><span className="text-cyan-400 font-bold">ANIME</span> (+10 spins)</div>
                          <div><span className="text-cyan-400 font-bold">IRUNA</span> (+15 spins)</div>
                        </div>
                      </div>
                    </div>

                    {/* Back button */}
                    <button
                      onClick={() => { playSound('select'); setDashboardTab('MAIN'); }}
                      className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-slate-300 font-press-start text-[9px] cursor-pointer"
                    >
                      BACK TO PROFILE / НАЗАД В ПРОФИЛЬ
                    </button>
                  </div>
                )}

              </div>

              {/* Lower Actions (Edit visual aspect / Delete) */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleEdit}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-slate-900 border-2 border-slate-700 hover:border-amber-400 rounded-xl text-slate-300 hover:text-amber-300 font-press-start text-[8px] cursor-pointer transition-all active:scale-95"
                >
                  <Edit2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>EDIT VISUAL APPEARANCE / ВНЕШНОСТЬ</span>
                </button>

                <button
                  onClick={handleDelete}
                  className="px-5 py-3 bg-slate-950 border-2 border-slate-900 hover:border-red-600 hover:text-red-400 rounded-xl text-slate-500 transition-all cursor-pointer active:scale-95"
                  title="Delete Character / Удалить"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>
        )
      )}

      {/* Footer hint */}
      <div className="w-full text-center text-[8px] sm:text-[9px] text-slate-600 font-press-start tracking-wider z-10 py-4 max-w-5xl mx-auto border-t border-slate-900">
        CLAIM SECURED CODES TO GAIN GACHA SPINS AND UNLEASH LEGENDARY POWERS!
      </div>

      {/* Retro Deletion Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && character && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-slate-900 border-4 border-red-600 rounded-xl p-6 md:p-8 max-w-md w-full shadow-2xl relative text-center flex flex-col items-center gap-5 outline-none"
              id="delete-confirmation-dialog"
            >
              <div className="w-16 h-16 rounded-full bg-red-950/50 border-2 border-red-500 flex items-center justify-center animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.2)]">
                <AlertTriangle className="w-8 h-8 text-red-500" />
              </div>

              <div className="space-y-1">
                <h3 className="font-press-start text-xs md:text-sm text-red-500 tracking-wider">
                  DELETE CHARACTER?
                </h3>
                <h4 className="font-press-start text-[9px] text-red-400/80 tracking-wider">
                  УДАЛИТЬ ПЕРСОНАЖА?
                </h4>
              </div>

              <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-4 w-full flex items-center gap-4 justify-center">
                <PixelSprite
                  customization={character.customization}
                  size={56}
                  animation="idle"
                  tick={Math.floor(Date.now() / 250)}
                  race={character.race || 'human'}
                />
                <div className="text-left font-mono">
                  <div className="font-press-start text-[10px] text-amber-300 truncate max-w-[180px]">
                    {character.name}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    Level {character.level} {character.class}
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-center">
                <p className="font-mono text-xs text-slate-300 leading-relaxed">
                  Are you sure? This will permanently delete your character and all saved progress.
                </p>
                <p className="font-mono text-[11px] text-slate-400 leading-relaxed italic border-t border-slate-800/60 pt-2">
                  Вы уверены? Это навсегда удалит вашего персонажа и весь сохраненный игровой прогресс.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 w-full mt-2">
                <button
                  onClick={handleConfirmDelete}
                  className="flex-1 py-2.5 bg-gradient-to-r from-red-700 to-rose-600 border-2 border-red-500 hover:border-red-400 rounded text-white font-press-start text-[10px] cursor-pointer shadow-lg active:scale-95 transition-all"
                  id="confirm-delete-btn"
                >
                  YES, DELETE / ДА
                </button>
                <button
                  onClick={handleCancelDelete}
                  className="flex-1 py-2.5 bg-slate-800 border-2 border-slate-700 hover:border-slate-500 rounded text-slate-300 font-press-start text-[10px] cursor-pointer shadow-lg active:scale-95 transition-all"
                  id="cancel-delete-btn"
                >
                  CANCEL / ОТМЕНА
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
