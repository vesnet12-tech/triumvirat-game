import { useState, useEffect, MouseEvent } from 'react';
import { motion } from 'motion/react';
import { Gamepad2, Volume2, VolumeX, Sword, Play } from 'lucide-react';
import { playSound, toggleTheme } from '../utils/audio';

interface StartScreenProps {
  onStart: () => void;
}

export default function StartScreen({ onStart }: StartScreenProps) {
  const [isMusicOn, setIsMusicOn] = useState(false);
  const [stars, setStars] = useState<{ id: number; left: number; top: number; size: number; delay: number }[]>([]);

  // Generate some atmospheric retro starry background
  useEffect(() => {
    const starCount = 30;
    const generatedStars = Array.from({ length: starCount }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      top: Math.random() * 100,
      size: Math.random() * 4 + 1,
      delay: Math.random() * 3,
    }));
    setStars(generatedStars);
  }, []);

  const handleStartGame = () => {
    playSound('confirm');
    onStart();
  };

  const handleToggleMusic = (e: MouseEvent) => {
    e.stopPropagation(); // Avoid triggering any container click
    const state = toggleTheme();
    setIsMusicOn(state);
    playSound('select');
  };

  return (
    <div
      className="relative min-h-screen bg-slate-950 flex flex-col items-center justify-between p-6 overflow-hidden select-none crt-effect"
      onClick={handleStartGame}
      id="start-screen-container"
    >
      {/* Moving pixel stars background */}
      <div className="absolute inset-0 pointer-events-none">
        {stars.map((star) => (
          <div
            key={star.id}
            className="absolute bg-white rounded-none opacity-80"
            style={{
              left: `${star.left}%`,
              top: `${star.top}%`,
              width: `${star.size}px`,
              height: `${star.size}px`,
              animation: `pulse 2s infinite ease-in-out`,
              animationDelay: `${star.delay}s`,
              boxShadow: star.size > 2 ? '0 0 8px #fff' : 'none',
            }}
          />
        ))}

        {/* Ambient floating grid/ground to give Depth */}
        <div 
          className="absolute bottom-0 left-0 right-0 h-48 opacity-10"
          style={{
            backgroundImage: 'linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
            transform: 'perspective(200px) rotateX(60deg)',
            transformOrigin: 'bottom',
          }}
        />
      </div>

      {/* Top bar with audio controls */}
      <div className="w-full flex justify-between items-center z-10 max-w-4xl">
        <div className="flex items-center gap-2 text-blue-400 font-press-start text-xs">
          <Gamepad2 className="w-5 h-5 text-blue-400 animate-bounce" />
          <span>v1.0.0</span>
        </div>

        <button
          onClick={handleToggleMusic}
          className="flex items-center gap-2 px-3 py-2 bg-slate-900 border-2 border-slate-700 hover:border-blue-500 rounded text-slate-300 font-press-start text-[10px] transition-all cursor-pointer shadow-lg active:scale-95"
          id="music-toggle-btn"
        >
          {isMusicOn ? (
            <>
              <Volume2 className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400">MUSIC: ON</span>
            </>
          ) : (
            <>
              <VolumeX className="w-4 h-4 text-slate-500" />
              <span>MUSIC: OFF</span>
            </>
          )}
        </button>
      </div>

      {/* Hero Logo Title */}
      <div className="flex flex-col items-center justify-center text-center my-auto z-10">
        {/* Floating golden shield & sword decorative icon */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: [0, -10, 0], opacity: 1 }}
          transition={{
            y: { repeat: Infinity, duration: 4, ease: "easeInOut" },
            opacity: { duration: 0.8 }
          }}
          className="mb-6 bg-blue-950/40 p-4 border-4 border-double border-blue-500/60 rounded-full"
        >
          <Sword className="w-16 h-16 text-yellow-400 transform rotate-45 filter drop-shadow-[0_0_12px_rgba(234,179,8,0.5)]" />
        </motion.div>

        {/* Big stylized RPG title */}
        <h1 className="font-press-start text-3xl md:text-5xl tracking-widest leading-none text-transparent bg-clip-text bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-700 drop-shadow-[0_4px_0_rgba(0,0,0,0.8)] filter drop-shadow-[0_0_24px_rgba(245,158,11,0.2)]">
          PIXEL QUEST
        </h1>
        <h2 className="font-press-start text-sm md:text-lg tracking-wider text-blue-400 mt-3 drop-shadow-[0_2px_0_rgba(0,0,0,0.8)]">
          - ODYSSEY BEGINS -
        </h2>

        {/* Subtitle */}
        <p className="mt-8 text-slate-400 font-mono text-sm max-w-md hidden md:block">
          Create your custom 8-bit adventurer, distribute attribute points, and explore the pixel valley.
        </p>
      </div>

      {/* Start prompt area */}
      <div className="flex flex-col items-center gap-3 z-10 mb-8">
        <motion.div
          animate={{ opacity: [1, 0.3, 1] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
          className="font-press-start text-xs md:text-sm text-yellow-400 cursor-pointer flex items-center gap-2 hover:scale-105 transition-transform"
        >
          <Play className="w-4 h-4 fill-yellow-400" />
          <span>CLICK SCREEN TO START</span>
        </motion.div>

        <span className="text-[10px] text-slate-500 font-press-start uppercase">
          [ Supports Keyboard & Mouse ]
        </span>
      </div>

      {/* Decorative footer credits */}
      <div className="w-full text-center text-[9px] text-slate-600 font-press-start tracking-wider">
        © 2026 RETRO STUIdO. ALL RIGHTS RESERVED.
      </div>
    </div>
  );
}
