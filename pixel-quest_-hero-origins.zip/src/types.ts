export type RPGClass = 'Warrior' | 'Mage' | 'Rogue' | 'Cleric';

export interface RPGClassData {
  name: RPGClass;
  description: string;
  baseStats: {
    str: number; // Strength
    agi: number; // Agility
    int: number; // Intelligence
    vit: number; // Vitality
  };
  startingWeapon: string;
  color: string;
}

export interface CharacterStats {
  str: number;
  agi: number;
  int: number;
  vit: number;
}

export interface Customization {
  skinColor: string;
  hairStyle: 'spiky' | 'long' | 'twintails' | 'messy' | 'bob' | 'none';
  hairColor: string;
  accessory: 'bunny' | 'witch' | 'cap' | 'none';
  accessoryColor: string;
  eyeStyle: 'classic' | 'hero' | 'goggles' | 'serious';
  eyeColor: string;
  outfitStyle: 'jacket' | 'apron' | 'sweater' | 't_shirt' | 'hoodie';
  outfitColor: string;
  innerColor: string; // Color for shirts, details
  weaponStyle: 'sword' | 'staff' | 'bow' | 'shield' | 'none';
  weaponColor: string;
  blush: boolean;
  useRetroSprite?: boolean; // Toggles the retro character pack
  retroSpriteId?: number;    // ID from 1 to 32
}

export type RarityType = 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic' | 'Divine';

export interface RaceData {
  id: string;
  name: string;
  russianName: string;
  rarity: RarityType;
  animeSource: string;
  description: string;
  descriptionRu: string;
  statBonus: {
    str: number;
    agi: number;
    int: number;
    vit: number;
  };
  color: string; // hex color for glow & UI
}

export interface TraitData {
  id: string;
  name: string;
  russianName: string;
  rarity: RarityType;
  animeSource: string;
  description: string;
  descriptionRu: string;
  statBonus: {
    str?: number;
    agi?: number;
    int?: number;
    vit?: number;
  };
  color: string;
}

export interface Character {
  id: string;
  name: string;
  class: RPGClass;
  stats: CharacterStats;
  customization: Customization;
  level: number;
  gold: number;
  exp: number;
  createdAt: string;
  race?: string; // ID of the race
  trait?: string; // ID of the active trait
  spins?: number; // Gacha spins remaining (starts at 5)
}

export const CLASSES: Record<RPGClass, RPGClassData> = {
  Warrior: {
    name: 'Warrior',
    description: 'A strong fighter skilled in melee weapons and heavy armor. High survivability.',
    baseStats: { str: 12, agi: 8, int: 5, vit: 15 },
    startingWeapon: 'Sword',
    color: '#ef4444', // Red
  },
  Mage: {
    name: 'Mage',
    description: 'A master of arcane magic who casts spells to destroy foes. High intellect.',
    baseStats: { str: 4, agi: 7, int: 15, vit: 9 },
    startingWeapon: 'Staff',
    color: '#3b82f6', // Blue
  },
  Rogue: {
    name: 'Rogue',
    description: 'A swift, stealthy assassin using daggers and speed to outmaneuver enemies.',
    baseStats: { str: 8, agi: 14, int: 6, vit: 10 },
    startingWeapon: 'Dagger',
    color: '#eab308', // Yellow
  },
  Cleric: {
    name: 'Cleric',
    description: 'A holy crusader who heals allies and smites undead using divine spells.',
    baseStats: { str: 9, agi: 6, int: 11, vit: 12 },
    startingWeapon: 'Mace',
    color: '#10b981', // Emerald
  },
};

export const COLOR_PALETTES = {
  skin: [
    { name: 'Fair', value: '#ffd1a9' },
    { name: 'Peach', value: '#ffb38a' },
    { name: 'Tan', value: '#dca37c' },
    { name: 'Dark', value: '#8b5a2b' },
    { name: 'Orc Green', value: '#76a060' },
    { name: 'Undead Blue', value: '#7fa3b5' },
  ],
  hair: [
    { name: 'Golden Blonde', value: '#facc15' },
    { name: 'Ruby Red', value: '#ef4444' },
    { name: 'Royal Blue', value: '#3b82f6' },
    { name: 'Emerald Green', value: '#10b981' },
    { name: 'Deep Black', value: '#1e293b' },
    { name: 'Pure White', value: '#f8fafc' },
    { name: 'Mystic Purple', value: '#a855f7' },
    { name: 'Orange', value: '#f97316' },
  ],
  eye: [
    { name: 'Sapphire', value: '#3b82f6' },
    { name: 'Emerald', value: '#10b981' },
    { name: 'Ruby', value: '#ef4444' },
    { name: 'Amethyst', value: '#a855f7' },
    { name: 'Charcoal', value: '#475569' },
    { name: 'Amber', value: '#d97706' },
  ],
  outfit: [
    { name: 'Steel Crimson', value: '#be123c' },
    { name: 'Wizard Violet', value: '#6d28d9' },
    { name: 'Ranger Forest', value: '#15803d' },
    { name: 'Shadow Charcoal', value: '#334155' },
    { name: 'Royal Gold', value: '#ca8a04' },
    { name: 'Ocean Cyan', value: '#0369a1' },
    { name: 'Sacred Teal', value: '#0f766e' },
  ],
  weapon: [
    { name: 'Iron Gray', value: '#94a3b8' },
    { name: 'Bronze Brown', value: '#b45309' },
    { name: 'Arcane Cyan', value: '#06b6d4' },
    { name: 'Gold Glint', value: '#eab308' },
    { name: 'Bloodwood', value: '#991b1b' },
  ]
};

export const RACES: RaceData[] = [
  // COMMON (3)
  {
    id: 'human',
    name: 'Human',
    russianName: 'Человек',
    rarity: 'Common',
    animeSource: 'Classic Fantasy / Real Life',
    description: 'An adaptable race with balanced potential, ready for any adventure.',
    descriptionRu: 'Универсальная раса со сбалансированным потенциалом, готовая к любым приключениям.',
    statBonus: { str: 1, agi: 1, int: 1, vit: 1 },
    color: '#94a3b8'
  },
  {
    id: 'otaku',
    name: 'Otaku',
    russianName: 'Отаку',
    rarity: 'Common',
    animeSource: 'No Game No Life',
    description: 'Possesses immense knowledge of gaming rules. Highly intelligent but physically average.',
    descriptionRu: 'Обладает обширными знаниями игровых правил. Высокий интеллект, но средние показатели.',
    statBonus: { str: 0, agi: 1, int: 3, vit: 0 },
    color: '#94a3b8'
  },
  {
    id: 'goblin',
    name: 'Goblin',
    russianName: 'Гоблин',
    rarity: 'Common',
    animeSource: 'Goblin Slayer',
    description: 'Small, green, nimble, and cunning. Loves gold and shiny accessories.',
    descriptionRu: 'Маленький, зеленый, ловкий и хитрый. Обожает золото и блестящие побрякушки.',
    statBonus: { str: 1, agi: 3, int: 0, vit: 0 },
    color: '#76a060'
  },

  // UNCOMMON (3)
  {
    id: 'neko',
    name: 'Neko',
    russianName: 'Неко',
    rarity: 'Uncommon',
    animeSource: 'Sword Art Online',
    description: 'Agile cat-like humanoid. Can dodge attacks easily with quick reflexes.',
    descriptionRu: 'Ловкий зверолюд-кошка. С легкостью уклоняется от атак благодаря быстрым рефлексам.',
    statBonus: { str: 1, agi: 3, int: 0, vit: 2 },
    color: '#10b981'
  },
  {
    id: 'cyborg',
    name: 'Cyborg',
    russianName: 'Киборг',
    rarity: 'Uncommon',
    animeSource: 'One Punch Man',
    description: 'Cybernetically enhanced fighter. Excellent damage output and computational logic.',
    descriptionRu: 'Кибернетически улучшенный боец. Отличный урон и вычислительная логика.',
    statBonus: { str: 3, agi: 0, int: 3, vit: 0 },
    color: '#10b981'
  },
  {
    id: 'esper',
    name: 'Esper',
    russianName: 'Эспер',
    rarity: 'Uncommon',
    animeSource: 'Mob Psycho 100',
    description: 'Gifted with supernatural telekinetic abilities. Strong focus on magic/intellect.',
    descriptionRu: 'Одарен сверхъестественными способностями. Упор на магию и интеллект.',
    statBonus: { str: 0, agi: 1, int: 4, vit: 1 },
    color: '#10b981'
  },

  // RARE (3)
  {
    id: 'saiyan',
    name: 'Saiyan',
    russianName: 'Сайан',
    rarity: 'Rare',
    animeSource: 'Dragon Ball Z',
    description: 'Fierce warrior race. Gets stronger from the brink of defeat. High brute force.',
    descriptionRu: 'Воинственная раса. Становится сильнее на грани поражения. Высокая физ. сила.',
    statBonus: { str: 5, agi: 1, int: 0, vit: 3 },
    color: '#3b82f6'
  },
  {
    id: 'ghoul',
    name: 'Ghoul',
    russianName: 'Гуль',
    rarity: 'Rare',
    animeSource: 'Tokyo Ghoul',
    description: 'Superhuman speed and regeneration. Feeds on high-density cells to empower physical strikes.',
    descriptionRu: 'Сверхчеловеческая скорость и регенерация. Питается для усиления физических атак.',
    statBonus: { str: 3, agi: 4, int: 0, vit: 2 },
    color: '#3b82f6'
  },
  {
    id: 'shinigami',
    name: 'Shinigami',
    russianName: 'Синигами',
    rarity: 'Rare',
    animeSource: 'Bleach',
    description: 'Soul reaper guarding the cycle of reincarnation. Excels in spiritual and tactical mastery.',
    descriptionRu: 'Жнец душ, охраняющий цикл реинкарнации. Мастер духовных и тактических искусств.',
    statBonus: { str: 2, agi: 2, int: 4, vit: 1 },
    color: '#3b82f6'
  },

  // EPIC (3)
  {
    id: 'uchiha',
    name: 'Uchiha',
    russianName: 'Учиха',
    rarity: 'Epic',
    animeSource: 'Naruto',
    description: 'Blessed with the Sharingan. Outstanding visual prowess, reflexes, and elemental magic.',
    descriptionRu: 'Благословлен Шаринганом. Выдающаяся реакция, рефлексы и стихийная магия.',
    statBonus: { str: 2, agi: 4, int: 5, vit: 1 },
    color: '#a855f7'
  },
  {
    id: 'demon',
    name: 'Demon',
    russianName: 'Демон',
    rarity: 'Epic',
    animeSource: 'Demon Slayer',
    description: 'Feared night stalker. High health pool and raw physical capability, but sensitive to sunlight.',
    descriptionRu: 'Ночной преследователь. Огромный запас здоровья и физической силы.',
    statBonus: { str: 5, agi: 2, int: 0, vit: 5 },
    color: '#a855f7'
  },
  {
    id: 'vampire',
    name: 'Vampire',
    russianName: 'Вампир',
    rarity: 'Epic',
    animeSource: 'Hellsing',
    description: 'Ancient bloodsucker. Balanced high stats across all categories. True immortal.',
    descriptionRu: 'Древний кровопийца. Сбалансированные высокие показатели во всех категориях.',
    statBonus: { str: 3, agi: 3, int: 3, vit: 3 },
    color: '#a855f7'
  },

  // LEGENDARY (3)
  {
    id: 'hollow',
    name: 'Vasto Lorde',
    russianName: 'Пустой',
    rarity: 'Legendary',
    animeSource: 'Bleach',
    description: 'An evolved high-class hollow. Possesses terrifying raw strength and speed.',
    descriptionRu: 'Эволюционировавший пустой высшего класса. Обладает ужасающей силой и скоростью.',
    statBonus: { str: 8, agi: 6, int: 0, vit: 4 },
    color: '#f97316'
  },
  {
    id: 'titan',
    name: 'Titan',
    russianName: 'Титан',
    rarity: 'Legendary',
    animeSource: 'Attack on Titan',
    description: 'Colossal giant of immense vitality and health. Punishes enemies with unmatched defense.',
    descriptionRu: 'Колоссальный гигант огромной живучести. Сокрушает врагов непревзойденной защитой.',
    statBonus: { str: 6, agi: 0, int: 0, vit: 12 },
    color: '#f97316'
  },
  {
    id: 'sorcerer',
    name: 'Jujutsu Sorcerer',
    russianName: 'Маг Жужуцу',
    rarity: 'Legendary',
    animeSource: 'Jujutsu Kaisen',
    description: 'Channels cursed energy. Mastery over advanced domain expansions and tactical barriers.',
    descriptionRu: 'Управляет проклятой энергией. Мастер расширения территории и магических барьеров.',
    statBonus: { str: 2, agi: 4, int: 8, vit: 4 },
    color: '#f97316'
  },

  // MYTHIC (3)
  {
    id: 'ramen',
    name: 'Ramen Spirit',
    russianName: 'Дух Рамена',
    rarity: 'Mythic',
    animeSource: 'Naruto (Ichiraku)',
    description: 'The ultimate food god! Feeds off pure flavor to bolster extreme energy and health.',
    descriptionRu: 'Абсолютное божество лапши! Питается чистым вкусом для колоссальной стойкости.',
    statBonus: { str: 6, agi: 4, int: 4, vit: 10 },
    color: '#ef4444'
  },
  {
    id: 'arrancar',
    name: 'Arrancar',
    russianName: 'Арранкар',
    rarity: 'Mythic',
    animeSource: 'Bleach (Espada)',
    description: 'A hollow that took off its mask to gain shinigami powers. Extremely destructive.',
    descriptionRu: 'Пустой, снявший маску ради обретения силы синигами. Экстремально разрушителен.',
    statBonus: { str: 9, agi: 7, int: 4, vit: 4 },
    color: '#ef4444'
  },
  {
    id: 'dragon_slayer',
    name: 'Dragon Slayer',
    russianName: 'Убийца Драконов',
    rarity: 'Mythic',
    animeSource: 'Fairy Tail',
    description: 'Fights with dragon claws and breath. Immune to elements, possesses ancient fires.',
    descriptionRu: 'Сражается когтями и дыханием дракона. Иммунен к стихиям, владеет древним огнем.',
    statBonus: { str: 10, agi: 4, int: 5, vit: 5 },
    color: '#ef4444'
  },

  // DIVINE (2)
  {
    id: 'otsutsuki',
    name: 'Otsutsuki',
    russianName: 'Ооцуцуки',
    rarity: 'Divine',
    animeSource: 'Naruto / Boruto',
    description: 'Celestial being that travels dimensions. Possesses divine chakra reserves.',
    descriptionRu: 'Небесное существо, путешествующее по измерениям. Обладает божественной чакрой.',
    statBonus: { str: 8, agi: 8, int: 12, vit: 8 },
    color: '#eab308'
  },
  {
    id: 'sun_god',
    name: 'Sun God Nika',
    russianName: 'Бог Солнца Ника',
    rarity: 'Divine',
    animeSource: 'One Piece (Gear 5)',
    description: 'The Warrior of Liberation. Fights with rubbery freedom, absolute laughter, and cosmic agility.',
    descriptionRu: 'Воин Освобождения. Сражается с абсолютной свободой, весельем и космической ловкостью.',
    statBonus: { str: 12, agi: 12, int: 6, vit: 6 },
    color: '#eab308'
  }
];

export const TRAITS: TraitData[] = [
  // COMMON
  {
    id: 'average_joe',
    name: 'Average Joe',
    russianName: 'Обычный Парень',
    rarity: 'Common',
    animeSource: 'Saitama (Pre-Training)',
    description: 'Just an ordinary human trying to survive. Extremely average yet surprisingly resilient.',
    descriptionRu: 'Просто обычный человек, пытающийся выжить. Крайне заурядный, но удивительно стойкий.',
    statBonus: { str: 1, vit: 1 },
    color: '#94a3b8'
  },
  {
    id: 'bookworm',
    name: 'Bookworm',
    russianName: 'Книжный Червь',
    rarity: 'Common',
    animeSource: 'Ascendance of a Bookworm',
    description: 'Devotes all time to ancient manuscripts. Intellectual focus, but physically weak.',
    descriptionRu: 'Посвящает все время древним манускриптам. Сильный фокус на интеллект, слаб физически.',
    statBonus: { int: 2 },
    color: '#94a3b8'
  },
  {
    id: 'crybaby',
    name: 'Crybaby Hero',
    russianName: 'Герой-Плакса',
    rarity: 'Common',
    animeSource: 'Tokyo Revengers',
    description: 'Cries easily in tough situations, but never gives up. Exceptional emotional durability.',
    descriptionRu: 'Легко плачет в трудных ситуациях, но никогда не сдается. Исключительная стойкость.',
    statBonus: { vit: 2 },
    color: '#94a3b8'
  },

  // UNCOMMON
  {
    id: 'shadow_lurker',
    name: 'Shadow Lurker',
    russianName: 'Крадущийся в Тени',
    rarity: 'Uncommon',
    animeSource: 'Eminence in Shadow',
    description: 'Stays low-profile to operate from the shadows. Grants high dexterity and speed.',
    descriptionRu: 'Остается незамеченным, чтобы действовать из тени. Дарует высокую ловкость и скорость.',
    statBonus: { agi: 3 },
    color: '#10b981'
  },
  {
    id: 'overlord',
    name: 'Overlord Presence',
    russianName: 'Аура Оверлорда',
    rarity: 'Uncommon',
    animeSource: 'Overlord',
    description: 'A dark imposing aura that commands authority and mental absolute clarity.',
    descriptionRu: 'Темная внушительная аура, внушающая авторитет и абсолютную ясность разума.',
    statBonus: { int: 2, vit: 2 },
    color: '#10b981'
  },
  {
    id: 'gluttony',
    name: 'Gluttony',
    russianName: 'Обжорство',
    rarity: 'Uncommon',
    animeSource: 'Slime Tensei',
    description: 'Able to digest any organic or magical matter. Vastly improves physical metabolism and health.',
    descriptionRu: 'Способен переваривать любую органику и магию. Значительно улучшает метаболизм и здоровье.',
    statBonus: { vit: 4 },
    color: '#10b981'
  },

  // RARE
  {
    id: 'dragon_heart',
    name: 'Dragon Heart',
    russianName: 'Сердце Дракона',
    rarity: 'Rare',
    animeSource: 'Fairy Tail',
    description: 'A glowing internal engine granting immense physical strike force and elemental power.',
    descriptionRu: 'Светящийся внутренний двигатель, дарующий огромную физическую силу удара и выносливость.',
    statBonus: { str: 4, vit: 2 },
    color: '#3b82f6'
  },
  {
    id: 'sharingan_trait',
    name: 'Sharingan',
    russianName: 'Шаринган',
    rarity: 'Rare',
    animeSource: 'Naruto',
    description: 'Legendary crimson eye that tracks enemy movements, anticipating spells and physical strikes.',
    descriptionRu: 'Легендарный алый глаз, отслеживающий движения врагов, предугадывая заклинания и удары.',
    statBonus: { int: 3, agi: 3 },
    color: '#3b82f6'
  },
  {
    id: 'alchemist',
    name: 'State Alchemist',
    russianName: 'Государственный Алхимик',
    rarity: 'Rare',
    animeSource: 'Fullmetal Alchemist',
    description: 'Master of equivalent exchange. Uses chemical and physical formulas to manipulate materials.',
    descriptionRu: 'Мастер эквивалентного обмена. Использует химические формулы для изменения материалов.',
    statBonus: { int: 4, vit: 2 },
    color: '#3b82f6'
  },

  // EPIC
  {
    id: 'gear_second',
    name: 'Gear Second',
    russianName: 'Второй Гир',
    rarity: 'Epic',
    animeSource: 'One Piece',
    description: 'Pumps blood faster to gain massive speeds. High agility and quick physical response.',
    descriptionRu: 'Качает кровь быстрее ради колоссальной скорости. Высокая ловкость и быстрая реакция.',
    statBonus: { agi: 6, str: 2 },
    color: '#a855f7'
  },
  {
    id: 'spirit_gun',
    name: 'Spirit Gunner',
    russianName: 'Духовный Стрелок',
    rarity: 'Epic',
    animeSource: 'Yu Yu Hakusho',
    description: 'Focuses spiritual energy into the fingertips to unleash blasting kinetic energy.',
    descriptionRu: 'Концентрирует духовную энергию в кончиках пальцев для выпуска мощного кинетического заряда.',
    statBonus: { int: 5, str: 3 },
    color: '#a855f7'
  },
  {
    id: 'king_of_games',
    name: 'King of Games',
    russianName: 'Король Игр',
    rarity: 'Epic',
    animeSource: 'Yu-Gi-Oh!',
    description: 'The absolute master of strategies. Always draws the perfect response and outsmarts challenges.',
    descriptionRu: 'Абсолютный мастер стратегий. Всегда находит идеальный ответ и обходит любые преграды.',
    statBonus: { int: 6, agi: 2 },
    color: '#a855f7'
  },

  // LEGENDARY
  {
    id: 'super_saiyan',
    name: 'Super Saiyan',
    russianName: 'Супер Сайян',
    rarity: 'Legendary',
    animeSource: 'Dragon Ball Z',
    description: 'An ancient warrior rage. Surges golden electric energy, doubling pure combat output.',
    descriptionRu: 'Древняя ярость воина. Извергает золотую электрическую энергию, удваивая боевой потенциал.',
    statBonus: { str: 8, agi: 4 },
    color: '#f97316'
  },
  {
    id: 'limit_breaker',
    name: 'Shadow Monarch',
    russianName: 'Теневой Монарх',
    rarity: 'Legendary',
    animeSource: 'Solo Leveling',
    description: 'Breaks all human limits. Continuously grows stronger through brutal leveling effort.',
    descriptionRu: 'Ломает любые человеческие лимиты. Непрерывно становится сильнее благодаря суровым тренировкам.',
    statBonus: { str: 5, agi: 5, vit: 5 },
    color: '#f97316'
  },
  {
    id: 'geass',
    name: 'Absolute Command',
    russianName: 'Абсолютный Приказ',
    rarity: 'Legendary',
    animeSource: 'Code Geass',
    description: 'Commands obedience through eye contact. Bestows terrifying intelligence and strategic foresight.',
    descriptionRu: 'Повелевает чужой волей через зрительный контакт. Дарует пугающий интеллект и тактичность.',
    statBonus: { int: 10, vit: 2 },
    color: '#f97316'
  },

  // MYTHIC
  {
    id: 'one_for_all',
    name: 'One For All',
    russianName: 'Один за Всех',
    rarity: 'Mythic',
    animeSource: 'My Hero Academia',
    description: 'Sacred stockpiled physical power. Unleashes earthquakes and shockwaves with standard strikes.',
    descriptionRu: 'Священная накопленная физическая мощь. Вызывает землетрясения и ударные волны простыми ударами.',
    statBonus: { str: 12, vit: 6 },
    color: '#ef4444'
  },
  {
    id: 'infinite_void',
    name: 'Limitless Void',
    russianName: 'Безграничная Пустота',
    rarity: 'Mythic',
    animeSource: 'Jujutsu Kaisen',
    description: 'Floods enemies with infinite sensory information. Offers god-like intellectual and evasive parameters.',
    descriptionRu: 'Перегружает врагов бесконечным потоком информации. Дарует божественный разум и уклонение.',
    statBonus: { int: 12, agi: 6 },
    color: '#ef4444'
  },
  {
    id: 'death_note_trait',
    name: 'Death Note Owner',
    russianName: 'Владелец Тетради Смерти',
    rarity: 'Mythic',
    animeSource: 'Death Note',
    description: 'Holds the power of life and death. Possesses infinite strategic wit and cosmic calculations.',
    descriptionRu: 'Обладает властью над жизнью и смертью. Имеет бесконечный стратегический ум и расчетливость.',
    statBonus: { int: 15, vit: 3 },
    color: '#ef4444'
  },

  // DIVINE
  {
    id: 'serious_punch',
    name: 'Serious Punch',
    russianName: 'Серьезный Удар',
    rarity: 'Divine',
    animeSource: 'One Punch Man',
    description: 'One punch is all it takes! Destroys local dimensional boundaries with unparalleled kinetic force.',
    descriptionRu: 'Одного удара достаточно! Разрушает пространственные границы непревзойденной силой.',
    statBonus: { str: 20, vit: 5 },
    color: '#eab308'
  },
  {
    id: 'ultra_instinct',
    name: 'Ultra Instinct',
    russianName: 'Автономный Ультра Эгоизм',
    rarity: 'Divine',
    animeSource: 'Dragon Ball Super',
    description: 'The body reacts automatically without thinking. Absolute evasion, god-level speed, and perfect strikes.',
    descriptionRu: 'Тело реагирует автоматически без мыслительного процесса. Абсолютное уклонение, божественная скорость.',
    statBonus: { agi: 15, str: 10, vit: 5 },
    color: '#eab308'
  }
];
