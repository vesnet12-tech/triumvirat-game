import { useState, useEffect } from 'react';
import StartScreen from './components/StartScreen';
import SlotSelection from './components/SlotSelection';
import CharacterCreator from './components/CharacterCreator';
import GameWorld from './components/GameWorld';
import { Character } from './types';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'START' | 'SLOTS' | 'CREATOR' | 'WORLD'>('START');
  const [character, setCharacter] = useState<Character | null>(null);
  const [characterToEdit, setCharacterToEdit] = useState<Character | null>(null);

  // Load character from localStorage on mount
  useEffect(() => {
    try {
      const savedCharacter = localStorage.getItem('rpg_character_slot_1');
      if (savedCharacter) {
        setCharacter(JSON.parse(savedCharacter));
      }
    } catch (e) {
      console.error('Failed to load character from storage:', e);
    }
  }, []);

  // Save character to localStorage whenever it changes
  const handleSaveCharacter = (newCharacter: Character) => {
    setCharacter(newCharacter);
    try {
      localStorage.setItem('rpg_character_slot_1', JSON.stringify(newCharacter));
    } catch (e) {
      console.error('Failed to save character to storage:', e);
    }
    setCharacterToEdit(null);
    // Return to slot selection screen
    setCurrentScreen('SLOTS');
  };

  const handleCancelCreator = () => {
    setCharacterToEdit(null);
    setCurrentScreen('SLOTS');
  };

  const handleDeleteCharacter = () => {
    setCharacter(null);
    try {
      localStorage.removeItem('rpg_character_slot_1');
    } catch (e) {
      console.error('Failed to remove character from storage:', e);
    }
  };

  const handleUpdateFromGame = (updatedCharacter?: Character) => {
    if (updatedCharacter) {
      setCharacter(updatedCharacter);
      try {
        localStorage.setItem('rpg_character_slot_1', JSON.stringify(updatedCharacter));
      } catch (e) {
        console.error('Failed to update character from game:', e);
      }
    }
    setCurrentScreen('SLOTS');
  };

  return (
    <main className="min-h-screen bg-slate-950 font-sans text-slate-100 selection:bg-blue-600 selection:text-white" id="main-app-viewport">
      {currentScreen === 'START' && (
        <StartScreen onStart={() => setCurrentScreen('SLOTS')} />
      )}

      {currentScreen === 'SLOTS' && (
        <SlotSelection
          character={character}
          onSelectCreate={() => {
            setCharacterToEdit(null);
            setCurrentScreen('CREATOR');
          }}
          onSelectPlay={() => setCurrentScreen('WORLD')}
          onDeleteCharacter={handleDeleteCharacter}
          onUpdateCharacter={handleSaveCharacter}
          onBack={() => setCurrentScreen('START')}
          onSelectEdit={(char) => {
            setCharacterToEdit(char);
            setCurrentScreen('CREATOR');
          }}
        />
      )}

      {currentScreen === 'CREATOR' && (
        <CharacterCreator
          onSave={handleSaveCharacter}
          onCancel={handleCancelCreator}
          characterToEdit={characterToEdit}
        />
      )}

      {currentScreen === 'WORLD' && character && (
        <GameWorld
          character={character}
          onExit={handleUpdateFromGame}
        />
      )}
    </main>
  );
}
